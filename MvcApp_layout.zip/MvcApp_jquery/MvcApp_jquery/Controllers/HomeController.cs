﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApp_jquery.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        public string GetServerDateTime(string userid)
        {
            return "Hello from the server:"+DateTime.Now.ToString()+":"+userid;
        }
    }
}
