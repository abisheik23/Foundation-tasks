﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MvcApp_layout.Models
{
    public class OrderModel
    {
        [Display(Name="Order ID")]
        public int OrderID { get; set; }
        [Display(Name = "Customer Name")]
        [Required(ErrorMessage="Enter the Customer Name")]
        [StringLength(int.MaxValue,MinimumLength=5,ErrorMessage="Min 5 Char")]
        public string customername { get; set; }
        [Display(Name = "Customer Email")]
        [Required(ErrorMessage="Enter CustomerID Email")]
        [EmailAddress(ErrorMessage="Invalid Email ID")]
        public string customerEmail { get; set; }
        [Range(1, 5, ErrorMessage = "Qty 1-5")]
        [Required(ErrorMessage = "Enter Quantity")]
        [Display(Name = "Item Quantity")]
        public int itemqty { get; set; }
        [Display(Name = "Item Price")]
        public int itemprice { get; set; }
        [Display(Name = "Order Address")]
        public string orderAddress { get; set; }
        [Display(Name = "OTP")]
        public string OTP { get; set; }
    }
}