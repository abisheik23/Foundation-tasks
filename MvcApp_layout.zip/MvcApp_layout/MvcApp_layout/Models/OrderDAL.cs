﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApp_layout.Models
{
    public class OrderDAL
    {
        public bool PlaceOrder(OrderModel model)
        {
            model.OrderID = 1009;
            return true;
        }
        public OrderModel FindOrder(int orderid)
        {
            OrderModel model = new OrderModel();
            model.OrderID = orderid;
            model.customername = "ABCD";
            model.customerEmail = "vi@gmail.com";
            model.itemprice = 200;
            model.itemqty = 2;
            model.orderAddress = "chennai";
            return model;
        }
        public List<OrderModel> GetOrders()
        {
            List<OrderModel> ordlist = new List<OrderModel>();

            ordlist.Add(new OrderModel 
            { OrderID = 1211, customername = "ABC", 
                customerEmail = "abc@gmail.com", 
                itemqty = 2,
                itemprice = 200, 
                orderAddress = "chennai" });


            ordlist.Add(new OrderModel
            {
                OrderID = 1123,
                customername = "dBC",
                customerEmail = "abcdd@gmail.com",
                itemqty = 3,
                itemprice = 250,
                orderAddress = "pune"
            });


            ordlist.Add(new OrderModel
            {
                OrderID = 1111,
                customername = "ABi",
                customerEmail = "abi@gmail.com",
                itemqty = 2,
                itemprice = 200,
                orderAddress = "chennai"
            });
            return ordlist;
        }
    }
}