﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApp_layout.Models;

namespace MvcApp_layout.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult PlaceOrder()
        {
            return View();
        }
        public ActionResult FindOrder()
        {
            return View();
        }
        public ActionResult CheckOTP(int OTP)
        {
            if (OTP > 1000)
            {
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        public ActionResult PlaceOrder(OrderModel model)
        {
            OrderDAL dal = new OrderDAL();
            dal.PlaceOrder(model);
            ViewBag.orderid = model.OrderID;
            return View("OrderPlaced");
        }

        public ActionResult ShowOrders()
        {
            OrderDAL dal = new OrderDAL();
            List<OrderModel> modellist = dal.GetOrders();

            return View(modellist);
        }

        public ActionResult FindOrder(int orderid)
        {
            OrderDAL dal = new OrderDAL();
            OrderModel model = dal.FindOrder(orderid);
            return View();

        }
    }
}
