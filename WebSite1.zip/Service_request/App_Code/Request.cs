﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
/// <summary>
/// Summary description for Request
/// </summary>
[DataContract]
public class Request
{
    [DataMember]
    public int reqid { get; set; }
    [DataMember]
    public int clientid { get; set; }
    [DataMember]
    public string acctype { get; set; }
    [DataMember]
    public int amount { get; set; }
}