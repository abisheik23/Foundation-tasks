﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Summary description for DatabaseDAL
/// </summary>
public class DatabaseDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public int addemp(Employee ee)
    {
        SqlTransaction trans = con.BeginTransaction();
        try
        {
            SqlCommand ins_emp = new SqlCommand("insert employee_XBBNHHF values(@name,@date,@desg,@did)", con);
            ins_emp.Parameters.AddWithValue("@name", ee.name);
            ins_emp.Parameters.AddWithValue("@date", ee.dob);
            ins_emp.Parameters.AddWithValue("@desg", ee.desg);
            ins_emp.Parameters.AddWithValue("@did", ee.deptid);

            con.Open();
            trans = con.BeginTransaction();
            ins_emp.ExecuteNonQuery();

            SqlCommand emp_id = new SqlCommand("select @@identity", con);
            trans = con.BeginTransaction();
            int empid = Convert.ToInt32(emp_id.ExecuteScalar());
            trans.Commit();
            ee.empid = empid;
            return empid;
        }
        catch(SqlException)
        {
            trans.Rollback();
            return -1;
        }
        finally
        {
            con.Close();
        }
    }

    public View viewdata(int empid)
    {
        SqlCommand view_emp = new SqlCommand
            ("select e.emp_name,e.dob,e.designation,d.dept_name from employee_XBBNHHF e join department_XBBNHHF d on(e.dept_id=d.dept_id) where e.emp_id=@id", con);
        view_emp.Parameters.AddWithValue("@id", empid);
        con.Open();
        SqlDataReader dr = view_emp.ExecuteReader();

        View v = new View();
        while (dr.Read())
        {
            v.name = dr.GetString(0);
            v.dob = dr.GetDateTime(1);
            v.desg = dr.GetString(2);
            v.dept = dr.GetString(3);
        }
        con.Close();
        return v;

    }
}