﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for View
/// </summary>
public class View
{
    public string name { get; set; }
    public DateTime dob { get; set; }
    public string desg { get; set; }
    public string dept { get; set; }
}