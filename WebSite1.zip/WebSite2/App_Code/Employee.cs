﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public int empid { get; set; }
    public string name { get; set; }
    public DateTime dob { get; set; }
    public string desg { get; set; }
    public int deptid { get; set; }
}