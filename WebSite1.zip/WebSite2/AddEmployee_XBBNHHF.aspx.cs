﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddEmployee_XBBNHHF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        Employee ee = new Employee();
        ee.name = tb_name.Text;
        ee.dob = Convert.ToDateTime(tb_date.Text);
        ee.desg = tb_desg.Text;
        ee.deptid = Convert.ToInt32(dd_dept.SelectedItem.Value);
        DatabaseDAL dal = new DatabaseDAL();
        int id=dal.addemp(ee);
        if (id != -1)
        {
            lb_id.Text = "Employee id is" + id.ToString();
            lb_msg.Text = "Employee added";
        }
        else
        {
            lb_msg.Text = "Employee not added";
        }
    }
}