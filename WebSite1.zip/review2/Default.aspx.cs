﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Net;
using System.Runtime.Serialization.Json;
using System.IO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btn_ok_Click(object sender, EventArgs e)
    {
        Order a = new Order();
        a.no = Convert.ToInt32(tb_no.Text);
        a.name = tb_name.Text;
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        string o = serializer.Serialize(a);
        WebClient pass = new WebClient();
        string address = "http://localhost:52267/WebSite1/Service.svc/myrestservice/AddList/";
        pass.UploadString(address,o);
        //string strUri = "http://localhost:52267/WebSite1/Service.svc/myrestservice/AddList/";
        //Uri uri = new Uri(strUri);
        //WebRequest request = WebRequest.Create(uri);
        //request.Method = "POST";
        //request.ContentType = "application/json; charset=utf-8";

        //JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
        //string serOut = jsonSerializer.Serialize(a);

        //using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
        //{
        //    writer.Write(serOut);
        //}

        //WebResponse responce = request.GetResponse();
        //Stream reader = responce.GetResponseStream();

        //StreamReader sReader = new StreamReader(reader);
        //string outResult = sReader.ReadToEnd();
        //sReader.Close();

    }
    protected void btn_here_Click(object sender, EventArgs e)
    {
        WebClient rest_order = new WebClient();
        string address = "http://localhost:52267/WebSite1/Service.svc/myrestservice/viewList";
        rest_order.OpenReadCompleted += new OpenReadCompletedEventHandler(rest_order_OpenReadCompleted);
        rest_order.OpenReadAsync(new Uri(address, UriKind.Absolute));
    }

    void rest_order_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
    {
        DataContractJsonSerializer json= new DataContractJsonSerializer(typeof(Order));
        Order obj = json.ReadObject(e.Result) as Order;
        lb_no.Text = obj.no.ToString();
        lb_name.Text = obj.name;
    }
}