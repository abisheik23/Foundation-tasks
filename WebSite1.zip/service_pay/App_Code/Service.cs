﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    [OperationBehavior(TransactionScopeRequired = true)]
    public int addPay(int cid, int sAccid, int tAccid, int Amount,int pin)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        if (sAccid != tAccid)
        {
            SqlCommand prj_Payfrm = new SqlCommand("select count(*) from AccountDetails where clientid=@cid and Accountid=@sAccid", con);
            SqlCommand prj_Payto = new SqlCommand("select count(*) from AccountDetails where Accountid=@tAccid", con);
            SqlCommand prj_PayAcc = new SqlCommand("select count(*) from accessdetails where Accountid=@sAccid and pin=@pin", con);
            prj_Payfrm.Parameters.AddWithValue("@cid", cid);
            prj_Payfrm.Parameters.AddWithValue("@sAccid", sAccid);
            prj_Payto.Parameters.AddWithValue("@tAccid", tAccid);
            prj_PayAcc.Parameters.AddWithValue("@sAccid", sAccid);
            prj_PayAcc.Parameters.AddWithValue("@pin", pin);
            con.Open();
            int c1 = Convert.ToInt32(prj_Payfrm.ExecuteScalar());
            int c2 = Convert.ToInt32(prj_Payto.ExecuteScalar());
            int c3 = Convert.ToInt32(prj_PayAcc.ExecuteScalar());
            if (c1 == 1 && c2 == 1 && c3 == 1)
            {
                SqlCommand prj_Pay = new SqlCommand("insert TransactionDetails values(@clid,@seAccid,@toAccid,@amt)", con);
                prj_Pay.Parameters.AddWithValue("@clid", cid);
                prj_Pay.Parameters.AddWithValue("@seAccid", sAccid);
                prj_Pay.Parameters.AddWithValue("@toAccid", tAccid);
                prj_Pay.Parameters.AddWithValue("@amt", Amount);
                prj_Pay.ExecuteNonQuery();
                SqlCommand ins_tid = new SqlCommand("select @@identity", con);
                int tid = Convert.ToInt32(ins_tid.ExecuteScalar());
                con.Close();
                return tid;

            }
            else
            {
                con.Close();
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }
}
