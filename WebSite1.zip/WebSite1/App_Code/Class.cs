﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
/// <summary>
/// Summary description for Class1
/// </summary>
[DataContract]
public class Class
{
    [DataMember]
    public int no { get; set; }

    [DataMember]
    public string name { get; set; }
}