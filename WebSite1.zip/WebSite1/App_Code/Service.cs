﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Script.Serialization;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
	

    public void AddList(string Data)
    {
        JavaScriptSerializer serializer = new JavaScriptSerializer();
        Class c = serializer.Deserialize<Class>(Data);
        viewList(c);
    }

    public Class viewList(Class c)
    {
        return c;
    }
}
