﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;


// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.

public class Service : IService
{
    public int insReq(string clientid,string type,string amt)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        try
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            SqlCommand ins_req = new SqlCommand("insert AccRequest values(@cid,@type,@amt)", con);
            ins_req.Parameters.AddWithValue("@cid", Convert.ToInt32(clientid));
            ins_req.Parameters.AddWithValue("@type",type);
            ins_req.Parameters.AddWithValue("@amt", Convert.ToInt32(amt));
            ins_req.Transaction = trans;
            ins_req.ExecuteNonQuery();
            SqlCommand req_id = new SqlCommand("select @@identity", con);
            req_id.Transaction = trans;
            int reqid = Convert.ToInt32(req_id.ExecuteScalar());
            trans.Commit();
            return reqid;
        }
        catch
        {
            return -1;
        }
        finally
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                con.Close();
            }
                
        }
        
    }
   
   

}
