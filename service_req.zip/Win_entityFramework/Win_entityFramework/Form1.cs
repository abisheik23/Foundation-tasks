﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_entityFramework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        linqEntities dc = new linqEntities();

        private void btn_add_Click(object sender, EventArgs e)
        {
            Customer c = new Customer();
            c.customerName = tb_name.Text;
            c.customerAge = Convert.ToInt32(tb_age.Text);
            c.customerCity = tb_city.Text;

            dc.Customers.Add(c);
            dc.SaveChanges();
            MessageBox.Show("Customer ID:" + c.customerid);
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            var q = from cust in dc.Customers
                    select cust;

            gv_show.DataSource = q.ToList();
            
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            var q = from cust in dc.Customers
                    where cust.customerCity == tb_search.Text
                    select cust;

            List<Customer> list = q.ToList();
            gv_show.DataSource = list;
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            int custid = Convert.ToInt32(tb_cid.Text);
            var custobj = (from cust in dc.Customers
                           where cust.customerid == custid
                           select cust).FirstOrDefault();

            if (custobj == null)
            {
                MessageBox.Show("Customer Not Found");
            }
            else
            {
                custobj.customerName = "XYZ";
                //dc.Customers.Remove(custobj);
                dc.SaveChanges();
                MessageBox.Show("Deleted");
                /* tb_name.Text = custobj.customerName;
                tb_age.Text = custobj.customerAge.ToString();
                tb_city.Text = custobj.customerCity;*/
            }
        }
    }
}
