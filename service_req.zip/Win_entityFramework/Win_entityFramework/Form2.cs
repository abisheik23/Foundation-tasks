﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_entityFramework
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        linqEntities dc = new linqEntities();
        private void button1_Click(object sender, EventArgs e)
        {
            var data = dc.Customers.SqlQuery("Select * from Customers where CustomerCity=@p0",textBox1.Text).ToList();
            dg_data.DataSource = data;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int count = dc.Database.ExecuteSqlCommand("Update Customers set customername=@p0 where customerid=@p1", "abc", textBox1.Text);

            MessageBox.Show(count.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var data = dc.Database.SqlQuery<CustomerCityCount>
                ("select CustomerCity,count(*) as 'CustomerCount' from Customers group by CustomerCity").ToList();
            dg_data.DataSource = data;
        }
    }
}
