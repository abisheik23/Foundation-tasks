﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_entityAssign
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        linqEntities dc = new linqEntities();
        private void btn_add_Click(object sender, EventArgs e)
        {
            product p = new product();
            p.productname = tb_name.Text;
            p.productprice = Convert.ToInt32(tb_price.Text);
            p.productdescription = tb_desc.Text;
            p.productcategory = tb_cat.Text;

            dc.products.Add(p);
            dc.SaveChanges();
            MessageBox.Show("Product ID:"+p.productid);
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            int pid = Convert.ToInt32(tb_id.Text);
            var pobj = (from prd in dc.products
                        where prd.productid == pid
                        select prd).FirstOrDefault();
            if (pobj == null)
            {
                MessageBox.Show("No such Products");
            }
            else
            {
                tb_name.Text = pobj.productname;
                tb_price.Text = pobj.productprice.ToString();
                tb_desc.Text = pobj.productdescription;
                tb_cat.Text = pobj.productcategory;
            }
        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            var p = from prd in dc.products
                    select prd;

            dg_data.DataSource = p.ToList();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            var c = from prd in dc.products
                    where prd.productcategory == tb_search.Text
                    select prd;
            dg_data.DataSource = c.ToList();
        }
    }
}
