﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{

    public bool addAcc(Account acc)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
       
        try
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            SqlCommand com_ins = new SqlCommand("insert AccountDetails values(@cid,@type,GETDATE(),@bal,'BHJK0000568')", con);
            com_ins.Parameters.AddWithValue("@cid",acc.clientid);
            com_ins.Parameters.AddWithValue("@type",acc.acctype);
            com_ins.Parameters.AddWithValue("@bal",acc.amount);
            com_ins.Transaction = trans;
            com_ins.ExecuteNonQuery();
            SqlCommand com_del = new SqlCommand("delete from AccRequest where clientid=@cid", con);
            com_del.Parameters.AddWithValue("@cid", acc.clientid);
            com_del.Transaction = trans;
            com_del.ExecuteNonQuery();
            trans.Commit();
            return true;
        }
        catch
        {
            
            return false;
        }
        finally 
        {
            if (con.State == System.Data.ConnectionState.Open)
            {
                con.Close();
            }
        }
    }
}
