﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication2.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(int userid, string password)
        {
            if (userid == 1000 && password == "pass@123")
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View();
            }
        }


        public ActionResult NewUser(int userid, string password, string name, string city,HttpPostedFileBase filedata)
        {

            filedata.SaveAs(Server.MapPath("~/Images/" + userid + ".jpg"));
            List<SelectListItem> cities = new List<SelectListItem>();
            cities.Add(new SelectListItem { Text = "Chennai", Value = "1" });
            cities.Add(new SelectListItem { Text = "Delhi", Value = "2" });
            cities.Add(new SelectListItem { Text = "Mumbai", Value = "3" });
            cities.Add(new SelectListItem { Text = "Pune", Value = "4" });

            ViewBag.cities = cities;
            ViewBag.msg = "User Created";
            return View("Login");
        }
    }
}
