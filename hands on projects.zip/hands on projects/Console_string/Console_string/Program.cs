﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_string
{
    class Program
    {
        static void Main(string[] args)
        {


            int[][] jaggedarray = new int[3][];
            jaggedarray[0] = new int[2];
            jaggedarray[1] = new int[4];
            jaggedarray[2] = new int[1];

            jaggedarray[0][0] = 55;
            jaggedarray[0][1] = 66;

            jaggedarray[1][0] = 88;
            jaggedarray[1][1] = 55;
            jaggedarray[1][2] = 88;
            jaggedarray[1][3] = 55;

            jaggedarray[2][0] = 100;

            foreach (int[] array in jaggedarray)
            {
                foreach (int x in array)
                {
                    Console.WriteLine(x);
                }

            }

            /*string name = "abc";
            char[] chararray = { 'a', 'b', 'c' };
            object obj = new string(chararray);
            if (name == obj)
            {
                Console.WriteLine("==true");

            }
            else
            {
                Console.WriteLine("==false");
            }
            if (name.Equals(obj)) 
            {
                Console.WriteLine("Equals True");
            }
            else
            {
                Console.WriteLine("Equals false");
            }
            string str = "hello";
            string str1 = "abc";
            str = str1;
            str1 = "xyza";
            foreach (char ch in str)
            {
                Console.Write(ch);
            }*/
            Console.ReadKey();
        }
    }
}
