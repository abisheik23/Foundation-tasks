﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleCSharp_Day1
{
    class Program
    {
        static void Main(string[] args)
        {
            int marks = Convert.ToInt32(Console.ReadLine());
            bool status = true;
            double d = 22.25;
            string str = "Hello";
            /*  DateTime dt = DateTime.Now;
              DateTime dt1 = Convert.ToDateTime("12/12/2017");
              DateTime dt2 = dt.AddDays(45);
              Console.WriteLine(dt1);
              Console.WriteLine(dt2);
              Console.WriteLine(dt.ToString());
              TimeSpan t = dt2 - dt;
              Console.WriteLine(t.TotalHours);*/
            if (marks > 50)
            {
                Console.WriteLine("PASS!!!");
            }
            else
            {
                Console.WriteLine("FAIL|||");
            }
            int counter = 0;
            Console.WriteLine("While");
            while (counter < 10)
            {
                Console.WriteLine(counter);
                counter++;
            }

            Console.WriteLine("For Loop");
            for (int i = 0; i < 10; i++)
            {

                Console.WriteLine(i);
            }
            int[] marksarray = new int[5];
            Console.WriteLine("Arrays");
            for (int i = 0; i< marksarray.Length; i++) {
                marksarray[i] = Convert.ToInt32(Console.ReadLine());
            }
            foreach(int elements in marksarray)
            {
             Console.Write(elements+" ");
            }
            Console.ReadKey();
        }
    }
}