﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ado2
{
    public partial class Frm_mars : Form
    {
        public Frm_mars()
        {
            InitializeComponent();
        }

        private void btn_mars_Click(object sender, EventArgs e)
        {
            SqlConnection con = new 
                SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            con.Open();
            SqlCommand com_order = new SqlCommand("select * from orders", con);
            SqlDataReader dr_order = com_order.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr_order);
            dg_orders.DataSource = dt;
           
            SqlCommand com_items = new SqlCommand("Select * from orderdetails", con);
            SqlDataReader dr_items = com_items.ExecuteReader();
            con.Close();

        }
    }
}
