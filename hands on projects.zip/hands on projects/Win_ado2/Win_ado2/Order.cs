﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado2
{
    class Order
    {
        public int OrderID { get; set; }
        public string customername { get; set; }
        public DateTime OrderDate { get; set; }

        public List<Items> items = new List<Items>();
        public void AddItem(Items item)
        {
            items.Add(item);
        }
    }
}
