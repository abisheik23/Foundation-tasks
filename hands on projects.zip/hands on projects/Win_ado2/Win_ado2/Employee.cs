﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado2
{
    class Employee
    {
        public int employeeid { get; set; }
        public string employeepassword { get; set; }
        public string employeename { get; set; }
    }
}
