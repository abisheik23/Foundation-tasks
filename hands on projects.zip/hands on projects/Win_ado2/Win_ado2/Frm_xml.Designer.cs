﻿namespace Win_ado2
{
    partial class Frm_xml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_read = new System.Windows.Forms.Button();
            this.dg_orders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(54, 58);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(140, 52);
            this.btn_save.TabIndex = 0;
            this.btn_save.Text = "Save XML";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_read
            // 
            this.btn_read.Location = new System.Drawing.Point(54, 142);
            this.btn_read.Name = "btn_read";
            this.btn_read.Size = new System.Drawing.Size(140, 49);
            this.btn_read.TabIndex = 1;
            this.btn_read.Text = "Read XML";
            this.btn_read.UseVisualStyleBackColor = true;
            this.btn_read.Click += new System.EventHandler(this.btn_read_Click);
            // 
            // dg_orders
            // 
            this.dg_orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_orders.Location = new System.Drawing.Point(67, 220);
            this.dg_orders.Name = "dg_orders";
            this.dg_orders.Size = new System.Drawing.Size(351, 150);
            this.dg_orders.TabIndex = 2;
            // 
            // Frm_xml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 382);
            this.Controls.Add(this.dg_orders);
            this.Controls.Add(this.btn_read);
            this.Controls.Add(this.btn_save);
            this.Name = "Frm_xml";
            this.Text = "Frm_xml";
            ((System.ComponentModel.ISupportInitialize)(this.dg_orders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_read;
        private System.Windows.Forms.DataGridView dg_orders;
    }
}