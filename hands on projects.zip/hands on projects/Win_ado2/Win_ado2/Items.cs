﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado2
{
    class Items
    {
        public int orderid { get; set; }
        public int itemid { get; set; }
        public int itemqty { get; set; }
        public int itemprice { get; set; }
    }
}
