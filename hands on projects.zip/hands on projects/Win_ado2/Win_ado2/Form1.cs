﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_ado2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_order_Click(object sender, EventArgs e)
        {
            try
            {
                Order ord = new Order();
                ord.customername = tb_name.Text;

                Items item = new Items();
                item.itemid = Convert.ToInt32(tb_iid.Text);
                item.itemprice = Convert.ToInt32(tb_price.Text);
                item.itemqty = Convert.ToInt32(tb_qty.Text);

                ord.AddItem(item);
                OrdersDAL dal = new OrdersDAL();
                dal.AddOrder(ord);
                tb_oid.Text = ord.OrderID.ToString();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

    }
}
