﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace Win_ado2
{
    class EmployeeDAL
    {
        public bool login(Employee obj)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand com_login = new SqlCommand();
            com_login.Connection = con;
            com_login.CommandType = System.Data.CommandType.StoredProcedure;
            com_login.CommandText = "proc_login";
            SqlParameter para_empid = new SqlParameter("@empid", SqlDbType.Int);
            SqlParameter para_emppwd = new SqlParameter("@emppwd", SqlDbType.VarChar, 30);
            SqlParameter para_empname = new SqlParameter("@empname", SqlDbType.VarChar, 30);
            SqlParameter para_return = new SqlParameter();
            para_return.Direction = ParameterDirection.ReturnValue;
            para_empid.Value = obj.employeeid;
            para_emppwd.Value = obj.employeepassword;
            para_empname.Direction = ParameterDirection.Output;
            com_login.Parameters.Add(para_empid);
            com_login.Parameters.Add(para_empname);
            com_login.Parameters.Add(para_emppwd);
            com_login.Parameters.Add(para_return);

            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();

            int count = Convert.ToInt32(para_return.Value);
            if (count > 0)
            {
                obj.employeename = para_empname.Value.ToString();
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
