﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ado2
{
    class OrdersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void AddOrder(Order ord)
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();

                SqlCommand com_order = new SqlCommand("insert orders values(@custname,getdate())", con);
                com_order.Parameters.AddWithValue("@custname", ord.customername);
                com_order.Transaction = trans;
                com_order.ExecuteNonQuery();
                SqlCommand com_orderid = new SqlCommand("select @@identity", con);
                com_orderid.Transaction = trans;
                int orderid = Convert.ToInt32(com_orderid.ExecuteScalar());

                ord.OrderID = orderid;

                foreach (Items item in ord.items)
                {
                    SqlCommand com_item = new
                       SqlCommand("insert orderdetails values(@oid,@itemid,@itemqty,@itemprice)", con);
                    com_item.Parameters.AddWithValue("@oid", orderid);
                    com_item.Parameters.AddWithValue("@itemid", item.itemid);
                    com_item.Parameters.AddWithValue("@itemqty", item.itemqty);
                    com_item.Parameters.AddWithValue("@itemprice", item.itemprice);
                    com_item.Transaction = trans;
                    com_item.ExecuteNonQuery();
                }
                System.Windows.Forms.MessageBox.Show("Wait");
                trans.Commit();
            }

            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
