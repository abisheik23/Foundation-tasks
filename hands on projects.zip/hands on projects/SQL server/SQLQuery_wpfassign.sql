create database employee

use employee

create table employee(
employeeid int identity(1000,1) primary key,
employeename varchar(20),
employeeexp int,
employeepassword varchar(20),
employeedept varchar(20),
employeedesg varchar(20),
managerid int
)

create table leaverequest(
leaveid int identity(1,1) primary key,
employeeid int foreign key references employee(employeeid),
requestdate datetime,
leavedate date,
noofdays int,
leavetype varchar(30),
leavestatus varchar(30),
managerid int,
reason varchar(30)
)
alter table leaverequest add 
insert employee values('abc',2,'abc@123','R&D','analyst',1100)
drop table leaverequest

select * from leaverequest


create table questions(
QuestionID int identity(1,1) primary key,
Question varchar(100),
option1 varchar(10),
option2 varchar(10),
option3 varchar(10),
option4 varchar(10),
answer int
)
select * from questions
insert questions values('Which of the following known as the currency of japan ','yen','dollar','ruppees','kronos',1)
insert questions values('Which is birth place of einstein','USA','Italy','Germany','UK',3)
insert questions values('Who is sting','Astronaut','RockStar','Athelete','Engineer',2)
insert questions values('Which of the following places still have monarchy rule','USA','Italy','Germany','UK',4)