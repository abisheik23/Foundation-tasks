Create Database bank_db

use bank_db

create table customerinfo(
customerid int identity(100,1) primary key,
customername varchar(20),
customercity varchar(20),
customeraddress varchar(20),
customermobileno int unique,
panno varchar(10) unique,
customerpassword varchar(20)
)

create table accountinfo(
accountid int identity(1000,1) primary key,
customerid int foreign key references customerinfo(customerid),
acctype varchar(15),
balance int,
opendate date,
accstatus varchar(8) check (accstatus='open'or accstatus='closed' or accstatus='blocked')
)

create table transactioninfo(
transactionid int identity(13000,1) primary key,
accountid int foreign key references accountinfo(accountid),
transtype varchar(10)check (transtype='d' or transtype='c'),
amount int check(amount>0),
transactiondate date
)

sp_help customerinfo
sp_help accountinfo
sp_help transactioninfo
sp_rename 'accountinfo.type','acctype'
insert customerinfo values('abc','chennai','xyz',94010052,'tyrf9006pl','password')
insert customerinfo values('qwe','salem','zmnb',94110092,'lprk8456mn','drowssap')
insert customerinfo values('abi','cbe','poiut',90910907,'znby6879po','pass@123')

select * from customerinfo

insert accountinfo values(103,'savings',2500,'1/12/2014','open')
insert accountinfo values(104,'salary',15000,'7/26/2014','open')
insert accountinfo values(104,'savings',2500,'6/27/2015','open')
insert accountinfo values(105,'checking',15000,'9/26/2016','open')
insert accountinfo values(105,'salary',15000,'9/15/2014','open')
insert accountinfo values(104,'checking',50000,'2/5/2017','open')

insert accountinfo values(103,'savings',0,'2/6/2010','closed')
select * from accountinfo


insert transactioninfo values(1000,'c',5000,'2/7/2017')
insert transactioninfo values(1001,'c',15000,'7/30/2016')
insert transactioninfo values(1002,'d',2500,'6/26/2014')
insert transactioninfo values(1003,'d',25000,'1/1/2017')
insert transactioninfo values(1004,'c',35000,'2/3/2016')
insert transactioninfo values(1005,'c',4500,'2/6/2017')
insert transactioninfo values(1006,'d',7500,'6/5/2011')
insert transactioninfo values(1001,'d',15750,'4/6/2016')
insert transactioninfo values(1002,'c',12000,'2/16/2017')
insert transactioninfo values(1003,'c',13200,'1/7/2017')
insert transactioninfo values(1004,'d',15450,'1/9/2017')
insert transactioninfo values(1005,'d',15550,'2/11/2017')
insert transactioninfo values(1006,'c',15200,'6/16/2012')
insert transactioninfo values(1001,'c',5200,'2/6/2017')
insert transactioninfo values(1002,'d',3700,'9/1/2017')
insert transactioninfo values(1003,'d',45000,'10/3/2016')
insert transactioninfo values(1004,'c',50000,'2/13/2017')
insert transactioninfo values(1005,'c',6000,'2/15/2017')
insert transactioninfo values(1006,'d',75000,'12/6/2013')
insert transactioninfo values(1006,'d',25000,'11/3/2014')
insert transactioninfo values(1006,'c',80000,'6/7/2015')

create trigger calc on transactioninfo
for insert
as
declare @acctype varchar(10)
declare @accid int
declare @amount int
select @acctype=acctype,@accid=accountid,@amount=amount from inserted
if(@acctype='d')
begin
update accountinfo set balance-=@amount where accountid=@accid
end
else
begin
update accountinfo set balance+=@amount where accountid=@accid
end

truncate table transactioninfo
select top 10 * from transactioninfo where DATEPART(YYYY,transactiondate)=DATEPART(YYYY,GETDATE())

select * from transactioninfo where transactiondate between '6/26/2014' and '10/3/2016'

select accountid,customerid from accountinfo where customerid in (select customerid from customerinfo)

select customerid,customername from customerinfo where customerid in (select customerid from accountinfo group by customerid having COUNT(accountid)>1)  

select accountid,count(transactionid) as 'Transactions' from transactioninfo group by accountid having COUNT(transactionid)>1 

select accountid,count(transactionid) as 'Transactions' from transactioninfo group by accountid having COUNT(transactionid)<=1 

select customerinfo.customerid,customerinfo.customername,
accountinfo.accountid,accountinfo.balance 
from customerinfo join accountinfo
on customerinfo.customerid=accountinfo.customerid

select distinct accountinfo.accountid,accountinfo.balance,
count(transactioninfo.transactionid)"No of Transactions"
from accountinfo join transactioninfo 
on
transactioninfo.accountid=accountinfo.accountid group by accountinfo.accountid,accountinfo.balance

create procedure checkaccbal(@accid int)
as
begin
select balance from accountinfo where accountid=@accid
end
select * from accountinfo

exec checkaccbal 1002

alter procedure checkstatus(@custid int,@cuspass varchar(20))
as 
begin
select accountid,accstatus from accountinfo where customerid in(select customerid from customerinfo where customerid=@custid and customerpassword=@cuspass)
end

exec checkstatus 103,'password'
