create table products(
Productid int identity(1000,1) primary key,
productname varchar(30),
productprice int,
productimageaddress varchar(100)
)

insert products values('xyz',2500,null)
--~/xyz/10
delete products where Productid=1000
select * from products
drop table Employees
create table Employees(
Employeeid int identity(2000,1) primary key,
employeename varchar(30),
employeeage int,
employeeexp int,
employeedept varchar(30),
employeesalary int
)

insert employees values('abc',25,1,'Security',35000)
insert employees values('mnbvb',27,3,'Programmer',45000)
insert employees values('jkshfdi',35,8,'Human Resource',45000)
insert employees values('dfdg',28,6,'Manager',35750)
insert employees values('xgfs',24,2,'Testing',25000)
insert employees values('gff',25,1,'ERT',35000)

create table leaverequest(
leaveid int identity(1,1) primary key,
employeeid int foreign key references employees(employeeid),
requestdate datetime,
leavedate date,
noofdays int,
leavetype varchar(30),
leavestatus varchar(30),
managerid int,
reason varchar(30)
)