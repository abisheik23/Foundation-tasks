Create Database InautixJan2017

use InautixJan2017

Create Table Customers
(
CustomerID int,
CustomerName varchar(20),
CustomerCity varchar(30),
CustomerAge int
)

sp_help Customers

insert Customers values(1001,'ABC','Chennai',25)
insert Customers values(1003,'ABCD',null,26)
insert Customers(CustomerName,CustomerID) values('John',1004)
Select * from Customers

update Customers set CustomerCity='Chennai' where CustomerID=1002
update Customers set CustomerCity='Chennai',CustomerAge=25 where CustomerID=1004
delete Customers where CustomerID=1001

drop table Customers


alter table Customers add CustomerContactNo varchar(12)
alter table Customers drop column CustomerContactNo

alter table Customers alter column CustomerName varchar(50)

sp_rename 'Customers','CustomersInfo'
sp_rename 'CustomersInfo','Customers'

sp_rename 'Customers.CustomerCity','CustomerAddress'

select * from Customers

Create Table Employees(
EmployeeID int,
EmployeeName varchar(30),
EmployeeCity varchar(30),
EmployeeDOJ DateTime,
EmployeeSalary int
)

Insert Employees values(1002,'John','Mumbai','01/15/2017',30000)
Insert Employees values(1003,'Mark','Pune','01/15/2014',40000)
Insert Employees values(1004,'Brian','New York','01/15/2017',30000)
Insert Employees values(1005,'ABI','coimbatore','01/18/2017',30000)

select * from Employees

Select EmployeeID,'Name :'+EmployeeName from Employees

Select EmployeeID,EmployeeName+','+EmployeeCity as 'EmpDetails' from Employees

select * from Employees where EmployeeCity='Chennai' and EmployeeSalary>20000

select * from Employees where EmployeeCity in ('Chennai','Mumbai')
select * from Employees where EmployeeSalary between 18000 and 30000

select * from Employees order by EmployeeCity desc,EmployeeSalary asc

select * from Employees order by EmployeeSalary desc
select * from Employees order by EmployeeSalary desc
select top 2 with ties * from Employees order by EmployeeSalary desc
 
 select LEN('Hello')
 select SUBSTRING('hello',1,4)
 select LTRIM('hello')
 select RTRIM('hello')
 select LOWER('HELLO')
 select UPPER('hello')
 select LEFT('hello',2)
 select RIGHT('hello',2)
 select ISNUMERIC('12a')
 select CEILING(25.01)
 select FLOOR(25.99)
 select ROUND(253.2595,2)
 Select ISNULL(EmployeeID,0) from Employees
 select SUM(employeesalary) as 'Total Salary' from Employees
 
 select SUM(employeesalary) as 'Total Salary' from Employees where EmployeeCity='Chennai'
 
 select AVG(Employeesalary) from Employees
 select Min(Employeesalary) from Employees
 select COUNT(*) from Employees
 
 select GETDATE()
 Insert Employees values(1006,'Smith','CleveLand',GETDATE(),50000)
 
 select * from Employees
 
 select DATEADD(MM,20,GETDATE())
 
 select DATEADD(DD,20,GETDATE())
 
 select employeeid,employeename,DATEDIFF(MM,EmployeeDOJ,GETDATE()) as 'Years Exp' from Employees
 select employeeid,employeename,DATename(DW,EmployeeDOJ) from Employees
 select CONVERT(varchar(20),EmployeeID)+',' from Employees
 
 select CAST(employeeid as varchar(20))+','+EmployeeName from Employees
 
 select CONVERT (varchar(20),GETDATE(),1)
 
 
 Select EmployeeCity,Count(*)as 'No of Employees' from Employees group by EmployeeCity having COUNT(*)>1
 update Employees set EmployeeCity='Chennai' where EmployeeID=1002

Select employeeid,Employeesalary,ROW_NUMBER() over (order by employeesalary desc) from Employees
Select employeeid,Employeesalary,RANK() over (order by employeesalary desc) from Employees

Select employeeid,Employeesalary,dense_Rank() over (order by employeesalary desc) from Employees


Create table orders(
orderid int identity(1000,1),
customerName varchar(30),
itemName varchar(30),
itemqty int,
itemprice int
)
insert orders values('Smith','Mobile',1,20000)
select * from orders

select @@IDENTITY

select * from orders

Create table items(
itemid int identity(1000,1) primary key,
itemname varchar(30) not null,
itemprice int check(itemprice>0)
)
Insert Items values('Lg mobile',15000)
insert items values('lava Mobile',40000)
select * from items

create table customerinfo(
CustomerID int identity(1,1) primary key,
customername varchar(30) not null,
customercity varchar(30) not null
)
Insert customerinfo values('john','chennai')
insert customerinfo values('xyz','pune')
Insert customerinfo values('abc','mumbai')
insert customerinfo values('bny','kolkata')
insert customerinfo values('qwer','delhi')
insert customerinfo values('qwe','jaipur')
insert customerinfo values('wert','amritsar')
select * from customerinfo

create table invoices(
invoiceid int identity(10000,1) primary key,
customerid int foreign key references CustomerInfo(customerId),
Invoicedate date,
invoiceAddress varchar(30) not null,
customercontactno varchar(15) not null 
)

insert invoices values(1,'2/2/2017','pune','7895566')
insert invoices values(2,'2/2/2017','chennai','98765412')
insert invoices values(3,'2/2/2017','mumbai','55872642')
insert invoices values(4,'2/2/2017','pune','75565472')
insert invoices values(5,'2/2/2017','COIMBATORE','45422642')
insert invoices values(6,'2/2/2017','jaipur','755555472')
insert invoices values(7,'2/2/2017','amritsar','7554472')
create table invoicedetails(
InvoiceId int foreign key references invoices(invoiceId),
itemid int foreign key references items(itemid),
itemqty int check (itemqty>0)
primary key(invoiceid,itemid)
)

insert invoicedetails values(10000,1001,25)
insert invoicedetails values(10001,1000,30)
insert invoicedetails values(10002,1001,78)
insert invoicedetails values(10003,1000,6)
insert invoicedetails values(10004,1001,45)
insert invoicedetails values(10006,1000,12)
insert invoicedetails values(10009,1001,45)
select * from items
select * from customerinfo
select * from invoices
select * from invoicedetails

select * from customerinfo where CustomerID in( 
select distinct customerid from invoices group by customerid having COUNT(*)>1
)

select * from items where itemid in(
select top 1 with ties itemid from invoicedetails where InvoiceId in(
 select InvoiceId from invoices where DATENAME(YYYY,Invoicedate)=DATEPART(YYYY,GETDATE())
) group by itemid order by SUM(itemqty) desc
)
update Employees set employeedept='technical' where EmployeeID=1001
update Employees set employeedept='hr' where EmployeeID=1002
update Employees set employeedept='accounts' where EmployeeID=1003
update Employees set employeedept='accounts' where EmployeeID=1004
update Employees set employeedept='technical' where EmployeeID=1005
update Employees set employeedept='hr' where EmployeeID=1006

select * from Employees
select * from Employees e1 where e1.EmployeeSalary>(
select avg(EmployeeSalary) from Employees e2 
where e2.EmployeeCity=e1.EmployeeCity
)

select * from customerinfo

select * from invoices

select * from(
select customerinfo.CustomerID,customerinfo.customername,
invoices.invoiceid,invoices.Invoicedate,invoicedetails.itemid,items.itemprice
from customerinfo join invoices 
on 
customerinfo.CustomerID=invoices.customerid
join 
invoicedetails
on 
invoices.invoiceid=invoicedetails.InvoiceId
join 
items on 
items.itemid=invoicedetails.itemid
)as x order by x.itemprice desc

select customerinfo.CustomerID,customerinfo.customername,count(invoices.invoiceid)as 'No of Invoices' 
from customerinfo 
join
invoices
on 
customerinfo.CustomerID=invoices.customerid
group by customerinfo.CustomerID,customerinfo.customername

select customerid,COUNT(*) as 'No of Invoices' from invoices group by customerid

select customerinfo.CustomerID,customerinfo.customername,invoices.invoiceid,invoices.Invoicedate 
from customerinfo 
full outer join invoices
on 
customerinfo.CustomerID=invoices.customerid

select * from customerinfo cross join invoices

create table employeeinfo(
employeeid int identity(1000,1) primary key,
employeename varchar(30),
employeecity varchar(30),
mangerid int
)

insert employeeinfo values('A','chennai',null)
insert employeeinfo values('B','chennai','1000')
insert employeeinfo values('C','chennai','1000')
insert employeeinfo values('D','chennai','1001')

select * from employeeinfo

select e.employeeid,e.employeename,m.employeename as 'manger name' from employeeinfo e join employeeinfo m on e.employeeid=m.employeeid

select * from invoices

select * into invoices_copy from invoices

select * from(
select * from invoices
union all
select * from invoices_copy
)
as x 
order by x.invoiceid desc

--TSQL

declare @count int
set @count=0
while(@count < 10)
begin
select @count 
set @count=@count+1
end
if(@count>5)
begin 
select 'True'
end
else
begin
select 'False'
end

create procedure sp_getcustomerdetails 
as
begin
select customerinfo.CustomerID,customerinfo.customername,
invoices.invoiceid,invoices.Invoicedate,invoicedetails.itemid,items.itemprice
from customerinfo join invoices 
on 
customerinfo.CustomerID=invoices.customerid
join 
invoicedetails
on 
invoices.invoiceid=invoicedetails.InvoiceId
join 
items on 
items.itemid=invoicedetails.itemid
end

alter procedure sp_getcustomerdetails(@customerid int) 
as
begin
select customerinfo.CustomerID,customerinfo.customername,
invoices.invoiceid,invoices.Invoicedate,invoicedetails.itemid,items.itemprice
from customerinfo join invoices 
on 
customerinfo.CustomerID=invoices.customerid
join 
invoicedetails
on 
invoices.invoiceid=invoicedetails.InvoiceId
join 
items on 
items.itemid=invoicedetails.itemid
where customerinfo.CustomerID=@customerid
end

exec sp_getcustomerdetails 1

create table customersdetails(
customerid int identity(1000,1) primary key,
customername varchar(30),
customerage int,
customerpassword varchar(30)
)

insert customersdetails values('A',25,'pass@123')
insert customersdetails values('B',30,'admin@123')

select * from customersdetails;

select * from customersdetails where customerid=1001 and customerpassword='pass@123'

create table customerslogin(
customerid int,
logindt datetime,
)
create procedure sp_getCustomersDetails(@custid int ,@custname varchar(30) output,@custage int output)
as
begin
select @custname=CustomerName,@custage=customerage from customersdetails where customerid=@custid
end

declare @customername varchar(30) 
declare @customerage int
exec sp_getcustomersdetails 1000,@customername output,
@customerage output
select @customername,@customerage 

create trigger trg_customerdetails_insert on customersdetails 
for insert
as
begin
select 'Trigger Fired'
end

insert customersDetails values('c','25','pass@123')

create table stock(
itemid int,
stockqty int,
)
insert stock values(1000,100)
insert stock values(1001,100)

select * from stock

create table ordersinfo(
customersName varchar(30),
itemid int,
itemqty int
)
insert ordersinfo values('A',1001,500)

alter trigger trg_orders_stock_update
on OrdersInfo
for insert
as
begin
declare @itemid int
declare @itemqty int
select @itemid=itemid,@itemqty=itemqty from inserted
update stock set stockqty-=@itemqty where itemid=@itemid
declare @stockqty int
select @stockqty=stockqty from stock where itemid=@itemid
if(@stockqty<0)
begin
rollback tran
end
end

select * from ordersinfo

sp_helptrigger ordersinfo