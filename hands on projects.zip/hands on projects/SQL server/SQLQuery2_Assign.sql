Create database emp_db
use emp_db
create table employees(
employeeid int,
employeefname varchar(20),
employeelname varchar(20),
employeecity varchar(20),
employeeage varchar(20),
employeesalary int
)
alter table Employees add employeedept varchar(12)
alter table Employees add employeedoj date

insert employees values(1001,'mark','roberts','chennai','30',30000,'accounts','1/12/2012')
insert employees values(1002,'sam','kapoor','pune','27',20000,'sales','3/28/2016')
insert employees values(1003,'abc','xyz','mumbai','35',35000,'technical','5/5/2013')
insert employees values(1004,'sunder','p','kanpur','22',28000,'security','6/18/2015')
insert employees values(1005,'sanjay','b','bangalore','26',30000,'sales','8/15/2016')
insert employees values(1006,'rekha','r','new delhi','45',50000,'technical','12/1/2014')
insert employees values(1007,'john','cena','chennai','33',20000,'sales','12/1/2016')
insert employees values(1008,'gokul','t','hydrabad','25',40000,'sales','12/1/2015')
insert employees values(1009,'kathick','m','mumbai','29',20000,'accounts','12/1/2017')
insert employees values(1010,'latha','p','chennai','31',45000,'accounts','12/1/2016')
select * from employees
select * from employees where employeecity='chennai'

select * from employees where employeesalary between 25000 and 50000

select employeefname+employeelname as 'employeefullname',employeeid,employeecity from employees

select SUM(employeesalary)as 'Sum of salary' from employees

select COUNT(*) as 'Total no of employees' from employees

select * from employees where DATENAME(MONTH,employeedoj)='January'

select * from employees where DATEDIFF(YY,Employeedoj,GETDATE())=5

select distinct employeedept,COUNT(employeeid)from employees group by employeedept

select distinct employeecity,COUNT(employeeid)from employees group by employeecity

update employees set employeecity='pune' where employeecity='chennai'

select distinct employeedept,SUM(employeesalary) from employees group by employeedept having SUM(employeesalary)>50000

delete employees where employeedept='security'

select * from employees;

drop table employees



