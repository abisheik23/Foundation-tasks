Create database inautixjan2017ado

use InautixJan2017ado

create table employees(
 employeeid int identity(1000,1) primary key,
 employeename varchar(30),
 employeecity varchar(30),
 employeeage int,
 employeepassword varchar(30)
)

create Table Cities(
cityID int identity(1,1),
CityName varchar(30)
)
insert Cities values('chennai');
insert Cities values('pune');
insert Cities values('delhi');
insert Cities values('Mumbai');

select * from employees


create table orders(
OrderID int identity(1000,1) primary key,
customername varchar(30),
orderdate date
)
create table orderdetails(
OrderID int foreign key references Orders(OrderID),
itemid int,
itemqty int,
itemprice int,
)
select * from orderdetails

create procedure proc_login(@empid int,@emppwd varchar(30),@empname varchar(30) output)
as
begin 
declare @count int 
select @count=COUNT(*) from employees
where employeeid=@empid and employeepassword=@emppwd
if(@count>0)
begin 
select @empname=employeename from employees
where employeeid=@empid
end
return @count
end