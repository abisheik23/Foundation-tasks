Create Database wpf_db

use wpf_db

Create Table Products(
ProductID int identity(1000,1) primary key,
ProductName varchar(30),
ProductPrice int
)

Insert Products values('LG Mobiles',25000)
Insert Products values('Dell Laptop',40000)
Insert Products values('Lenovo',60000)
Insert Products values('Samsung tv',70000)
Insert Products values('ipod',5000)

create Table Orders(
orderid int identity(10000,1) primary key,
customerid int,
orderdate datetime,
orderaddress varchar(30),
productid int foreign key references products(productid),
productprice int,
productqty int
)

create table customers(
customerid int identity(1,1) primary key,
customername varchar(30),
customeremail varchar(50),
customerPassword varchar(30)
)
insert customers values('John','john@g.com','pass@123')
insert customers values('admin','admin@g.com','admin@123')

select * from Orders