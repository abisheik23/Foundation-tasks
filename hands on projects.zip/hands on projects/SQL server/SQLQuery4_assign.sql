create database db
use db

create table Employees(
employeeid int identity(1000,1) primary key,
employeename varchar(30),
employeepassword varchar(30)
)
insert Employees values('abc','pass@123');
insert Employees values('bny','mellon');

Create table Customerinfo(
customerid int identity(13000,3) primary key,
customername varchar(30),
customercity varchar(30),
customerage int,
customerdoj date
)

create table cities(
cityid int identity(1,1) primary key,
cityname varchar(30)
)

insert cities values('chennai');
insert cities values('coimbatore');
insert cities values('Bangalore');
insert cities values('Kolkata');
insert cities values('pune');
insert cities values('Mumbai');
insert cities values('new Delhi');

select * from cities;

select * from Customerinfo;