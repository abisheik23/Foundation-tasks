﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sal_library
{
    public class salary
    {
        double dsal;
        int days;

        public salary(double dsal,int days)
        {
            this.dsal=dsal;
            this.days = days;
        }
        public double getSalary(double dsal, int days)
        {
            return dsal * days;
        }
    }
}
