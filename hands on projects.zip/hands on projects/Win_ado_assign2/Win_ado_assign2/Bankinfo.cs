﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado_assign2
{
    class Bankinfo
    {
        public int transid { get; set; }
        public int accno { get; set; }
        public int amount { get; set; }
        public DateTime transdate { get; set; }

      
    }
}
