﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ado_assign2
{
    class TicketsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["tickets"].ConnectionString);
        public void AddTrans(Bankinfo ban,ticketsinfo tickets)
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();

            SqlCommand tic_bank = new SqlCommand("insert bankinfo values(@accno,@amt,getdate())",con);
            tic_bank.Parameters.AddWithValue("@accno",ban.accno);
            tic_bank.Parameters.AddWithValue("@amt", ban.amount);
            tic_bank.Transaction = trans;
            tic_bank.ExecuteNonQuery();
            SqlCommand tic_trid=new SqlCommand("select @@identity",con);
            tic_trid.Transaction = trans;
            int trid = Convert.ToInt32(tic_trid.ExecuteScalar());
            ban.transid = trid;

       
                SqlCommand ban_tic = new
                   SqlCommand("insert ticketinfo values(@mname,@mdate,@time,@no,@transid,getdate())", con);
                ban_tic.Parameters.AddWithValue("@mname", tickets.moviename);
                ban_tic.Parameters.AddWithValue("@mdate", tickets.moviedate);
                ban_tic.Parameters.AddWithValue("@time", tickets.timings);
                ban_tic.Parameters.AddWithValue("@no", tickets.nooftickets);
                ban_tic.Parameters.AddWithValue("@transid", trid);
                ban_tic.Transaction = trans;
                ban_tic.ExecuteNonQuery();

                SqlCommand ban_tid = new SqlCommand("select @@identity", con);
                ban_tid.Transaction = trans;
                int tid = Convert.ToInt32(ban_tid.ExecuteScalar());
                tickets.ticketno = tid;
       
            trans.Commit();
        }
    }
}
