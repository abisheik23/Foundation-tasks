﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado_assign2
{
    class ticketsinfo
    {
        public int ticketno { get; set; }
        public string moviename { get; set; }
        public DateTime moviedate { get; set; }
        public string timings { get; set; }
        public int nooftickets { get; set; }
        public DateTime ticketdate { get; set; }
    }
}
