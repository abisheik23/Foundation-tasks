﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_ado_assign2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            tb_accno.Text = "";
            tb_amt.Text = "";
            tb_mdate.Text = "";
            tb_tid.Text = "";
            tb_tno.Text = "";
            tb_mname.Text = "";
            cb_ntickets.SelectedIndex = -1;
            cb_time.SelectedIndex = -1;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_ntickets.Items.Add("1");
            cb_ntickets.Items.Add("2");
            cb_ntickets.Items.Add("3");
            cb_ntickets.Items.Add("4");
            cb_ntickets.Items.Add("5");
            cb_ntickets.Items.Add("6");
            cb_ntickets.Items.Add("7");
            cb_ntickets.Items.Add("8");
            cb_ntickets.Items.Add("9");
            cb_ntickets.Items.Add("10");


            cb_time.Items.Add("11:00 am");
            cb_time.Items.Add("1:00 pm");
            cb_time.Items.Add("4:00 pm");
            cb_time.Items.Add("7:00 pm");
            cb_time.Items.Add("10:30 pm");

        }

        private void btn_book_Click(object sender, EventArgs e)
        {
            Bankinfo ban = new Bankinfo();
            
            ban.accno=Convert.ToInt32(tb_accno.Text);
            ban.amount = Convert.ToInt32(tb_amt.Text);

            ticketsinfo tic = new ticketsinfo();
            
            tic.moviename = tb_mname.Text;
            tic.moviedate = Convert.ToDateTime(tb_mdate.Text);
            tic.timings = cb_time.Text;
            tic.ticketno = Convert.ToInt32(cb_ntickets.Text);

            
            TicketsDAL dal = new TicketsDAL();
            dal.AddTrans(ban,tic);
            tb_tno.Text = tic.ticketno.ToString();
            tb_tid.Text = ban.transid.ToString();

        }


        
    }
}
