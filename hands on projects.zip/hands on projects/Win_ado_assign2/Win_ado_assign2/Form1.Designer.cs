﻿namespace Win_ado_assign2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tb_tid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_accno = new System.Windows.Forms.TextBox();
            this.l = new System.Windows.Forms.Label();
            this.tb_amt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_tno = new System.Windows.Forms.TextBox();
            this.tb_mname = new System.Windows.Forms.TextBox();
            this.cb_time = new System.Windows.Forms.ComboBox();
            this.cb_ntickets = new System.Windows.Forms.ComboBox();
            this.btn_book = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.tb_mdate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // tb_tid
            // 
            this.tb_tid.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.tb_tid.Location = new System.Drawing.Point(125, 34);
            this.tb_tid.Name = "tb_tid";
            this.tb_tid.Size = new System.Drawing.Size(100, 20);
            this.tb_tid.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Account No:";
            // 
            // tb_accno
            // 
            this.tb_accno.Location = new System.Drawing.Point(125, 65);
            this.tb_accno.Name = "tb_accno";
            this.tb_accno.Size = new System.Drawing.Size(100, 20);
            this.tb_accno.TabIndex = 3;
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.Location = new System.Drawing.Point(16, 106);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(52, 13);
            this.l.TabIndex = 4;
            this.l.Text = "Amount : ";
            // 
            // tb_amt
            // 
            this.tb_amt.Location = new System.Drawing.Point(125, 103);
            this.tb_amt.Name = "tb_amt";
            this.tb_amt.Size = new System.Drawing.Size(100, 20);
            this.tb_amt.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Transaction ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Ticket Number:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Movie Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Movie Date:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 262);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Timings:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Number of Tickets:";
            // 
            // tb_tno
            // 
            this.tb_tno.Location = new System.Drawing.Point(125, 141);
            this.tb_tno.Name = "tb_tno";
            this.tb_tno.Size = new System.Drawing.Size(100, 20);
            this.tb_tno.TabIndex = 16;
            // 
            // tb_mname
            // 
            this.tb_mname.Location = new System.Drawing.Point(125, 181);
            this.tb_mname.Name = "tb_mname";
            this.tb_mname.Size = new System.Drawing.Size(100, 20);
            this.tb_mname.TabIndex = 17;
            // 
            // cb_time
            // 
            this.cb_time.FormattingEnabled = true;
            this.cb_time.Location = new System.Drawing.Point(122, 262);
            this.cb_time.Name = "cb_time";
            this.cb_time.Size = new System.Drawing.Size(72, 21);
            this.cb_time.TabIndex = 18;
            // 
            // cb_ntickets
            // 
            this.cb_ntickets.FormattingEnabled = true;
            this.cb_ntickets.Location = new System.Drawing.Point(122, 303);
            this.cb_ntickets.Name = "cb_ntickets";
            this.cb_ntickets.Size = new System.Drawing.Size(35, 21);
            this.cb_ntickets.TabIndex = 20;
            // 
            // btn_book
            // 
            this.btn_book.Location = new System.Drawing.Point(331, 341);
            this.btn_book.Name = "btn_book";
            this.btn_book.Size = new System.Drawing.Size(108, 23);
            this.btn_book.TabIndex = 21;
            this.btn_book.Text = "Book";
            this.btn_book.UseVisualStyleBackColor = true;
            this.btn_book.Click += new System.EventHandler(this.btn_book_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(464, 341);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(101, 23);
            this.btn_clear.TabIndex = 22;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // tb_mdate
            // 
            this.tb_mdate.Location = new System.Drawing.Point(122, 214);
            this.tb_mdate.Name = "tb_mdate";
            this.tb_mdate.Size = new System.Drawing.Size(103, 20);
            this.tb_mdate.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 391);
            this.Controls.Add(this.tb_mdate);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_book);
            this.Controls.Add(this.cb_ntickets);
            this.Controls.Add(this.cb_time);
            this.Controls.Add(this.tb_mname);
            this.Controls.Add(this.tb_tno);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_amt);
            this.Controls.Add(this.l);
            this.Controls.Add(this.tb_accno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_tid);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_tid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_accno;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.TextBox tb_amt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_tno;
        private System.Windows.Forms.TextBox tb_mname;
        private System.Windows.Forms.ComboBox cb_time;
        private System.Windows.Forms.ComboBox cb_ntickets;
        private System.Windows.Forms.Button btn_book;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.TextBox tb_mdate;
    }
}

