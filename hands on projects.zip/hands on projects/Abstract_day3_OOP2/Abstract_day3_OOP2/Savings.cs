﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_day3_OOP2
{
    class Savings:Account
    {
        public Savings(int AccountID, string CustomerName, int accountbalance)
            : base(AccountID, CustomerName, accountbalance)
        {
        }
        public override bool Withdraw(int amt)
        {
            if ((AccountBal - amt) >= 500)
            {
                AccountBal = AccountBal - amt;
                return true;
            }
            else
            {
                return false;
            }

        }
        public override bool Deposit(int amt)
        {
            AccountBal = AccountBal + amt + 1000;
            return true;
        }
    }
}
