﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_day3_OOP2
{
    abstract class Account
    {
        protected int AccountID;
        protected string CustomerName;
        protected int AccountBal;
        public Account(int AccountID, string CustomerName, int AccountBal)
        {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBal = AccountBal;
        }
        public void StopPayment() 
        {
            Console.WriteLine("stop Payment");
        }
        public int GetBalance()
        {
            return AccountBal;
        }
        public void GetStatement()
        {
            Console.WriteLine("Bank Statement");
        }
        public abstract bool Withdraw(int amt);
        public abstract bool Deposit(int amt);


    }
}
