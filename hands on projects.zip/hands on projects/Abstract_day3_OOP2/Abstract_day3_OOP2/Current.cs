﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_day3_OOP2
{
    class Current:Account
    {
         public Current(int AccountID, string CustomerName, int accountbalance)
            : base(AccountID, CustomerName, accountbalance)
        {
        }
        public override bool Withdraw(int amt)
        {
            AccountBal = AccountBal - amt;
            return true;
        }
        public override bool Deposit(int amt)
        {
            AccountBal = AccountBal + amt;
            return false;
        }
    }
}
