﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_day3_OOP2
{
    class Program
    {
        static void Main(string[] args)
        {
         Console.Write("Enter the Account ID:");
         int accid=Convert.ToInt32(Console.ReadLine());
         Console.Write("Enter the Customer Name:");
         string cusname = Console.ReadLine();
         Console.Write("Enter the Account balance:");
         int accbal = Convert.ToInt32(Console.ReadLine());
         Console.Write("Enter the Account Type:");
         string type = Console.ReadLine();
         Account obj;
         if (type == "Savings" || type == "savings")
         {
             obj = new Savings(accid, cusname, accbal);
         }
         else
         {
             obj = new Current(accid,cusname,accbal);
         }
         int bal = obj.GetBalance();
         Console.WriteLine("Balance:" + bal);
         obj.Deposit(2500);
         bal = obj.GetBalance();
         Console.WriteLine("Balance:" + bal);
         obj.Withdraw(2000);
            bal=obj.GetBalance();
            Console.WriteLine("Balance:"+bal);
            obj.StopPayment();
            Console.ReadKey();
        }
    }
}
