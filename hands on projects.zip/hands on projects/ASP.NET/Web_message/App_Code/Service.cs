﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
	

    public void UpdateData(string UserID)
    {
        System.Threading.Thread.Sleep(20000);
    }

    public void SendRequest(string UserID)
    {
        ICallBack client_ref = OperationContext.Current.GetCallbackChannel<ICallBack>();
        client_ref.ReceiveData("One:" + DateTime.Now.ToString());

        System.Threading.Thread.Sleep(3000);
        client_ref.ReceiveData("Two :" + DateTime.Now.ToString());

        System.Threading.Thread.Sleep(3000);
        client_ref.ReceiveData("Three :" + DateTime.Now.ToString());

        System.Threading.Thread.Sleep(3000);
        client_ref.ReceiveData("Four :" + DateTime.Now.ToString());
    }
}
