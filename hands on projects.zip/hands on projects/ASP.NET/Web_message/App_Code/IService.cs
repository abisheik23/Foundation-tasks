﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
[ServiceContract(CallbackContract=typeof(ICallBack))]
public interface IService
{
    [OperationContract(IsOneWay=true)]
    void SendRequest(string UserID);

    
}

public interface ICallBack
{
    [OperationContract(IsOneWay = true)]
    void ReceiveData(string str);
}
