﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{

    [OperationBehavior(TransactionScopeRequired = true)]
    public int PlaceOrder(int ProductID, int ProductPrice, int TransID, string BankName)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand com_products = new SqlCommand("Insert ProductOrders values(@pid,@price,@tid,@name,getdate())", con);
        com_products.Parameters.AddWithValue("@pid", ProductID);
        com_products.Parameters.AddWithValue("@price",ProductPrice);
        com_products.Parameters.AddWithValue("@tid",TransID);
        com_products.Parameters.AddWithValue("@name", BankName);
        con.Open();
        com_products.ExecuteNonQuery();
        SqlCommand com_oid = new SqlCommand("Select @@identity", con);
        int oid = Convert.ToInt32(com_oid.ExecuteScalar());
        con.Close();
        return oid;
    }
}
