﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Caching;

public partial class Default_XMLData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_show_Click(object sender, EventArgs e)
    {
        if (Cache["employees"] == null)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(MapPath("~/Employees.xml"));
            gv_employees.DataSource = ds.Tables[0];
            gv_employees.DataBind();
            Label1.Text = "data from file";
            CacheDependency dep = new CacheDependency(MapPath("~/Employees.xml"));
            Cache.Insert("employees", ds, dep);
        }
        else
        {
            DataSet ds = Cache["employees"] as DataSet;
            gv_employees.DataSource = ds.Tables[0];
            gv_employees.DataBind();
            Label1.Text = "Data from Cache";
        }
    }
}