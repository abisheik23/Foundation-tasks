﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_DataCaching : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_show_Click(object sender, EventArgs e)
    {

        if (Cache["product"] == null)
        {
            Product p = new Product();
            p.ProductID = 100;
            p.ProductName = "Mobile";
            p.Productprice = 15000;

            Cache.Insert("product", p, null, DateTime.Now.AddSeconds(20), TimeSpan.Zero);
            btn_show.Text = "Data from DAL";
            lb_pid.Text = p.ProductID.ToString();
            lb_pname.Text = p.ProductName;
            lb_price.Text = p.Productprice.ToString();
        }
        else
        {
            Product p = Cache["product"] as Product;
            
            btn_show.Text = "Data from Cache";

            lb_pid.Text = p.ProductID.ToString();
            lb_pname.Text = p.ProductName;
            lb_price.Text = p.Productprice.ToString();
        }
    }
}