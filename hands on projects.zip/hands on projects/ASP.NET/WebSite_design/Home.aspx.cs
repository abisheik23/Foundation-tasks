﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            dd_city.Items.Add("Select");
            dd_city.Items.Add("Chennai");
            dd_city.Items.Add("Mumbai");
            dd_city.Items.Add("Pune");
            dd_city.Items.Add("Delhi");
        }
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        //DAL
        //EmployeeID
        //textbox.text=employeeid
        fu_image.SaveAs(MapPath("~/Images/" + tb_id.Text + ".jpg"));
        Response.Write("<script>alert('Employee Added Successfully');</script>");
    }
}