﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lst_cities.Items.Add("Pune");
            lst_cities.Items.Add("Mumbai");
            lst_cities.Items.Add("Chennai");
        }
    }
   
   protected void lst_cities_SelectedIndexChanged(object sender, EventArgs e)
    {
        lb1_city.Text = lst_cities.Text;
    }
    protected void btn_test_Click(object sender, EventArgs e)
    {
        lb_text.Text = "Hello From .NET";
    }
    protected void btn_next_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Home.aspx?orderid="+ txt_data.Text);
        // Response.Redirect("http://www.google.co.in");
       // Server.Transfer("http://www.google.co.in");
    }
    
}