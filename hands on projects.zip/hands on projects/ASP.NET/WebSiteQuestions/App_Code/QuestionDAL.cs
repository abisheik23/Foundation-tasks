﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
/// <summary>
/// Summary description for QuestionDAL
/// </summary>
public class QuestionDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public List<Questions> GetQuestions()
    {
        SqlCommand com = new SqlCommand("Select QuestionID,Question,option1,option2,option3,option4 from questions",con);
        List<Questions> show_questions = new List<Questions>();
        con.Open();
        SqlDataReader dr = com.ExecuteReader();
        
        while (dr.Read())
        {
            Questions q = new Questions();
            q.QuestionID = dr.GetInt32(0);
            q.QuestionName = dr.GetString(1);
            q.Option1 = dr.GetString(2);
            q.Option2 = dr.GetString(3);
            q.Option3 = dr.GetString(4);
            q.Option4 = dr.GetString(5);
            show_questions.Add(q);
        }
        con.Close();
        return show_questions;
    }

    public int GetQuestionAnswer(int qid, int userans)
    {
        SqlCommand com_question_check = new SqlCommand("Select Count(*) from questions where questionid=@qid and answer=@ans", con);
        com_question_check.Parameters.AddWithValue("@qid",qid);
        com_question_check.Parameters.AddWithValue("@ans",userans);
        con.Open();
        int count=Convert.ToInt32(com_question_check.ExecuteScalar());
        con.Close();
        return count;

    }
}