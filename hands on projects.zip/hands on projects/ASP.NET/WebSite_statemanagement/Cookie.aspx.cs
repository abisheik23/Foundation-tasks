﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Cookie : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_cookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie("pid", tb_cookie.Text);
        c.Expires = Convert.ToDateTime("12/12/2017");
        Response.Cookies.Add(c);
    }
    protected void btn_read_Click(object sender, EventArgs e)
    {
        HttpCookie c = Request.Cookies["pid"];
        lb_cookie.Text = c.Value;
    }
}