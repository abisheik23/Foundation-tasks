﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_application : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_set_Click(object sender, EventArgs e)
    {
        Application["msg"] = tb_msg.Text;
    }
    protected void btn_get_Click(object sender, EventArgs e)
    {
        lb_data.Text = Application["msg"].ToString();
    }
}