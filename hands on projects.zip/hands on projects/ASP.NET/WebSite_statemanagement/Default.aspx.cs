﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    int orderid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void btn_orderid_Click(object sender, EventArgs e)
    {
        orderid = Convert.ToInt32(tb_id.Text);
        ViewState["oid"] = orderid;
        
    }
    protected void btn_show_Click(object sender, EventArgs e)
    {
        orderid = Convert.ToInt32(ViewState["oid"]);
        lb_id.Text = orderid.ToString();
    }
    protected void btn_details_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OrderDetails.aspx?oid="+tb_id.Text+"&cid="+tb_detail1.Text);
    }
}