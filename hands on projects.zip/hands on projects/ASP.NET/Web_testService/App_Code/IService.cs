﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService" in both code and config file together.
[ServiceContract(Name="mycontract",Namespace="www.inautix.com")]
public interface IService
{
    [OperationContract(Name = "Method1")]
    int GetData(string str);

    [OperationContract(Name = "Method2")]
    int GetData(int i);
}
[ServiceContract(Name = "mycontract2", Namespace = "www.inautix.com/v2")]
public interface IService2
{
    [OperationContract(Name = "Method1")]
    int GetData(string str);

    [OperationContract(Name = "Method2")]
    int GetData(int i);
}
