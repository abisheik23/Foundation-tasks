﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class showLeave : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int eid = Convert.ToInt32(Request.QueryString["eid"]);
        EmployeeDAL dal = new EmployeeDAL();
        gv_leave.DataSource = dal.show_leave(eid);
        gv_leave.DataBind();
    }
}