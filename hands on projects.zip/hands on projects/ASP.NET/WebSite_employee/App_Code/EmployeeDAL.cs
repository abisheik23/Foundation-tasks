﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
/// <summary>
/// Summary description for EmployeeDAL
/// </summary>
public class EmployeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["employee"].ConnectionString);
    public List<Employee> showEmployee()
    {
        List<Employee> show_employee = new List<Employee>();
        SqlCommand com_employee = new SqlCommand("Select * from Employee", con);
        con.Open();
        SqlDataReader dr = com_employee.ExecuteReader();
        while (dr.Read())
        {
            Employee emp = new Employee();
            emp.EmployeeID = dr.GetInt32(0);
            emp.EmployeeName = dr.GetString(1);
            emp.EmployeeExp = dr.GetInt32(2);
            emp.EmployeeDept = dr.GetString(4);
            emp.Employeedesg = dr.GetString(5);
            show_employee.Add(emp);
         }
        con.Close();
        return show_employee;
    }

    public List<Leave> show_leave(int eid)
    {
        List<Leave> leavelist = new List<Leave>();
        SqlCommand com_product = new SqlCommand("Select * from leaverequest where employeeid=@eid", con);
        com_product.Parameters.AddWithValue("@eid", eid);
        con.Open();
        SqlDataReader dr = com_product.ExecuteReader();
        Leave L = new Leave();
        if (dr.Read())
        {
            L.Leaveid = dr.GetInt32(0);
            L.Employeeid=dr.GetInt32(1);
            L.LeaverequestDate = dr.GetDateTime(2);
            L.LeaveDate = dr.GetDateTime(3);
            L.noofdays = dr.GetInt32(4);
            L.Leavetype = dr.GetString(5);
            L.Status = dr.GetString(6);
            L.ManagerId = dr.GetInt32(7);
            L.Reason = dr.GetString(8);
            leavelist.Add(L);
        }
        con.Close();
        return leavelist;
        
    }
}
