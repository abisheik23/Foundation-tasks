﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public int EmployeeID { get; set; }
    public string EmployeeName { get; set; }
    public int EmployeeExp { get; set; }
    public string EmployeeDept { get; set; }
    public string Employeedesg { get; set; }
}