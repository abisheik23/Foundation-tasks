﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Leave
/// </summary>
public class Leave
{
    public int Leaveid { get; set; }
    public int Employeeid { get; set; }
    public DateTime LeaverequestDate { get; set; }
    public DateTime LeaveDate { get; set; }
    public int noofdays { get; set; }
    public string Leavetype { get; set; }
    public string Status { get; set; }
    public int ManagerId { get; set; }
    public string Reason { get; set; }
}