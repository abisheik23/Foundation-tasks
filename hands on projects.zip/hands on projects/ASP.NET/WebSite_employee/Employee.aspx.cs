﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_show_Click(object sender, EventArgs e)
    {
        EmployeeDAL dal = new EmployeeDAL();
        gv_emp.DataSource = dal.showEmployee();
        gv_emp.DataBind();
    }
    protected void gv_emp_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label lb = gv_emp.SelectedRow.FindControl("lb_eid") as Label;
        int eid = Convert.ToInt32(lb.Text);
        Response.Redirect("~/showLeave.aspx?eid=" + eid);
    }
}