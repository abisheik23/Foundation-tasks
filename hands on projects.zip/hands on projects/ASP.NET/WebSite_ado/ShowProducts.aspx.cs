﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_show_Click(object sender, EventArgs e)
    {
        ProductDAL dal = new ProductDAL();
        gv_products.DataSource = dal.GetProducts();
        gv_products.DataBind();
    }
    protected void gv_products_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label lb= gv_products.SelectedRow.FindControl("lb_pid") as Label;
        int pid = Convert.ToInt32(lb.Text);
        Response.Redirect("~/ShowProductDetails.aspx?pid=" + pid);
    }
}