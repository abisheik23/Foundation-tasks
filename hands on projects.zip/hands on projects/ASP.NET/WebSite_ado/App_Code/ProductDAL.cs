﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
/// <summary>
/// Summary description for ProductDAL
/// </summary>
public class ProductDAL
{
	SqlConnection con=new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool addProduct(Product p)
    {
        SqlCommand com_product_insert = new SqlCommand("insert products values(@pname,@price,null)", con);
        com_product_insert.Parameters.AddWithValue("@pname", p.ProductName);
        com_product_insert.Parameters.AddWithValue("@price",p.ProductPrice);
        con.Open();
        com_product_insert.ExecuteNonQuery();
        SqlCommand com_product_id = new SqlCommand("Select @@identity",con);
        int productid = Convert.ToInt32(com_product_id.ExecuteScalar());
        p.ProductAddress = "~/ProductImages/" + productid + ".jpg";
        p.ProductID = productid;

        SqlCommand com_product_update_image_address = new SqlCommand
            ("update products set Productimageaddress=@address where productid=@pid", con);
        com_product_update_image_address.Parameters.AddWithValue("@pid",p.ProductID);
        com_product_update_image_address.Parameters.AddWithValue("@address", p.ProductAddress);
        com_product_update_image_address.ExecuteNonQuery();
        con.Close();
        return true;
    }

    public List<Product> GetProducts()
    {
        List<Product> list_products = new List<Product>();
        SqlCommand com_products = new SqlCommand("Select * from Products", con);
        con.Open();
        SqlDataReader dr = com_products.ExecuteReader();
        while (dr.Read())
        {
            Product p = new Product();
            p.ProductID = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductAddress = dr.GetString(3);
            list_products.Add(p);
        }
        con.Close();
        return list_products;
    }

    public Product GetProduct(int productid)
    {
        SqlCommand com_product = new SqlCommand("Select * from Products where productid=@pid", con);
        com_product.Parameters.AddWithValue("@pid", productid);
        con.Open();
        SqlDataReader dr = com_product.ExecuteReader();
        Product p = new Product();
        if (dr.Read())
        {
            p.ProductID = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductAddress = dr.GetString(3);
        }
        con.Close();
        return p;
    }
}