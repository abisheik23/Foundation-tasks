﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProductDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int pid = Convert.ToInt32(Request.QueryString["pid"]);
        ProductDAL dal = new ProductDAL();
        Product p = dal.GetProduct(pid);

        lb_id.Text= p.ProductID.ToString();
        lb_name.Text= p.ProductName;
        lb_price.Text= p.ProductPrice.ToString();
        im_image.ImageUrl = p.ProductAddress;
    }
}