﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["login"].ConnectionString);
    public bool addCustomer(Customer c,string password,string email,string question,string answer)
	{
        SqlCommand com_new_cus = new SqlCommand("insert newcustomer values(@cname,@desg)",con);
        com_new_cus.Parameters.AddWithValue("@cname", c.CustomerName);
        com_new_cus.Parameters.AddWithValue("@desg", c.CustomerDesg);
        con.Open();
        com_new_cus.ExecuteNonQuery();
        SqlCommand com_new_id=new SqlCommand("select @@identity",con);
        int cid = Convert.ToInt32(com_new_id.ExecuteScalar());
        
        con.Close();
        c.Customerid = cid;

        MembershipCreateStatus status;

        Membership.CreateUser(c.Customerid.ToString(),password,email,question,answer,true,out status);

        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
        return true;
	}
}