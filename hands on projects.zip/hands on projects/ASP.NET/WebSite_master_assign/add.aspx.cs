﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class add : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_crCus_Click(object sender, EventArgs e)
    {
        CustomerDAL dal = new CustomerDAL();
        Customer c = new Customer();
        c.CustomerName = tb_cname.Text;
        c.CustomerDesg = tb_cdesg.Text;
        if (dal.addCustomer(c, tb_cpass.Text, tb_cemail.Text, tb_sques.Text, tb_sans.Text))
        {
            tb_cid.Text = c.Customerid.ToString();
            lb_status.Text = "Customer Created";
        }
        else
        {
            lb_status.Text = "Customer Not Created";
        }
        
    }
}