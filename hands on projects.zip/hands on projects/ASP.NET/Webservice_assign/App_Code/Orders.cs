﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
/// <summary>
/// Summary description for Orders
/// </summary>
[DataContract]
public class Orders
{
 [DataMember]
    public int OrderID { get; set; }
    [DataMember]
    public string Customername { get; set; }
    [DataMember]
    public int orderamt { get; set; }
    [DataMember]
    public string Ordercity { get; set; }
}