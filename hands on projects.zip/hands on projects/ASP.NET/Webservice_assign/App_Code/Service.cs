﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public int AddOrder(Orders o)
    {
        SqlCommand com_ins = new SqlCommand("insert orders values(@name,@amt,@city)", con);
        com_ins.Parameters.AddWithValue("@name", o.Customername);
        com_ins.Parameters.AddWithValue("@amt", o.orderamt);
        com_ins.Parameters.AddWithValue("@city", o.Ordercity);
        con.Open();
        com_ins.ExecuteNonQuery();
        SqlCommand com_id = new SqlCommand("Select @@identity", con);
        int orderid = Convert.ToInt32(com_id.ExecuteScalar());
        o.OrderID = orderid;
        con.Close();
        return orderid;
    }

    public List<Orders> GetOrders(string name)
    {
        List<Orders> ordlist = new List<Orders>();
        SqlCommand com_orders = new SqlCommand("Select * from Orders where customername=@name", con);
        com_orders.Parameters.AddWithValue("@name", name);
        con.Open();
        SqlDataReader dr = com_orders.ExecuteReader();
        while (dr.Read())
        {
            Orders o = new Orders();
            o.OrderID = dr.GetInt32(0);
            o.Customername = dr.GetString(1);
            o.orderamt = dr.GetInt32(2);
            o.Ordercity = dr.GetString(3);
            ordlist.Add(o);
        }
        con.Close();
        return ordlist;
    }
}
