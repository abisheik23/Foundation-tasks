﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
	
    [OperationBehavior(TransactionScopeRequired=true)]
    public int makepayment(int AccountNo, int Amount)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        SqlCommand com_bank_payment = new SqlCommand("Insert BankTransaction values(@accno,@amt,getdate())", con);
        com_bank_payment.Parameters.AddWithValue("@accno", AccountNo);
        com_bank_payment.Parameters.AddWithValue("@amt", Amount);
        con.Open();
        com_bank_payment.ExecuteNonQuery();
        SqlCommand com_transid = new SqlCommand("Select @@identity", con);
        int transid = Convert.ToInt32(com_transid.ExecuteScalar());
        con.Close();
        return transid;
    }
}
