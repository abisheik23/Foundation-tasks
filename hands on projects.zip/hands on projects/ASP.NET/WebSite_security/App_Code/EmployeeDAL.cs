﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
/// <summary>
/// Summary description for EmployeeDAL
/// </summary>
public class EmployeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["login"].ConnectionString);
    public bool addEmployee(Employee e,string securityquestion,string securityanswer,string email,string password)
    {
        SqlCommand com_insert = new SqlCommand("insert employeelogin values(@name,@city)", con);
        com_insert.Parameters.AddWithValue("@name", e.EmployeeName);
        com_insert.Parameters.AddWithValue("@city", e.EmployeeCity);
        con.Open();
        com_insert.ExecuteNonQuery();
        SqlCommand com_login = new SqlCommand("select @@identity", con);
        int eid= Convert.ToInt32(com_login.ExecuteScalar());
        
        con.Close();
        e.EmployeeID = eid;

        MembershipCreateStatus status;
        Membership.CreateUser(e.EmployeeID.ToString(),password,email,securityquestion,securityanswer,true,out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false; 
        }

        return true;
        
    }
    
}