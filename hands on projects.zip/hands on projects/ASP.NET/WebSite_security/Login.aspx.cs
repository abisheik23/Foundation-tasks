﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        EmployeeDAL dal = new EmployeeDAL();
        Employee emp = new Employee();
        emp.EmployeeName = tb_ename.Text;
        emp.EmployeeCity = tb_ecity.Text;
        if (dal.addEmployee(emp, tb_question.Text, tb_eans.Text, tb_email.Text, tb_epass.Text))
        {
            tb_eid.Text = emp.EmployeeID.ToString();


            lb_status.Text = "User Created";
        }
        else
        {
            lb_status.Text = "User Not Created";
        }
            
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(tb_lid.Text, tb_pass.Text))
        {
            FormsAuthentication.SetAuthCookie(tb_lid.Text, cb_rem.Checked);
            Response.Redirect("~/HomePage.aspx");

        }
        else
        {
            lb_msg.Text = "Invalid user id and password";
        }
    }
}