﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(tb_id.Text,tb_pass.Text))
        {
            FormsAuthentication.SetAuthCookie(tb_id.Text, cb_rem.Checked);
            Response.Redirect("~/ShowProducts.aspx?cid="+tb_id.Text);

        }
        else
        {
            Response.Redirect("<script>alert('Invalid userid and password')</script>");
        }
    }
    protected void btn_new_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SetAuthCookie(tb_id.Text, cb_rem.Checked);
        Response.Redirect("~/New.aspx");
    }
}