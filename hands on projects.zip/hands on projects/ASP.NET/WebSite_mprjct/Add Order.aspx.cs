﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Add_Order : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

        dd_quantity.Items.Add("1");
        dd_quantity.Items.Add("2");
        dd_quantity.Items.Add("3");
        dd_quantity.Items.Add("4");
        dd_quantity.Items.Add("5");
        dd_quantity.Items.Add("6");
        dd_quantity.Items.Add("7");
        dd_quantity.Items.Add("8");
        dd_quantity.Items.Add("9");
        dd_quantity.Items.Add("10");

        int price = Convert.ToInt32(Request.QueryString["price"]);
        lb_price.Text = (Convert.ToInt32(dd_quantity.Text) * price).ToString();
    }
    protected void btn_place_Click(object sender, EventArgs e)
    {
        Products p=new Products();
        Order o = new Order();
        OrderDAL dal = new OrderDAL();
        o.customerID = Convert.ToInt32(Page.User.Identity.Name);
        o.ProductID = p.ProductID;
        o.Quantity = Convert.ToInt32(dd_quantity.Text);
        o.Price = Convert.ToInt32(lb_price.Text);
    }
}