﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Show_Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void gv_show_SelectedIndexChanged(object sender, EventArgs e)
    {
        ProductDAL dal=new ProductDAL();
        gv_show.DataSource = dal.showProducts();
        gv_show.DataBind();
    }

    protected void gv_show_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        
        Products p=new Products();
        if (e.CommandName == "Add to cart")
        {
            int tktid = p.ProductID;
            Cart cd = new Cart();
            CartDAL dal = new CartDAL();
            cd.customerid = Convert.ToInt32(Page.User.Identity.Name);
            cd.productid = p.ProductID;
            dal.addcart(cd);
        }
    }
}