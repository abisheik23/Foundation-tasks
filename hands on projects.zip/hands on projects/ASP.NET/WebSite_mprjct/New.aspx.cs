﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class New : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        CustomerDAL dal = new CustomerDAL();
        Customer c = new Customer();
        c.customerName = tb_name.Text;
        c.contactno = tb_no.Text;

        if (dal.addCustomer(c, tb_question.Text, tb_ans.Text, tb_email.Text, tb_pass.Text))
        {
            lb_id.Text = c.customerID.ToString();
            Response.Redirect("<script>alert('user is created')</script>");
            
        }
        else
        {
            Response.Redirect("<script>alert('user not created')</script>");
        }

        FormsAuthentication.RedirectToLoginPage();
    }
}