﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;
/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cart"].ConnectionString);
    public bool addCustomer(Customer c,string securityquestion, string securityanswer, string email, string password)
	{
        SqlCommand com_insert_cus = new SqlCommand("insert customer values(@cname,@cno)", con);
        com_insert_cus.Parameters.AddWithValue("@cname", c.customerName);
        com_insert_cus.Parameters.AddWithValue("@cno", c.contactno);
        con.Open();
        com_insert_cus.ExecuteNonQuery();
        SqlCommand com_cid = new SqlCommand("Select @@identity", con);
        int cid = Convert.ToInt32(com_cid.ExecuteScalar());
        con.Close();
        c.customerID = cid;


        MembershipCreateStatus status;
        Membership.CreateUser(c.customerID.ToString(), password, email, securityquestion, securityanswer, true, out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
        return true;
   }
}