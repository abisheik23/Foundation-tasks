﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Cart
/// </summary>
public class Cart
{
    public int customerid { get; set;}
    public int productid { get; set;}
    public DateTime addeddate { get; set;}
}