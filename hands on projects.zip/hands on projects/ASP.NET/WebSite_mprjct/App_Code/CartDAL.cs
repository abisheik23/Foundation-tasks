﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Security;

/// <summary>
/// Summary description for CartDAL
/// </summary>
public class CartDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cart"].ConnectionString);
    public bool addcart(Cart c)
	{
        SqlCommand com_ins_cart = new SqlCommand("insert cart values(@cid,@pid,getdate())", con);
        com_ins_cart.Parameters.AddWithValue("@cid",c.customerid);
        com_ins_cart.Parameters.AddWithValue("@pid", c.productid);
        con.Open();
        com_ins_cart.ExecuteNonQuery();
        con.Close();
        return true;
	}
}