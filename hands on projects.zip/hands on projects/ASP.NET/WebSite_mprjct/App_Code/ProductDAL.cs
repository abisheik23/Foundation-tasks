﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for ProductDAL
/// </summary>
public class ProductDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cart"].ConnectionString);
    public bool addProduct(Products p)
    {
        SqlCommand com_addp = new SqlCommand("insert products values(@pname,@pprice,@pdesc,@pmodel,@pcat,null)", con);
        com_addp.Parameters.AddWithValue("@pname", p.ProductName);
        com_addp.Parameters.AddWithValue("@pprice",p.ProductPrice);
        com_addp.Parameters.AddWithValue("@pdesc", p.ProductDesc);
        com_addp.Parameters.AddWithValue("@pmodel", p.ProductModel);
        com_addp.Parameters.AddWithValue("@pcat", p.ProductCategory);
        
        con.Open();
        com_addp.ExecuteNonQuery();
        SqlCommand com_pid = new SqlCommand("select @@identity", con);
        int pid = Convert.ToInt32(com_pid.ExecuteScalar());
        p.ProductAddress = "~/Product Images/" + pid + ".jpg";
        p.ProductID = pid;
        SqlCommand com_update = new SqlCommand("update products set productImageAddress=@address where productid=@ppid", con);
        com_update.Parameters.AddWithValue("@address",p.ProductAddress);
        com_update.Parameters.AddWithValue("@ppid", p.ProductID);
        com_update.ExecuteNonQuery();
        con.Close();
        return true;
    }

    public List<Products> showProducts()
    {
        List<Products> showproduct = new List<Products>();
        SqlCommand com_product = new SqlCommand("Select productid,productname,productprice,productaddress from Products", con);
        con.Open();
        SqlDataReader dr = com_product.ExecuteReader();
        while (dr.Read())
        {
            Products p = new Products();
            p.ProductID = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductAddress = dr.GetString(3);
            showproduct.Add(p);
        }
        con.Close();
        return showproduct;
    }


}