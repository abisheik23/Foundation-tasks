﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
/// <summary>
/// Summary description for OrderDAL
/// </summary>
public class OrderDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cart"].ConnectionString);
    public bool addOrders(Order o)
    {
        SqlCommand com_ins = new SqlCommand("insert orders values(@cid,@pid,@qua,@price,getdate())", con);
        com_ins.Parameters.AddWithValue("@cid",o.customerID);
        com_ins.Parameters.AddWithValue("@pid", o.ProductID);
        com_ins.Parameters.AddWithValue("@qua", o.Quantity);
        com_ins.Parameters.AddWithValue("@price", o.Price);
        con.Open();
        com_ins.ExecuteNonQuery();

        SqlCommand com_oid = new SqlCommand("select @@identity", con);
        int oid = Convert.ToInt32(com_oid.ExecuteScalar());
        o.OrderID = oid;
        con.Close();
        return true;
    }
}