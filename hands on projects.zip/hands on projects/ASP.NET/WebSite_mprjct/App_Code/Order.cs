﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    public int OrderID { get; set; }
    public int customerID { get; set;}
    public int ProductID { get; set; }
    public int Quantity { get; set; }
    public int Price { get; set;}
    public DateTime orderdate { get; set;}
}