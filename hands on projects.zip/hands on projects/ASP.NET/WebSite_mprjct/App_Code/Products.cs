﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Products
/// </summary>
public class Products
{
    public int ProductID { get; set; }
    public string ProductName { get; set;}
    public int ProductPrice { get; set;}
    public string ProductDesc { get; set;}
    public string ProductModel { get; set;}
    public string ProductCategory { get; set; }
    public string ProductAddress { get; set; }
}