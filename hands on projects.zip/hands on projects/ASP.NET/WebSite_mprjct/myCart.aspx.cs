﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class myCart : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void gv_cart_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        Products p = new Products();
        Order o = new Order();
        if (e.CommandName =="Place Order")
        {
            o.ProductID = p.ProductID;
            Response.Redirect("~/AddOrder.aspx?price=" + p.ProductPrice);

        }
    }
    protected void gv_cart_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
}