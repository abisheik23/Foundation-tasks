﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Add_Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        Products p = new Products();
        p.ProductName = tb_pname.Text;
        p.ProductPrice = Convert.ToInt32(tb_pprice.Text);
        p.ProductCategory = tb_cat.Text;
        p.ProductDesc = tb_desc.Text;
        p.ProductModel = tb_mod.Text;

        ProductDAL dal = new ProductDAL();
        dal.addProduct(p);

        fu_img.SaveAs(MapPath(p.ProductAddress));

        tb_pid.Text = p.ProductID.ToString();

        Response.Write("<script>alert('Product"+tb_pid.Text+" Added Successfully')</script>");
    }
}