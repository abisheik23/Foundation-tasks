﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
/// <summary>
/// Summary description for ErrorInfo
/// </summary>
[DataContract]
public class ErrorInfo
{
    [DataMember]
    public int ErrorNo { get; set; }
    [DataMember]
    public string ErrorDateTime { get; set; }
    [DataMember]
    public string ErrorDetails { get; set; }
}