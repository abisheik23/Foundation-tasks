﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public int AddCustomer(Customer obj)
    {
        try
        {
            SqlCommand com_insert = new SqlCommand("insert customer_wcf1 values(@custname,@custcity)", con);
            com_insert.Parameters.AddWithValue("@custname", obj.CustomerName);
            com_insert.Parameters.AddWithValue("@custcity", obj.CustomerCity);
            con.Open();
            com_insert.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("Select @@identity", con);
            int customerid = Convert.ToInt32(com_id.ExecuteScalar());
            con.Close();
            return customerid;
        }
        catch (Exception exp)
        {
            ErrorInfo info = new ErrorInfo();
            info.ErrorNo = 101;
            info.ErrorDateTime = DateTime.Now.ToString();
            info.ErrorDetails = "Database Server Error";
            throw new FaultException<ErrorInfo>(info);
        }
    }

    public List<Customer> GetCustomers(string CustomerCity)
    {
        System.Threading.Thread.Sleep(15000);
        List<Customer> custlist = new List<Customer>();
        SqlCommand com_customers = new SqlCommand("Select * from customer_wcf where customercity=@city", con);
        com_customers.Parameters.AddWithValue("@city", CustomerCity);
        con.Open();
        SqlDataReader dr = com_customers.ExecuteReader();
        while (dr.Read())
        {
            Customer c = new Customer();
            c.CustomerID = dr.GetInt32(0);
            c.CustomerName = dr.GetString(1);
            c.CustomerCity = dr.GetString(2);
            custlist.Add(c);
        }

        con.Close();
        return custlist;
    }
}
