﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assign2
{
    /// <summary>
    /// Interaction logic for Win_home.xaml
    /// </summary>
    public partial class Win_home : Window
    {
        public Win_home()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, RoutedEventArgs e)
        {
            Win_show show = new Win_show();
            show.Show();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            tb_id.Text= "Employee ID:" + App.Current.Properties["eid"].ToString();
        }

        private void btn_request_Click(object sender, RoutedEventArgs e)
        {
            Win_request req = new Win_request();
            req.Show();
        }

        private void btn_find_Click(object sender, RoutedEventArgs e)
        {
            Win_find find = new Win_find();
            find.Show();
        }

        private void btn_logout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}
