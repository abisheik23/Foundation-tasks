﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_assign2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            Employee emp =new Employee();
            emp.Employeeid = Convert.ToInt32(tb_id.Text);
            emp.Employeepass = tb_pass.Password;

            if (dal.login(emp))
            {
                App.Current.Properties.Add("eid", tb_id.Text);
                Win_home home = new Win_home();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Employee");
            }
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            Win_add add = new Win_add();
            add.Show();
        }
    }
}
