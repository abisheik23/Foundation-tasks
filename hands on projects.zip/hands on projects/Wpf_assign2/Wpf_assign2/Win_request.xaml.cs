﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assign2
{
    /// <summary>
    /// Interaction logic for Win_request.xaml
    /// </summary>
    public partial class Win_request : Window
    {
        public Win_request()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, RoutedEventArgs e)
        {
            LeaveDAL dal = new LeaveDAL();
            Leave l = new Leave();
            l.LeaveDate = Convert.ToDateTime(tb_date.Text);
            l.noofdays = Convert.ToInt32(cb_days.Text);
            if(rb_cas.IsChecked==true)
            {
                l.Leavetype = "Casual";
            }
            else if (rb_man.IsChecked == true)
            {
                l.Leavetype = "Mandatory";
            }
            else if (rb_med.IsChecked == true)
            {
                l.Leavetype = "Medical";
            }
            else if (rb_sick.IsChecked == true)
            {
                l.Leavetype = "sick";
            }
            l.Reason = tb_reason.Text;
            l.MangerId = Convert.ToInt32(tb_mgrid.Text);
            l.Employeeid = Convert.ToInt32(App.Current.Properties["eid"].ToString());
            dal.leaverequest(l);
            MessageBox.Show("The Request Has been Followed to your Manager and leave id is" + l.Leaveid);
           

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cb_days.Items.Add("1");
            cb_days.Items.Add("2");
            cb_days.Items.Add("3");
            cb_days.Items.Add("4");
            cb_days.Items.Add("5");
            cb_days.Items.Add("6");
            cb_days.Items.Add("7");
            cb_days.Items.Add("8");
            cb_days.Items.Add("9");
            cb_days.Items.Add("10");
        }
    }
}
