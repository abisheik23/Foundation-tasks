﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_assign2
{
    class LeaveDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["employee"].ConnectionString);
        public bool leaverequest(Leave obj)
        {
            SqlCommand lve_req = new SqlCommand("insert leaverequest values(@empid,getdate(),@ldate,@no,@type,'pending',@mgrid,@reason)",con);
            lve_req.Parameters.AddWithValue("@empid", obj.Employeeid);
            lve_req.Parameters.AddWithValue("@ldate",obj.LeaveDate);
            lve_req.Parameters.AddWithValue("@no", obj.noofdays);
            lve_req.Parameters.AddWithValue("@type", obj.Leavetype);
            lve_req.Parameters.AddWithValue("@mgrid", obj.MangerId);
            lve_req.Parameters.AddWithValue("@reason", obj.Reason);
            con.Open();
            lve_req.ExecuteNonQuery();
            SqlCommand lve_id = new SqlCommand("select @@identity", con);
            int leaveid = Convert.ToInt32(lve_id.ExecuteScalar());
            obj.Leaveid = leaveid;
            con.Close();
            return true;
        }

        public List<Leave> showleave(int employeeid)
        {
            List<Leave> leavelist = new List<Leave>();
            SqlCommand lve_show = new SqlCommand("select * from leaverequest where employeeid=@eid", con);
            lve_show.Parameters.AddWithValue("@eid",employeeid);
            con.Open();
            SqlDataReader dr = lve_show.ExecuteReader();
            while (dr.Read())
            {
                Leave l = new Leave();
                l.Leaveid = dr.GetInt32(0);
                l.Employeeid = dr.GetInt32(1);
                l.LeaverequestDate = dr.GetDateTime(2);
                l.LeaveDate = dr.GetDateTime(3);
                l.noofdays = dr.GetInt32(4);
                l.Leavetype = dr.GetString(5);
                l.Status = dr.GetString(6);
                l.MangerId = dr.GetInt32(7);
                l.Reason = dr.GetString(8);
                leavelist.Add(l);

            }
            con.Close();
            return leavelist;
        }
    }
}
