﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_assign2
{
    class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["employee"].ConnectionString);
        public bool login(Employee obj)
        {
            SqlCommand com_login = new SqlCommand("select count(*) from employee where employeeid=@empid and employeepassword=@empass", con);
            com_login.Parameters.AddWithValue("@empid", obj.Employeeid);
            com_login.Parameters.AddWithValue("@empass", obj.Employeepass);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            con.Close();

        }
        public void addemployee(Employee obj)
        {
            SqlCommand com_add = new SqlCommand("insert employee values(@ename,@exp,@pass,@dept,@desg,@mgrid)", con);
            com_add.Parameters.AddWithValue("@ename", obj.Employeename);
            com_add.Parameters.AddWithValue("@exp", obj.Employeeexp);
            com_add.Parameters.AddWithValue("@pass", obj.Employeepass);
            com_add.Parameters.AddWithValue("@dept", obj.Employeedept);
            com_add.Parameters.AddWithValue("@desg", obj.Employeedesg);
            com_add.Parameters.AddWithValue("@mgrid", obj.ManagerID);
            con.Open();
            com_add.ExecuteNonQuery();
            SqlCommand com_id = new SqlCommand("select @@identity", con);
            int employeeid = Convert.ToInt32(com_id.ExecuteScalar());
            obj.Employeeid = employeeid;
            con.Close();
        }

        public Employee findemployee(int employeeid)
        {
            Employee e = new Employee();
            SqlCommand com_find = new SqlCommand("select * from employee where employeeid=@empid", con);
            com_find.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            while (dr.Read())
            {
                
                e.Employeeid = dr.GetInt32(0);
                e.Employeename = dr.GetString(1);
                e.Employeeexp=dr.GetInt32(2);
                e.Employeepass = dr.GetString(3);
                e.Employeedept = dr.GetString(4);
                e.Employeedesg = dr.GetString(5);
                e.ManagerID = dr.GetInt32(6);
            }
            con.Close();
            return e;

        }
    }
}
