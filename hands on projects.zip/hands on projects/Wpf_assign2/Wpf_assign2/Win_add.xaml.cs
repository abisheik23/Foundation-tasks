﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assign2
{
    /// <summary>
    /// Interaction logic for Win_add.xaml
    /// </summary>
    public partial class Win_add : Window
    {
        public Win_add()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDAL dal = new EmployeeDAL();
            Employee emp = new Employee();
            emp.Employeename = tb_name.Text;
            emp.Employeeexp = Convert.ToInt32(tb_exp.Text);
            emp.Employeepass = tb_pass.Password;
            emp.Employeedept = tb_dept.Text;
            emp.Employeedesg = tb_desg.Text;
            emp.ManagerID = Convert.ToInt32(tb_mgr.Text);
            dal.addemployee(emp);
            MessageBox.Show("Your Details have been added and id" + emp.Employeeid);

        }
    }
}
