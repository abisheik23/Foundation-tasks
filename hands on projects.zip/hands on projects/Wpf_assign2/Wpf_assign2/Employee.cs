﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_assign2
{
    class Employee
    {
        public int Employeeid { get; set; }
        public string Employeename { get; set;}
        public int Employeeexp { get; set; }
        public string Employeepass { get; set; }
        public string Employeedept { get; set; }
        public string Employeedesg { get; set; }
        public int ManagerID { get; set; }
    }
}
