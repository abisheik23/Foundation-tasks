﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Interface
{
    interface ITesting
    {
        bool Run();
        bool Stop();
    }
}
