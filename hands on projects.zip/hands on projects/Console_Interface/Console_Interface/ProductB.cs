﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Interface
{
    class ProductB:ITransport,ITesting

    {
        public string productid;
        public string productname;
        public string customername;
        public string customeraddress;
        public string spec_details;
        public void run() { }
        public void stop() { }
        public string GetCustomerDetails()
        {
            return customername + " " + customeraddress;
        }
        public string GetCustomerAddress()
        {
            return customername + " " + customeraddress;
        }
        public bool Run()
        {
            this.run();
            return true;
        }
        public bool Stop()
        {
            this.stop();
            return true;
        }

        
    }
}
