﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA a = new ProductA();
            a.pid = "121";
            a.pname = "Mobile";
            a.customername = "XYZ";
            a.address = "chennai";

            ProductB b = new ProductB();
            b.productid="1121";
            b.productname = "Laptop";
            b.customername = "ABC";
            b.customeraddress = "Pune";

            Testing testdept = new Testing();
            bool statusa = testdept.RecProductForTesting(a);
            bool statusb = testdept.RecProductForTesting(b);

            Transport t = new Transport();
            if (statusa != true)
            {
                Console.WriteLine("Product A is not OK");
            }
            else
            {
                t.Rec_Product(a);
            }
            if (statusb == true)
            {
                t.Rec_Product(b);
            }
            else
            {
                Console.WriteLine("Product B is not Ok");
            }
            Console.ReadKey();
        }
    }
}
