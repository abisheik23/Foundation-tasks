﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsForms_wsdn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_get_Click(object sender, EventArgs e)
        {
            int days = Convert.ToInt32(tb_days.Text);
            int sal = Convert.ToInt32(tb_sal.Text);

            localhost.WebService1 proxy = new localhost.WebService1();

            int total = proxy.GetSalary(days, sal);
            //SOAP Message -->

            MessageBox.Show("Salary:" + total);
        }
    }
}
