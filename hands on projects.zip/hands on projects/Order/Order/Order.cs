﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Order_library
{
    public class Order
    {
        int oid;
        public int poid { get { return oid; } }
        string name;
        public string pname { get { return name; } set { name = value; } }
        int iid;
        public int piid { get { return iid; } set { iid = value; } }
        int qty;
        public int pqty { get { return qty; } set { qty = value; } }
        double price;
        public double pprice { get { return price; } set { price = value; } }
        string address;
        public string padr { get { return address; } set { address = value; } }
        string date;
        public string pdate { get { return date; } set { date = value; } }
        string payment;
        public string ppay { get { return payment; } set { payment = value; } }
        string city;
        public string pcity { get { return city; } set { city = value; } }
        public Order(int oid)
         {
             this.oid = oid;
         }
         public Order()
         {
         }
         public double getOrderValue(int qty, double price)
         {
             return qty * price;
         }

    }
}
