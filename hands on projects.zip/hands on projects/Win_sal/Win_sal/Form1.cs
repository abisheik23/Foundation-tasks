﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_sal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double sal = Convert.ToDouble(tb_dsal.Text);
            if (sal == 0)
            {
                MessageBox.Show("Enter the salary per day:");
            }
            int day = Convert.ToInt32(tb_day.Text);
            if (day == 0)
            {
                MessageBox.Show("Enter the No of Days");
            }
            sal_library.salary obj = new sal_library.salary(sal,day);
            MessageBox.Show(""+obj.getSalary(sal, day));

        }
    }
}
