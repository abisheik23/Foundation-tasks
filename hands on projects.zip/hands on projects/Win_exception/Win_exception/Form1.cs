﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_exception
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_getvalue_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                //object obj = new object();
                //obj = null;
                //obj.ToString();
                Test obj = new Test();
                i = obj.getSum(tb_num.Text);
                MessageBox.Show(i.ToString());
            }

            catch (NullReferenceException exp)
            {
                MessageBox.Show(exp.Message);
            }
            catch (Exception exp)
            {
                MessageBox.Show("Error in the application,try with right values");
            }
            finally
            {
                MessageBox.Show("Finally");
            }
            MessageBox.Show("After Finally");

        }
    }
}
