﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_exception
{
    class Test
    {
        public int getSum(string str)
        {
            int i=0;
            i = Convert.ToInt32(str);
            return i;
        }
    }
}
