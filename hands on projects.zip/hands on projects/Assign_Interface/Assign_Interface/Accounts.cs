﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Interface
{
    class Accounts
    {
        public void GetAccounts(IAccounts obj)
        {
            
            string details = obj.getAccountDetails();
            Console.WriteLine(details);
        }
    }
}
