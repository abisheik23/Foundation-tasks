﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Interface
{
    class Hr
    {
        public void GetHr(IHr obj)
        {
            
            string details = obj.getEmpDetails();
            Console.WriteLine(details);
        }
    }
}
