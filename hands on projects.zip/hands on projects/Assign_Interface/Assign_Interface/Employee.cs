﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Interface
{
    class Employee:IAccounts,IManager,IHr
    {
        int eID;
        public int PeID { get { return eID; } }
        public string EmpName;
        public string Empcity;
        int Empsalary;
        public int PEmpSalary { get { return Empsalary; } }
        public string EmpAddress;
        public string EmpPrjDetails;
        int EmpExp;
        public int PEmpExp{get{return EmpExp;}}
        long EmpAccNo;
        public long PEmpAccNo{get{return EmpAccNo;}}
        public string EmpBankName;
        int EmpAge;
        public int PEmpAge{get{return EmpAge;}}
        public Employee()
        {
            this.eID = 0;
            this.EmpExp = 0;
            this.EmpAccNo = 0;
            this.EmpAge = 0;
            this.Empsalary = 0;
        }
        public Employee(int eID, int EmpExp, long EmpAccNo, int EmpAge,int Empsalary)
        {
            this.eID = eID;
            this.EmpExp = EmpExp;
            this.EmpAccNo = EmpAccNo;
            this.EmpAge = EmpAge;
            this.Empsalary = Empsalary;
        }

        public string getEmpDetails()
        {
            
            return EmpAddress + " " + Empsalary + " " + eID;

        }
        public string getAccountDetails()
        {
            return EmpAddress +" " + EmpAccNo + " " + eID;
        }
        public string getProjectDetails()
        {
            return eID + " " + EmpExp + " " + EmpPrjDetails;

        }
    }
}
