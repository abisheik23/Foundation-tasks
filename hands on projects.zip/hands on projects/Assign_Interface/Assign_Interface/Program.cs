﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e=new Employee();
            Console.Write("Enter the Employee ID:");
            int id = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter the Employee Name:");
            string name = Console.ReadLine();
            e.EmpName = name;
            Console.Write("Enter the Employee City:");
            string city = Console.ReadLine();
            e.Empcity = city;
            Console.Write("Enter the Employee Salary:");
            int sal = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Employee Address:");
            string adr = Console.ReadLine();
            e.EmpAddress = adr;
            Console.Write("Enter the Employee Project Details:");
            string pdetails = Console.ReadLine();
            e.EmpPrjDetails = pdetails;
            Console.Write("Enter the Employee Experience:");
            int exp = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter the Employee Account No:");
            long AccNo = Convert.ToInt64(Console.ReadLine());
            Console.Write("Enter the Employee Bank Name:");
            string bank = Console.ReadLine();
            e.EmpBankName = bank;
            Console.Write("Enter the Employee Age:");
            int age = Convert.ToInt16(Console.ReadLine());

            e = new Employee(id, exp, AccNo, age, sal);
            bool status=true;
            do
            {
                Console.WriteLine("1.HR Details\n2.Account Details\n3.Manager Details\n4.Exit");
                Console.Write("Enter Your Choice:");
                int choice = Convert.ToInt16(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Hr h = new Hr();
                        Console.WriteLine("The Hr details of Employee-"+e.EmpName);
                        h.GetHr(e);
                        break;
                    case 2:
                        Accounts a = new Accounts();
                        Console.WriteLine("The Account details of Employee-" + e.EmpName);
                        a.GetAccounts(e);
                        break;
                    case 3:
                        Manager m = new Manager();
                        Console.WriteLine("The Manager details of Employee-" + e.EmpName);
                        m.GetProjectDetails(e);
                        break;
                    case 4:
                        status = false;
                        break;
                }
            } while (status == true);

            Console.ReadKey();
            
        }
    }
}
