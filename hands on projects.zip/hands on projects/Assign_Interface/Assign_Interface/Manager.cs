﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Interface
{
    class Manager
    {
        public void GetProjectDetails(IManager obj)
        {
            string details = obj.getProjectDetails();
            Console.WriteLine(details);
           
        }
    }
}
