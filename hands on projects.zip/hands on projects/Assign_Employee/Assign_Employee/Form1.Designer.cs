﻿namespace Assign_Employee
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_oid = new System.Windows.Forms.Label();
            this.tb_oid = new System.Windows.Forms.TextBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.lb_tid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_iid = new System.Windows.Forms.TextBox();
            this.tb_qty = new System.Windows.Forms.TextBox();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.tb_adr = new System.Windows.Forms.TextBox();
            this.cb_city = new System.Windows.Forms.ComboBox();
            this.tb_date = new System.Windows.Forms.TextBox();
            this.rb_card = new System.Windows.Forms.RadioButton();
            this.rb_net = new System.Windows.Forms.RadioButton();
            this.rb_cash = new System.Windows.Forms.RadioButton();
            this.lb_city = new System.Windows.Forms.Label();
            this.lb_date = new System.Windows.Forms.Label();
            this.lb_payment = new System.Windows.Forms.Label();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_order = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_oid
            // 
            this.lb_oid.AutoSize = true;
            this.lb_oid.Location = new System.Drawing.Point(18, 43);
            this.lb_oid.Name = "lb_oid";
            this.lb_oid.Size = new System.Drawing.Size(50, 13);
            this.lb_oid.TabIndex = 0;
            this.lb_oid.Text = "Order ID:";
            // 
            // tb_oid
            // 
            this.tb_oid.Location = new System.Drawing.Point(130, 40);
            this.tb_oid.Name = "tb_oid";
            this.tb_oid.Size = new System.Drawing.Size(146, 20);
            this.tb_oid.TabIndex = 1;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Location = new System.Drawing.Point(18, 80);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(38, 13);
            this.lb_name.TabIndex = 2;
            this.lb_name.Text = "Name:";
            // 
            // tb_name
            // 
            this.tb_name.Location = new System.Drawing.Point(130, 77);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(146, 20);
            this.tb_name.TabIndex = 3;
            // 
            // lb_tid
            // 
            this.lb_tid.AutoSize = true;
            this.lb_tid.Location = new System.Drawing.Point(18, 117);
            this.lb_tid.Name = "lb_tid";
            this.lb_tid.Size = new System.Drawing.Size(44, 13);
            this.lb_tid.TabIndex = 4;
            this.lb_tid.Text = "Item ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Quantity:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Address:";
            // 
            // tb_iid
            // 
            this.tb_iid.Location = new System.Drawing.Point(130, 114);
            this.tb_iid.Name = "tb_iid";
            this.tb_iid.Size = new System.Drawing.Size(146, 20);
            this.tb_iid.TabIndex = 8;
            // 
            // tb_qty
            // 
            this.tb_qty.Location = new System.Drawing.Point(130, 149);
            this.tb_qty.Name = "tb_qty";
            this.tb_qty.Size = new System.Drawing.Size(146, 20);
            this.tb_qty.TabIndex = 9;
            // 
            // tb_price
            // 
            this.tb_price.Location = new System.Drawing.Point(130, 185);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(146, 20);
            this.tb_price.TabIndex = 10;
            // 
            // tb_adr
            // 
            this.tb_adr.Location = new System.Drawing.Point(130, 220);
            this.tb_adr.Name = "tb_adr";
            this.tb_adr.Size = new System.Drawing.Size(146, 20);
            this.tb_adr.TabIndex = 11;
            // 
            // cb_city
            // 
            this.cb_city.FormattingEnabled = true;
            this.cb_city.Location = new System.Drawing.Point(130, 260);
            this.cb_city.Name = "cb_city";
            this.cb_city.Size = new System.Drawing.Size(146, 21);
            this.cb_city.TabIndex = 12;
            // 
            // tb_date
            // 
            this.tb_date.Location = new System.Drawing.Point(130, 297);
            this.tb_date.Name = "tb_date";
            this.tb_date.Size = new System.Drawing.Size(146, 20);
            this.tb_date.TabIndex = 13;
            // 
            // rb_card
            // 
            this.rb_card.AutoSize = true;
            this.rb_card.Location = new System.Drawing.Point(130, 338);
            this.rb_card.Name = "rb_card";
            this.rb_card.Size = new System.Drawing.Size(107, 17);
            this.rb_card.TabIndex = 14;
            this.rb_card.TabStop = true;
            this.rb_card.Text = "Credit/Debit Card";
            this.rb_card.UseVisualStyleBackColor = true;
            // 
            // rb_net
            // 
            this.rb_net.AutoSize = true;
            this.rb_net.Location = new System.Drawing.Point(240, 338);
            this.rb_net.Name = "rb_net";
            this.rb_net.Size = new System.Drawing.Size(84, 17);
            this.rb_net.TabIndex = 15;
            this.rb_net.TabStop = true;
            this.rb_net.Text = "Net Banking";
            this.rb_net.UseVisualStyleBackColor = true;
            // 
            // rb_cash
            // 
            this.rb_cash.AutoSize = true;
            this.rb_cash.Location = new System.Drawing.Point(331, 338);
            this.rb_cash.Name = "rb_cash";
            this.rb_cash.Size = new System.Drawing.Size(107, 17);
            this.rb_cash.TabIndex = 16;
            this.rb_cash.TabStop = true;
            this.rb_cash.Text = "Cash On Delivery";
            this.rb_cash.UseVisualStyleBackColor = true;
            // 
            // lb_city
            // 
            this.lb_city.AutoSize = true;
            this.lb_city.Location = new System.Drawing.Point(21, 263);
            this.lb_city.Name = "lb_city";
            this.lb_city.Size = new System.Drawing.Size(26, 13);
            this.lb_city.TabIndex = 17;
            this.lb_city.Text = "city:";
            // 
            // lb_date
            // 
            this.lb_date.AutoSize = true;
            this.lb_date.Location = new System.Drawing.Point(21, 300);
            this.lb_date.Name = "lb_date";
            this.lb_date.Size = new System.Drawing.Size(62, 13);
            this.lb_date.TabIndex = 18;
            this.lb_date.Text = "Order Date:";
            // 
            // lb_payment
            // 
            this.lb_payment.AutoSize = true;
            this.lb_payment.Location = new System.Drawing.Point(21, 340);
            this.lb_payment.Name = "lb_payment";
            this.lb_payment.Size = new System.Drawing.Size(51, 13);
            this.lb_payment.TabIndex = 19;
            this.lb_payment.Text = "Payment:";
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(211, 395);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 20;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_order
            // 
            this.btn_order.Location = new System.Drawing.Point(331, 396);
            this.btn_order.Name = "btn_order";
            this.btn_order.Size = new System.Drawing.Size(75, 23);
            this.btn_order.TabIndex = 21;
            this.btn_order.Text = "Order";
            this.btn_order.UseVisualStyleBackColor = true;
            this.btn_order.Click += new System.EventHandler(this.btn_order_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(439, 431);
            this.Controls.Add(this.btn_order);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.lb_payment);
            this.Controls.Add(this.lb_date);
            this.Controls.Add(this.lb_city);
            this.Controls.Add(this.rb_cash);
            this.Controls.Add(this.rb_net);
            this.Controls.Add(this.rb_card);
            this.Controls.Add(this.tb_date);
            this.Controls.Add(this.cb_city);
            this.Controls.Add(this.tb_adr);
            this.Controls.Add(this.tb_price);
            this.Controls.Add(this.tb_qty);
            this.Controls.Add(this.tb_iid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_tid);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.tb_oid);
            this.Controls.Add(this.lb_oid);
            this.Name = "Form1";
            this.Text = "Order Details";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_oid;
        private System.Windows.Forms.TextBox tb_oid;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label lb_tid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_iid;
        private System.Windows.Forms.TextBox tb_qty;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.TextBox tb_adr;
        private System.Windows.Forms.ComboBox cb_city;
        private System.Windows.Forms.TextBox tb_date;
        private System.Windows.Forms.RadioButton rb_card;
        private System.Windows.Forms.RadioButton rb_net;
        private System.Windows.Forms.RadioButton rb_cash;
        private System.Windows.Forms.Label lb_city;
        private System.Windows.Forms.Label lb_date;
        private System.Windows.Forms.Label lb_payment;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_order;
    }
}

