﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assign_Employee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_city.Items.Add("Bangalore");
            cb_city.Items.Add("Chennai");
            cb_city.Items.Add("Coimbatore");
            cb_city.Items.Add("Kolkata");
            cb_city.Items.Add("Mumbai");
            cb_city.Items.Add("New Delhi");
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            tb_adr.Text = "";
            tb_name.Text = "" ; 
            tb_oid.Text = "" ; 
            tb_iid.Text = "" ;
            tb_qty.Text = ""; 
            tb_price.Text = ""; 
            cb_city.SelectedIndex=-1;
            tb_date.Text = "";
            rb_card.Checked = false;
            rb_cash.Checked = false;
            rb_net.Checked = false;
        }

        private void btn_order_Click(object sender, EventArgs e)
        {

           
            Order_library.Order obj = new Order_library.Order();
            if (tb_adr.Text ==""|| tb_name.Text == "" || tb_oid.Text == "" || tb_iid.Text == "" || tb_qty.Text == "" || tb_price.Text == "" || cb_city.Text == "" || tb_date.Text == "")
            {
               
                if (tb_oid.Text == "")
                {
                    MessageBox.Show("Enter the Order Id");
                }
                else
                {
                   obj = new Order_library.Order(Convert.ToInt32(tb_oid.Text));
                }
                string name = tb_name.Text;
                if (name == "")
                {
                    MessageBox.Show("Enter the Name");
                }
                else
                {
                    obj.pname = name;
                }
           
                if (tb_iid.Text == "")
                {
                    MessageBox.Show("Enter the Item Id");
                }
                else
                {
                    obj.piid = Convert.ToInt32(tb_iid.Text);
                }
                if (tb_qty.Text == "")
                {
                    MessageBox.Show("Enter the Quantity");
                }
                else
                {
                    obj.pqty = Convert.ToInt32(tb_qty.Text);
                   
                }
                if (tb_price.Text == "")
                {
                    MessageBox.Show("Enter the price");
                }
                else
                {
                    obj.pprice = Convert.ToDouble(tb_price.Text);
                   
                }
                string address = tb_adr.Text;
                if (address == "")
                {
                    MessageBox.Show("Enter the address");
                }
                else
                {
                    obj.padr = address;
                }
                string city = cb_city.Text;
                if (city == "")
                {
                    MessageBox.Show("Enter the city");
                }
                else
                {
                    obj.pcity = city;
                }
                string date = tb_date.Text;
                if (date == "")
                {
                    MessageBox.Show("Enter the Date");
                }
                else
                {
                    obj.pdate = date;
                }
                 if (!rb_card.Checked && !rb_cash.Checked && !rb_net.Checked)
                {
                    MessageBox.Show("Enter the Payment Option");
                }
                else
                {
                    if (rb_card.Checked)
                    {
                       string pay = "Card";
                        obj.ppay = pay;
                    }
                    else if (rb_net.Checked)
                    {
                        string pay = "Net Banking";
                        obj.ppay = pay;
                    }
                    else if (rb_cash.Checked)
                    {
                       string  pay = "Cash";
                        obj.ppay = pay;
                    }
                }
            }
        
            else
            {
                int qty;
                double price;
                qty = Convert.ToInt32(tb_qty.Text);
                price = Convert.ToDouble(tb_price.Text);
                double value = obj.getOrderValue(qty,price);
            MessageBox.Show("Order Value is:" + value);
            }

        }

      

       
       
     
    }
}
