﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day2_OOP1
{
    class Test2
    {
        public string CustomerName { get; set; }
    }
}
