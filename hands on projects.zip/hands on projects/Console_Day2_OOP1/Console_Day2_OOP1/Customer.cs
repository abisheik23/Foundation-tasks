﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day2_OOP1
{
    class Customer
    {
        private int customerId;
        private string customerName;
        private string customerAddress;
        private  int CustomerAge;

        
        public Customer(int customerId, string customerName, string customerAddress, int CustomerAge)
        {
            this.customerId = customerId;
            this.customerName = customerName;
            this.customerAddress = customerAddress;
            this.CustomerAge = CustomerAge;
            Console.WriteLine("With Parameter");
        }

        public string GetcustomerDetails()
        {
            customerId = 5000;
            return this.customerId + "  " + customerName;
        }
        public int GetCustomerAge()
        {
            return CustomerAge;
        }
    
    }
}