﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day2_OOP1
{
    class Student
    {
        int StudentID;
        public int PStudentID
        {
            get
            {
                return StudentID;
            }
            set
            {
                this.StudentID = value;
            }
        }
        string StudentName;
        public string PStudentName
        {
            get
            {
                return StudentName;
            }
            set
            {
                StudentName = value;
            }
        }
        int StudentMarks;
        bool StudentStatus;
        public int PstudentMarks
        {
            get
            {
                return StudentMarks;
            }
            set
            {
                if (value > 100 || value < 0)
                {
                    StudentMarks = 0;
                }
                else
                {
                    StudentMarks = value;
                    if (StudentMarks > 50)
                    {
                        StudentStatus = true;
                    }
                    else 
                    {
                        StudentStatus = false;
                    }
                }
            }
        }
        public bool PstudentStatus
        {
            get
            {
                return StudentStatus;
            }
           
        }
        public Student(int StudentID,string StudentName)
        {
          this.StudentID=StudentID;
          this.StudentName=StudentName;
        }
        
    }
}
