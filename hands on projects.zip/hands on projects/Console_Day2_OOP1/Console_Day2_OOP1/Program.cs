﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day2_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Test2 objtest = new Test2();
            objtest.CustomerName = "ABC";
            Student st = new Student(100,"ABCD");
            Console.WriteLine(st.PStudentID);
            st.PStudentName = "XYZ";
            Console.WriteLine(st.PStudentName);
            st.PstudentMarks = 93;
            Console.WriteLine(st.PstudentMarks);
            Console.WriteLine(st.PstudentStatus);
           
           
            /* Console.Write("Enter Customer Id:");
            int customerId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Customer Name:");
            string customerName =Console.ReadLine();
            Console.Write("Enter Customer Address:");
            string customerAddress = Console.ReadLine();
            Console.Write("Enter Customer Age:");
            int CustomerAge = Convert.ToInt32(Console.ReadLine());
            Customer obj = new Customer(customerId, customerName, customerAddress, CustomerAge);
            String details = obj.GetcustomerDetails();
            Console.WriteLine(details);*/
            Console.ReadKey();

        }
    }
}
