﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sum_library
{
    public class sum
    {
        public int GetSum(int num1, int num2)
        {
            int total = num1 + num2;
            return total;
        }
    }
}
