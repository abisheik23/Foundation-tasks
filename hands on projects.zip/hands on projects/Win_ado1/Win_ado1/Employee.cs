﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ado1
{
    class Employee
    {
        public int employeeid { get; set; }
        public string employeename { get; set; }
        public string employeecity { get; set; }
        public int employeeage { get; set; }
        public string employeepassword { get; set; }

    }
}
