﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace Win_ado1
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            tb_id.Text = "";
            tb_name.Text = "";
            cb_city.SelectedIndex =-1;
            tb_age.Text = "";
            tb_pass.Text = "";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {

            Employee obj = new Employee();
            obj.employeename = tb_name.Text;
            obj.employeecity = cb_city.Text;
            obj.employeeage = Convert.ToInt32(tb_age.Text);
            obj.employeepassword = tb_pass.Text;

            EmployeeDAL dal = new EmployeeDAL();
            dal.AddEmployee(obj);
            MessageBox.Show("Employee added Successfully: "+obj.employeeid);
           
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            con.Open();
                SqlCommand com_emp_find=
                    new SqlCommand("select * from employees where employeeid=@empid",con);
            com_emp_find.Parameters.AddWithValue("@empid",tb_id.Text);
            SqlDataReader dr = com_emp_find.ExecuteReader();
            if (dr.Read())
            {
                tb_id.Text = dr.GetInt32(0).ToString();
                tb_name.Text = dr.GetString(1);
                cb_city.Text = dr.GetString(2);
                tb_age.Text = dr.GetInt32(3).ToString();
                tb_pass.Text = dr.GetString(4);
            }
            else
            {
                MessageBox.Show("Employee Not Found");
            }
            con.Close();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            
             con.Open();
            SqlCommand com_update_emp = new SqlCommand
            ("update employees set employeename=@empname,employeecity=@empcity where employeeid=@empid", con);

            com_update_emp.Parameters.AddWithValue("@empname", tb_name.Text);
            com_update_emp.Parameters.AddWithValue("@empcity", cb_city.Text);
            com_update_emp.Parameters.AddWithValue("@empid", tb_id.Text);

            int rowsaffected = com_update_emp.ExecuteNonQuery();
            con.Close();
            if (rowsaffected > 0)
            {
                MessageBox.Show("Employee Updated");

            }
            else
            {
                MessageBox.Show("Employee Not Updated");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_cities = new SqlCommand("select cityname from cities", con);
            SqlDataReader dr = com_cities.ExecuteReader();
            while (dr.Read())
            {
                cb_city.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
    }
}
