﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ado1
{
    class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddEmployee(Employee obj)
        {
            con.Open();
            SqlCommand com_emp_insert =
                new SqlCommand("Insert Employees values(@empname,@empcity,@empage,@emppwd)", con);
            com_emp_insert.Parameters.AddWithValue("@empname", obj.employeename);
            com_emp_insert.Parameters.AddWithValue("@empcity", obj.employeecity);
            com_emp_insert.Parameters.AddWithValue("@empage", obj.employeeage);
            com_emp_insert.Parameters.AddWithValue("@emppwd", obj.employeepassword);
            com_emp_insert.ExecuteNonQuery();
            SqlCommand com_empid = new SqlCommand("select @@identity", con);
            int empid = Convert.ToInt32(com_empid.ExecuteScalar());
            obj.employeeid = empid;
            con.Close();
            return true;
        }
    }
}
