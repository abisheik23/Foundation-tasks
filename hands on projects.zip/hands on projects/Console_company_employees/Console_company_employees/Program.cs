﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_company_employees
{
    class Program
    {
        static void Main(string[] args)
        {
            Company comp = new Company(1001, "Inautix");
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Add:1 Remove:2 Find:3 Show:4 Exit:5 Company Approval:6");
                Console.Write("Enter the option:");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.Write("Enter the Employee ID:");
                        int eID = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter the Employee Name:");
                        string ename = Console.ReadLine();
                        Console.Write("Enter the Employee City:");
                        string ecity = Console.ReadLine();
                        Employee obj = new Employee(eID, ename, ecity);
                        comp.AddEmployee(obj);
                        Console.WriteLine("Data Entered Successfully");
                        break;

                    case 2:
                        Console.Write("Enter the Employee ID:");
                        int employeeID = Convert.ToInt32(Console.ReadLine());
                        bool status = comp.RemoveEmployee(employeeID);
                        if (status == true)
                        {
                            Console.WriteLine("Employee Removed");

                        }
                        else
                        {
                            Console.WriteLine("Employee Not Removed");
                        }
                        break;
                    case 3:
                        Console.Write("Enter EmpID:");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        Employee emp = comp.SearchEmployee(eid);
                        if (emp == null)
                        {
                            Console.WriteLine("Employee Not Found");
                        }
                        else
                        {
                            Console.WriteLine("Enter 1:show  2:Leave Request");
                            int option = Convert.ToInt32(Console.ReadLine());
                            if (option == 1)
                            {
                                Console.WriteLine(emp.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Enter the Reason:");
                                string reason = Console.ReadLine();
                                emp.RequestLeave(reason);

                            }
                        }
                        break;
                    case 4:
                        comp.ShowEmployees();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        comp.employee_leave_request_approval();
                        break;
                }
            }
        }
    }
}
