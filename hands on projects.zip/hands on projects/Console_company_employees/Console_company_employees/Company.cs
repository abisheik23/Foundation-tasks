﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_company_employees
{
    class Company
    {
        int CompanyID;
        string CompanyName;
        List<Employee> emplist = new List<Employee>();
        List<Employee> emplist_leave_request=new List<Employee>();
        public Company(int CompanyID, string CompanyName)
        {
            this.CompanyID = CompanyID;
            this.CompanyName = CompanyName;
        }
        public void notify(int EmpID, string msg)
        {
            Console.WriteLine("ID :" + EmpID + "Reason: " + msg);
            emplist_leave_request.Add(SearchEmployee(EmpID));
        }
        public void AddEmployee(Employee emp)
        {
            emplist.Add(emp);
            emp.evt_leave_request+=new Employee.delleave(notify);
        }
        public void employee_leave_request_approval()
        {
            foreach (Employee e in emplist_leave_request)
            {
                e.Leave_Approval();
                Console.WriteLine("Approved by Company:" + e.PEmpID);
            }
            emplist_leave_request.Clear();
        }
        public bool RemoveEmployee(int EmpID)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpID)
                {
                    emplist.Remove(e);
                    return true;
                }
            }
            return false;
        }
        public Employee SearchEmployee(int EmpID)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpID)
                {
                    return e;
                }
            }
            return null;
        }
        public void ShowEmployees()
        {
            foreach (Employee e in emplist)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
