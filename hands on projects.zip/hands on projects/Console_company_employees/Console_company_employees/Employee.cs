﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_company_employees
{
    class Employee
    {
        public delegate void delleave(int EmpID, string msg);
        public event delleave evt_leave_request;
        public void RequestLeave(string msg)
        {
            if (evt_leave_request != null)
            {
                evt_leave_request(EmpID, msg);
            }

        }
        bool leave_status = false;
        public bool Pstatus
        {
            get
            {
                return leave_status;
            }
        }
        public void Leave_Approval()
        {
            leave_status = true;
        }
        int EmpID;
        public int PEmpID
        {
            get
            {
                return EmpID;
            }
        }
        string EmpName;
        string EmpCity;
        public Employee(int EmpID, string EmpName, string EmpCity)
        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.EmpCity = EmpCity;
        }
        public override string ToString()
        {
            return EmpID + "  " + EmpName + "  " + EmpCity+" "+leave_status;
        }


      
    }
}
