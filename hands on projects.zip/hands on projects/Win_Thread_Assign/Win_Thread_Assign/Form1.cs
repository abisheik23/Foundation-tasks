﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_Thread_Assign
{
    public partial class Form1 : Form
    {
        
       
        public Form1()
        {
            InitializeComponent();
        }
        public delegate int del_calc(int n1,int n2,string s);
        public int doCalc(int n1,int n2,string s)
        {
            if (s == "+")
            {
                return n1 + n2;
            }
            else if(s=="-")
            {
                return n1-n2;
            }
            else if (s == "X")
            {
                return n1 * n2;
            }
            else
            {
                return n1 / n2;
            }
        }
        public delegate void del();
        del_calc r;
        public void callback(IAsyncResult res)
        {
            
            int result=r.EndInvoke(res);
            del delobj = delegate()
            {
                lst_result.Items.Add("Result of "+res.AsyncState + " : " + result);
            };
            this.BeginInvoke(delobj);
        }
        private void btn_plus_Click(object sender, EventArgs e)
        {
            string sy = "+";
            r = new del_calc(doCalc);
            r.BeginInvoke(Convert.ToInt32(tb_num1.Text), Convert.ToInt32(tb_num2.Text), sy, new AsyncCallback(callback), tb_num1.Text + sy + tb_num2.Text);
           
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {
            string sy = "-";
            r = new del_calc(doCalc);
            r.BeginInvoke(Convert.ToInt32(tb_num1.Text), Convert.ToInt32(tb_num2.Text), sy, new AsyncCallback(callback), tb_num1.Text + sy + tb_num2.Text);
        }

        private void btn_star_Click(object sender, EventArgs e)
        {
            string sy = "X";
            r = new del_calc(doCalc);
            r.BeginInvoke(Convert.ToInt32(tb_num1.Text), Convert.ToInt32(tb_num2.Text), sy, new AsyncCallback(callback), tb_num1.Text + sy + tb_num2.Text);
        }

        private void btn_div_Click(object sender, EventArgs e)
        {
            string sy = "/";
            r = new del_calc(doCalc);
            r.BeginInvoke(Convert.ToInt32(tb_num1.Text), Convert.ToInt32(tb_num2.Text), sy, new AsyncCallback(callback), tb_num1.Text + sy + tb_num2.Text);
        }
    }
}
