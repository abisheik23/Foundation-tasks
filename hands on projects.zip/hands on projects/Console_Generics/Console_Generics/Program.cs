﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Console_Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int,string> names=new Dictionary<int,string>();
            names.Add(1001,"abcd");
            names.Add(1002,"xyz");
            Console.WriteLine(names[1001]);
            /*List<int> marks = new List<int>();
            marks.Add(80);
            marks.Add(90);
            marks.Add(30);
            int x = marks[0];
            Console.WriteLine(x);
            int y=marks.Count;
            Console.WriteLine(y);
            marks.Remove(80);
            foreach (int i in marks)
            {

                Console.WriteLine(i);
            }
            int z = marks.Count;
            Console.WriteLine(z);

            ArrayList List = new ArrayList();
            List.Add("Abc");
            List.Add(1500);
            List.Add(true);
            int i = 100;
            List.Add(i);
            int x = Convert.ToInt32(List[1]);
            string str = List[0].ToString();
            Console.WriteLine(x);
            Console.WriteLine(str);
            Test obj = new Test();
            int i = obj.getData<int>(100);
            string str = obj.getData<string>("hello");
            Console.WriteLine(i);
            Console.WriteLine(str);*/
            Console.ReadKey();
        }
    }
}
