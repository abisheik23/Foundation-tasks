﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_SingleTon_Day2
{
    class Manager
    {
        string ManagerName;
        int ManagerId;
        public string PManagerName
        {
            get
            {
                return ManagerName;
            }
        }
        public int PManagerId
        {
            get
            {
                return ManagerId;
            }
        }
        private Manager(string ManagerName,int ManagerId)
        {
            this.ManagerName=ManagerName;
            this.ManagerId=ManagerId;
        }
        static Manager m;
        public static Manager GetManager()
        {
            if (m == null)
            {
                m = new Manager("ABC", 1000);
            }
            return m;
        }
    
    }
}
