﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_SingleTon_Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager obj1 = Manager.GetManager();
            Manager obj2 = Manager.GetManager();
            if (obj1 == obj2)
            {
                Console.WriteLine("Same Manager");
            }
            Console.ReadKey();
        }
    }
}
