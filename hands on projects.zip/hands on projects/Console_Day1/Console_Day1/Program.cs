﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Employee ID:");
            string empid = Console.ReadLine();
            Console.WriteLine("Enter Employee Name:");
            string empname = Console.ReadLine();
            Console.WriteLine("Employee Details.....");
            Console.WriteLine("Employee ID:" + empid);
            Console.WriteLine("Employee Name:" + empname);
            
            Console.ReadKey();

        }
    }
}
