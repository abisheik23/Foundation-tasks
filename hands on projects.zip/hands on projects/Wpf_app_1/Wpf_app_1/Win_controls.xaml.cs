﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_app_1
{
    /// <summary>
    /// Interaction logic for Win_controls.xaml
    /// </summary>
    public partial class Win_controls : Window
    {
        public Win_controls()
        {
            InitializeComponent();
        }

        private void s_no_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (s_no.Value != null && tb_no!=null)
            {
                tb_no.Text = s_no.Value.ToString();
            }
        }
    }
}
