﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_app_1
{
    /// <summary>
    /// Interaction logic for win_newuser.xaml
    /// </summary>
    public partial class win_newuser : Window
    {
        public win_newuser()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            tb_cid.Text = App.Current.Properties["userid"].ToString();

        }
    }
}
