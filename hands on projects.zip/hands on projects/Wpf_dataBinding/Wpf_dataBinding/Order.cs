﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_dataBinding
{
    class Order
    {
        public int OrderId { get; set; }
        public int customerid { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderAddress { get; set; }
        public int ProductID { get; set; }
        public int ProductPrice { get; set; }
        public int Productqty { get; set; }
    }

}
