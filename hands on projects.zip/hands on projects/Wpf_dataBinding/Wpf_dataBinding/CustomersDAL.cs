﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
namespace Wpf_dataBinding
{
    class CustomersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["order"].ConnectionString);
        public bool Login(Customers obj)
        {
            con.Open();
            SqlCommand com_cus_login = new SqlCommand("select count(*) from customers where customerid=@cusid and customerpassword=@cuspass",con);
            com_cus_login.Parameters.AddWithValue("@cusid", obj.CustomerID);
            com_cus_login.Parameters.AddWithValue("@cuspass", obj.CustomerPassword);
            int count = Convert.ToInt32(com_cus_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
