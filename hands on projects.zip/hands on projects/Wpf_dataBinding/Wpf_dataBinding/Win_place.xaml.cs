﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_dataBinding
{
    /// <summary>
    /// Interaction logic for Win_place.xaml
    /// </summary>
    public partial class Win_place : Window
    {
        public Win_place()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ProductsDAL dal=new ProductsDAL();
            lst_products.ItemsSource = dal.Getproducts();
        }

        private void btn_place_Click(object sender, RoutedEventArgs e)
        {
            Product p = lst_products.SelectedItem as Product;
            if (p != null)
            {
                ordersDAL dal = new ordersDAL();
                Order ord = new Order();
                ord.ProductID = p.ProductID;
                ord.ProductPrice = p.ProductPrice;
                ord.Productqty = Convert.ToInt32(tb_qty.Text);
                ord.OrderAddress = tb_address.Text;
                ord.customerid = Convert.ToInt32(App.Current.Properties["cid"]);
                dal.PlaceOrder(ord);
                MessageBox.Show("Order Placed successfully:"+ord.OrderId);
            }
            else
            {
                MessageBox.Show("Select A Product");
            }
        }
    }
}
