﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_dataBinding
{
    /// <summary>
    /// Interaction logic for Win_Home.xaml
    /// </summary>
    public partial class Win_Home : Window
    {
        public Win_Home()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            tb_cid.Text ="Customer ID:"+ App.Current.Properties["cid"].ToString();
        }

        private void btn_place_Click(object sender, RoutedEventArgs e)
        {
            Win_place obj = new Win_place();
            obj.Show();
        }

        private void btn_show_Click(object sender, RoutedEventArgs e)
        {
            win_show obj = new win_show();
            obj.Show();
        }

        private void btn_find_Click(object sender, RoutedEventArgs e)
        {
            Win_find obj = new Win_find();
            obj.Show();
        }
    }
}
