﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_dataBinding
{
    /// <summary>
    /// Interaction logic for win_show.xaml
    /// </summary>
    public partial class win_show : Window
    {
        public win_show()
        {
            InitializeComponent();
        }
        private void btn_show_orders_Click(object sender, RoutedEventArgs e)
        {
            ordersDAL dal = new ordersDAL();
            int Customerid = Convert.ToInt32(App.Current.Properties["cid"]);
            dg_orders.ItemsSource = dal.getOrders(Customerid);
        }
    }
}
