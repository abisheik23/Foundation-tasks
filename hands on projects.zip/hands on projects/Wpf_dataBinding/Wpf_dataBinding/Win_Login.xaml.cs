﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_dataBinding
{
    /// <summary>
    /// Interaction logic for Win_Login.xaml
    /// </summary>
    public partial class Win_Login : Window
    {
        public Win_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            CustomersDAL dal = new CustomersDAL();
            Customers c = new Customers();
            c.CustomerID = Convert.ToInt32(tb_id.Text);
            c.CustomerPassword = tb_pass.Password;

            if (dal.Login(c))
            {
                MessageBox.Show("Valid Customer");
                App.Current.Properties.Add("cid", tb_id.Text);
                Win_Home home = new Win_Home();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Customer");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
