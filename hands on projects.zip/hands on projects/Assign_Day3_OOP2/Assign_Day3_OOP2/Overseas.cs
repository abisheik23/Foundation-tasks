﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Day3_OOP2
{
    class Overseas:Order
    {
        public Overseas(int itemqty, double itemprice)
            : base(itemqty, itemprice)
        {
        }
        public override double calc(int itemqty, double itemprice)
        {
            
            return (itemqty*itemprice)+1200;
        }
    }
}
