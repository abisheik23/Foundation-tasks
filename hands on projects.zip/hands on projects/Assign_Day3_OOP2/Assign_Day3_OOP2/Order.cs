﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Day3_OOP2
{
    class Order
    {
        int OrderID;
        string custname;
        protected int itemqty;
        protected double itemprice;
        public int POrderId { get { return OrderID; } }
        public string Pcustname 
        {
            get
            {
                return custname;
            }

            set
            {
                custname = value;
            }
        
        }
        public Order(int Order)
        {
            this.OrderID = OrderID;
        }
        public Order(int itemqty, double itemprice)
        {
            this.itemqty = itemqty;
            this.itemprice = itemprice;
        }
        public virtual double calc(int itemqty, double itemprice)
        {
            return itemprice * itemqty;
        }
    }
 }
