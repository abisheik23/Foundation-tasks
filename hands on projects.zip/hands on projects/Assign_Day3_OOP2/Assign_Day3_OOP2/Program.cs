﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Day3_OOP2
{
    class Program
    {
        static void Main(string[] args)
        {
            double total;
            Console.Write("Enter the Order ID:");
            int oid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Customer Name:");
            string cusname = Console.ReadLine();
            Order obj=new Order(oid);
            obj.Pcustname = cusname;
            Console.Write("Enter The type of Order:");
            string type = Console.ReadLine();
            if (type == "Overseas" || type == "overseas")
            {
                Console.Write("Enter The Order Quantity:");
                int qty = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the Order price:");
                double price = Convert.ToDouble(Console.ReadLine());
                obj = new Overseas(qty, price);
                total = obj.calc(qty, price);
                Console.WriteLine("Total Price Of the Order Is " + total);

            }
            else
            {
                Console.Write("Enter The Order Quantity:");
                int qty = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the Order price:");
                double price = Convert.ToDouble(Console.ReadLine());
                obj = new Order(qty, price);
                total = obj.calc(qty, price);
                Console.WriteLine("Total Price Of the Order Is " + total);
            }
            Console.ReadKey();
        }
    }
}
