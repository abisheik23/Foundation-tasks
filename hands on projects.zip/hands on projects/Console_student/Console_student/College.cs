﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_student
{
    class College
    {
        string cName;
        List<Student> slist = new List<Student>();
        List<Student> slist_leave_request = new List<Student>();
        public College(string cName)
        {
            this.cName = cName;
        }
        public void AddStudent(Student std)
        {
            slist.Add(std);
            std.evt_leave_request += new Student.delleave(notify);
        }
        public void notify(string sID, string msg)
        {
            Console.WriteLine("ID :" + sID + "\nReason: " + msg);
            slist_leave_request.Add(SearchStudent(sID));
        }
        public void student_leave_request_approval()
        {
            foreach (Student s in slist_leave_request)
            {
                s.Leave_Approval();
                Console.WriteLine("Approved by College:" + s.PsID);
            }
            slist_leave_request.Clear();
        }
        public Student SearchStudent(string sID)
        {
            foreach (Student s in slist)
            {
                if (s.PsID == sID)
                {
                    return s;
                }
            }
            return null;
        }
        public void ShowStudents()
        {
            foreach (Student s in slist)
            {
                Console.WriteLine(s.ToString());
            }
        }
    }
}
