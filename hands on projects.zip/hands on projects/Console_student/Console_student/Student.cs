﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_student
{
    class Student
    {
        public delegate void delleave(string sID, string msg);
        public event delleave evt_leave_request;
        public void RequestLeave(string msg)
        {
            if (evt_leave_request != null)
            {
                evt_leave_request(sID, msg);
            }

        }
        bool leave_status = false;
        public bool Pstatus
        {
            get
            {
                return leave_status;
            }
        }
        public void Leave_Approval()
        {
            leave_status = true;
        }
        string sID;
        public string PsID { get { return sID; } }
        string sName;
        public Student(string sID, string sName)
        {
            this.sID = sID;
            this.sName = sName;
        }
        public override string ToString()
        {
            return sID + "  " + sName + "  " + leave_status;
        }
    }
}
