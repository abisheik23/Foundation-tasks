﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_student
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College("IIT-M");
            bool flag = true;
            do
            {
                Console.WriteLine("1.Add 2.Apply Leave 3.College Approval  4.Show 5.Exit");
                Console.Write("Enter The option:");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        Console.Write("Enter the Student ID:");
                        string sID = Console.ReadLine();
                        Console.Write("Enter the Student Name:");
                        string sname = Console.ReadLine();
                        Student std = new Student(sID, sname);
                        c.AddStudent(std);
                        Console.WriteLine("Data Entered Successfully");
                        break;
                    case 2:
                        Console.Write("Enter  Student ID:");
                        string sid = Console.ReadLine();
                        Student s = c.SearchStudent(sid);
                        if (s == null)
                        {
                            Console.WriteLine("Student Not Found");
                        }
                        else
                        {
                            Console.Write("Enter the Reason:");
                            string reason = Console.ReadLine();
                            s.RequestLeave(reason);
                        }
                        break;
                    case 3:
                        c.student_leave_request_approval();
                        break;
                    case 4:
                        c.ShowStudents();
                        break;
                    case 5:
                        flag = false;
                        break;
                }

            } while (flag == true);
        }
    }
}
