﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    class XYZ:IDisposable
    {
        public void Dispose()
        {
            Console.WriteLine("Disposable");
        }
    }
}
