﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_assign
{
    /// <summary>
    /// Interaction logic for Win_home.xaml
    /// </summary>
    public partial class Win_home : Window
    {
        public Win_home()
        {
            InitializeComponent();
        }

        private void btn_calc_Click(object sender, RoutedEventArgs e)
        {
            Win_calc obj = new Win_calc();
            obj.Show();
            this.Close();
        }

        private void btn_order_Click(object sender, RoutedEventArgs e)
        {
            Win_order obj = new Win_order();
            obj.Show();
            this.Close();
        }
    }
}
