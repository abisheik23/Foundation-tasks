﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class Frm_Home : Form
    {
        public Frm_Home()
        {
            InitializeComponent();
        }


        private void btn_city_Click(object sender, EventArgs e)
        {
            string gender = "";
            if (lst_city.Text == "")
            {
                MessageBox.Show("Select a City");
            }
            else
            {
                string city = lst_city.Text;
                MessageBox.Show(city);
            }
            if (cb_status.Checked)
            {
                MessageBox.Show("Order is completed");
            }
            else
            {
                MessageBox.Show("Order is pending");
            }
            if (gender == "")
            {
                MessageBox.Show("Select the Gender");
            }
            else
            {
                if (rb_male.Checked)
                {
                    gender = "Male";
                }
                else if (rb_female.Checked)
                {
                    gender = "Female";
                }
            }
        }

     private void Frm_Home_Load(object sender, EventArgs e)
        {
            lst_city.Items.Add("Chennai");
            lst_city.Items.Add("Coimbatore");
            lst_city.Items.Add("Bangalore");
            lst_city.Items.Add("Kolkata");
            lst_city.Items.Add("Mumbai");
            lst_city.Items.Add("New Delhi");

            cb_list.Items.Add("Pendrive");
            cb_list.Items.Add("Laptop");
        }

        private void cb_status_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
