﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_Click(object sender, EventArgs e)
        {
            string userid = tb_login.Text;
            string password = tb_pass.Text;
            if (userid == "")
            {
                MessageBox.Show("Enter User ID");
            }
            else if (password == "")
            {
                MessageBox.Show("Enter The Password");

            }
            else
            {
                if (userid == "abisheik23" && password == "password")
                {
                    MessageBox.Show("Valid User");
                    Frm_Home obj = new Frm_Home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }

        }
    }
}
