﻿namespace Win_First_Application
{
    partial class Frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_city = new System.Windows.Forms.ListBox();
            this.btn_city = new System.Windows.Forms.Button();
            this.cb_list = new System.Windows.Forms.ComboBox();
            this.cb_status = new System.Windows.Forms.CheckBox();
            this.rb_male = new System.Windows.Forms.RadioButton();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lst_city
            // 
            this.lst_city.FormattingEnabled = true;
            this.lst_city.Location = new System.Drawing.Point(51, 52);
            this.lst_city.Name = "lst_city";
            this.lst_city.Size = new System.Drawing.Size(120, 95);
            this.lst_city.TabIndex = 0;
            // 
            // btn_city
            // 
            this.btn_city.Location = new System.Drawing.Point(232, 52);
            this.btn_city.Name = "btn_city";
            this.btn_city.Size = new System.Drawing.Size(123, 57);
            this.btn_city.TabIndex = 1;
            this.btn_city.Text = "Get City";
            this.btn_city.UseVisualStyleBackColor = true;
            this.btn_city.Click += new System.EventHandler(this.btn_city_Click);
            // 
            // cb_list
            // 
            this.cb_list.FormattingEnabled = true;
            this.cb_list.Location = new System.Drawing.Point(384, 54);
            this.cb_list.Name = "cb_list";
            this.cb_list.Size = new System.Drawing.Size(121, 21);
            this.cb_list.TabIndex = 2;
            this.cb_list.Text = "select the item";
            // 
            // cb_status
            // 
            this.cb_status.AutoSize = true;
            this.cb_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_status.Location = new System.Drawing.Point(84, 235);
            this.cb_status.Name = "cb_status";
            this.cb_status.Size = new System.Drawing.Size(118, 20);
            this.cb_status.TabIndex = 3;
            this.cb_status.Text = "Is Completed";
            this.cb_status.UseVisualStyleBackColor = true;
            this.cb_status.CheckedChanged += new System.EventHandler(this.cb_status_CheckedChanged);
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_male.Location = new System.Drawing.Point(281, 235);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(57, 19);
            this.rb_male.TabIndex = 4;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "Male";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_female.Location = new System.Drawing.Point(408, 235);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(73, 19);
            this.rb_female.TabIndex = 5;
            this.rb_female.TabStop = true;
            this.rb_female.Text = "Female";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // Frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 448);
            this.Controls.Add(this.rb_female);
            this.Controls.Add(this.rb_male);
            this.Controls.Add(this.cb_status);
            this.Controls.Add(this.cb_list);
            this.Controls.Add(this.btn_city);
            this.Controls.Add(this.lst_city);
            this.Name = "Frm_Home";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Frm_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_city;
        private System.Windows.Forms.Button btn_city;
        private System.Windows.Forms.ComboBox cb_list;
        private System.Windows.Forms.CheckBox cb_status;
        private System.Windows.Forms.RadioButton rb_male;
        private System.Windows.Forms.RadioButton rb_female;
    }
}