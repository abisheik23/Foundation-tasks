﻿namespace Win_sum
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_n1 = new System.Windows.Forms.Label();
            this.lb_n2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btn_sum = new System.Windows.Forms.Button();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lb_n1
            // 
            this.lb_n1.AutoSize = true;
            this.lb_n1.Location = new System.Drawing.Point(51, 42);
            this.lb_n1.Name = "lb_n1";
            this.lb_n1.Size = new System.Drawing.Size(44, 13);
            this.lb_n1.TabIndex = 0;
            this.lb_n1.Text = "NUM 1:";
            // 
            // lb_n2
            // 
            this.lb_n2.AutoSize = true;
            this.lb_n2.Location = new System.Drawing.Point(54, 124);
            this.lb_n2.Name = "lb_n2";
            this.lb_n2.Size = new System.Drawing.Size(44, 13);
            this.lb_n2.TabIndex = 1;
            this.lb_n2.Text = "NUM 2:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(167, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(139, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(167, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(139, 20);
            this.textBox2.TabIndex = 3;
            // 
            // btn_sum
            // 
            this.btn_sum.Location = new System.Drawing.Point(57, 229);
            this.btn_sum.Name = "btn_sum";
            this.btn_sum.Size = new System.Drawing.Size(135, 23);
            this.btn_sum.TabIndex = 4;
            this.btn_sum.Text = "Get Sum";
            this.btn_sum.UseVisualStyleBackColor = true;
            this.btn_sum.Click += new System.EventHandler(this.btn_sum_Click);
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(276, 229);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(100, 20);
            this.tb_total.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 273);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.btn_sum);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lb_n2);
            this.Controls.Add(this.lb_n1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_n1;
        private System.Windows.Forms.Label lb_n2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btn_sum;
        private System.Windows.Forms.TextBox tb_total;
    }
}

