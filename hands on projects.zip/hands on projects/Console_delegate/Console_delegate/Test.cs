﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Test
    {
        public delegate void del(string str);
        public void getData(string msg)
        {
            Console.WriteLine("Getdata " + msg);
        }
        public void setdata(string str)
        {
            Console.WriteLine("Setdata " + str);
        }
        public void bind()
        {
            del obj = new del(getData);
            obj += new del(setdata);
            obj -= new del(getData);
           
            obj += delegate(string str)
            {
                Console.WriteLine(str);
            };
            obj("Hello");
        }
    }
}
