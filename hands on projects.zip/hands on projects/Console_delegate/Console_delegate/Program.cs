﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Test t = new Test();
            t.bind();*/
            EventTesting obj = new EventTesting();
            //obj.bind();
            obj.fire();
            
            Console.ReadKey();
        }
    }
}
