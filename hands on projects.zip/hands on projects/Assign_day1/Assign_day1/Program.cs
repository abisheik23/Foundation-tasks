﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Assign_day1 {
    class Program {
        static void Main(string[] args) {
            int balance=0;
            int AccId, value,p=1;
            string cus_name, cus_adr, type;
            do {
                Console.WriteLine("Banking System\n1.Creating Account\n2.Deposit\n3.WithDraw\n4.check balance\n5.Exit\n==================================================");
                Console.Write("Enter Your Choice:");
                int choice = Convert.ToInt16(Console.ReadLine());
                switch (choice) {
                    case 1:
                        balance = 0;
                        Console.WriteLine("Creating the account");
                        Console.Write("Enter the Account Number:");
                        AccId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter the Your Name:");
                        cus_name = Console.ReadLine();
                        Console.Write("Enter the Your Address:");
                        cus_adr = Console.ReadLine();
                        Console.Write("Enter the Account Type:");
                        type = Console.ReadLine();
                        Console.Write("Enter the Amount Depositing:");
                        value = Convert.ToInt16(Console.ReadLine());
                        if (value >= 500) {
                            balance += value;
                            Console.WriteLine("Your Amount $" + balance + " has been deposited.....");
                        }
                        else {
                          Console.WriteLine("Put more than $500");
                        }
                        break;
                    case 2:
                        Console.WriteLine("Deposit your amount");
                        Console.Write("Enter the Account Number:");
                        AccId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter the Amount Depositing:");
                        value = Convert.ToInt16(Console.ReadLine());
                        if (value >= 500) {
                            balance += value;
                            Console.WriteLine("Your Amount $" + value + " has been deposited and balance is $" + balance);
                        }
                        else {
                            Console.WriteLine("Put more than $500");
                        }
                        break;
                    case 3:
                        Console.WriteLine("WithDraw your amount.....");
                        Console.Write("Enter the Account Number:");
                        AccId = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter the Amount Withdrawing:");
                        value = value = Convert.ToInt16(Console.ReadLine());
                        if (value > 5000) {
                            Console.WriteLine("WithDraw Amount Less Than 5000....");
                        }
                        else {
                            if (balance - value >= 500) {
                                balance -= value;
                            }
                            else {
                                Console.WriteLine("Minimum must above or equal to 500");
                                Console.WriteLine("$" + value + " has been withdrawn from your account and balance is $" + balance);
                            }
                        }
                        break;
                    case 4:
                        Console.WriteLine("Your balance is $" + balance);
                        break;
                    case 5:
                        Console.WriteLine("Exiting Account....");
                        p = 0;
                        break;
                    default: 
                        Console.WriteLine("No Such Option");
                        break;
                }
            } while (p==1);
            Console.WriteLine("==================================================");
            Console.ReadKey();
        }
    }
}

      