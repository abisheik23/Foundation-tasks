﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day3_OOP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter CustomerID:");
            int custid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter CustomerName:");
            string custname = Console.ReadLine();
            Console.Write("Enter the type of CustomerName:");
            string type = Console.ReadLine();
            if (type == "Customer"|| type=="customer")
            {
                Customer obj = new Customer(custid, custname);
                string details = obj.GetDetails();
                Console.WriteLine("details");
            }
            else
            {
                Console.Write("Enter Address:");
                string address = Console.ReadLine();
                Customer_Special obj = new Customer_Special(custid, custname, address, 1000);
                string details = obj.GetDetails();
                Console.WriteLine(details);
                string add = obj.GetAddress();
                Console.WriteLine(add);
            }
                Console.ReadKey();
        }
    }
}
