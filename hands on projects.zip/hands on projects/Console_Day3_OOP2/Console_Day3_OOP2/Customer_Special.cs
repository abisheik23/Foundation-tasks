﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Day3_OOP2
{
    class Customer_Special:Customer
    {
        string CustomerAddress;
        int CreditLimit;
        bool paymentstatus;
        public Customer_Special(int CustomerID,string CustomerName,string CustomerAddress,int CreditLimit):base(CustomerID,CustomerName)
        {
            this.CustomerAddress =CustomerAddress;
            this.CreditLimit = CreditLimit;
        }
        public string GetAddress()
        {
            return CustomerAddress;
        }
    }
}
