﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ado1
{
    public partial class Frm_ShowEmployees : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Frm_ShowEmployees()
        {
            InitializeComponent();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            
            SqlDataAdapter data = new SqlDataAdapter("Select * from employees", con);
            DataSet ds = new DataSet();
            data.Fill(ds, "emp");
            dg_show.DataSource = ds.Tables["emp"];
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            SqlDataAdapter data_employees = new SqlDataAdapter("Select * from employees where employeecity=@city", con);
            data_employees.SelectCommand.Parameters.AddWithValue("@city", tb_search.Text);

            DataSet ds = new DataSet();
            data_employees.Fill(ds, "emp");
            if (ds.Tables["emp"].Rows.Count == 0)
            {
                MessageBox.Show("Employee Not Found");
            }
            else
            {
                dg_show.DataSource = ds.Tables["emp"];
            }
        }
    }
}
