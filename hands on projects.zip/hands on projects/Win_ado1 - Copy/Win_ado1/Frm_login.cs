﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace Win_ado1
{
    public partial class Frm_login : Form
    {
        
        public Frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand com_login = new
                SqlCommand("Select count(*) from employees where employeeid=@empid and employeepassword=@empass", con);
            com_login.Parameters.AddWithValue("@empid", tb_id.Text);
            com_login.Parameters.AddWithValue("@empass", tb_pass.Text);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                MessageBox.Show("Valid User");
                Form1 obj = new Form1();
                obj.Show();
            }
            else
            {
                MessageBox.Show("InValid User");
            }

        }
    }
}
