﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace Win_ado_assign
{
    public partial class Frm_Addcustomers : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["customer"].ConnectionString);
        public Frm_Addcustomers()
        {
            InitializeComponent();
        }
        private void btn_submit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cus_submit = new SqlCommand("insert customerinfo values(@cusname,@cuscity,@cusage,@cusdoj)", con);
            cus_submit.Parameters.AddWithValue("@cusname", tb_name.Text);
            cus_submit.Parameters.AddWithValue("@cuscity", cb_city.Text);
            cus_submit.Parameters.AddWithValue("@cusage", tb_age.Text);
            cus_submit.Parameters.AddWithValue("@cusdoj", tb_doj.Text);
            cus_submit.ExecuteNonQuery();
            SqlCommand cus_id = new SqlCommand("select customerid from customerinfo", con);
            int cusid = Convert.ToInt32(cus_id.ExecuteScalar());
            tb_id.Text = cusid.ToString();
            con.Close();
            MessageBox.Show("Customer added Successfully: " + cusid);
        }
        
        private void btn_find_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cus_find =
                new SqlCommand("select * from customerinfo where customerid=@cusid", con);
            cus_find.Parameters.AddWithValue("@cusid", tb_id.Text);
            SqlDataReader dr = cus_find.ExecuteReader();
            if (dr.Read())
            {
                tb_id.Text = dr.GetInt32(0).ToString();
                tb_name.Text = dr.GetString(1);
                cb_city.Text = dr.GetString(2);
                tb_age.Text = dr.GetInt32(3).ToString();
                tb_doj.Text = dr.GetDateTime(4).ToString();
            }
            else
            {
                MessageBox.Show("Customer Not Found");
            }
            con.Close();
        }

        private void Frm_Addcustomers_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cus_cities = new SqlCommand("select cityname from cities order by cityname", con);
            SqlDataReader dr = cus_cities.ExecuteReader();
            while (dr.Read())
            {
                cb_city.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            tb_id.Text = "";
            tb_name.Text = "";
            cb_city.SelectedIndex = -1;
            tb_age.Text = "";
            tb_doj.Text = "";
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Form1 h = new Form1();
            Hide();
            h.Show();
        }

        

      
    }
}
