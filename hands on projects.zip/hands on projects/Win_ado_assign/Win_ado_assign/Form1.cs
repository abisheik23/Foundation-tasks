﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace Win_ado_assign
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["customer"].ConnectionString);
            SqlCommand emp_login = new 
                SqlCommand(@"select count(*) from employees where employeeid=@empid and employeepassword=@empass",con);
            emp_login.Parameters.AddWithValue("@empid",tb_id.Text);
            emp_login.Parameters.AddWithValue("@empass", tb_pass.Text);
            con.Open();
            int count = Convert.ToInt32(emp_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                Frm_Addcustomers cus = new Frm_Addcustomers();
                Hide();
                cus.Show();
            }
            else
            {
                MessageBox.Show("Please Try Again");
            }

        }
    }
}
