﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Day2_OOP1
{
    class order
    {
         int orderId;
       public  static int count = 0;

        int itemId;
        int itemQty;
        double itemPrice;
        double orderValue;
        string customerName;

        public order()
        {
            this.itemId = 0;
            this.itemQty = 0;
            this.itemPrice = 0;
            this.orderValue = 0;
            count++;
            this.orderId = count;
        }
        public order(int itemQty,double itemPrice) : this()
        {
            this.itemQty = itemQty;
            this.itemPrice = itemPrice;
        }
        public int PorderId
        {
            get
            {
                return orderId;
            }
        }
        public int PitemId
        {
            get
            {
                return itemId;
            }
            set
            {
                itemId = value;
            }

        }
        public int PitemQty
        {
            get
            {
                return itemQty;
            }
            set
            {
                itemQty = value;
            }

        }
        public double PitemPrice
        {
            get
            {
                return itemPrice;
            }
            set
            {
                itemPrice = value;
            }
        }

        public double PorderValue
        {
            get
            {
                return itemPrice * itemQty;
            }
            
        }
        public string PcustomerName{get; set;}
     }
}
