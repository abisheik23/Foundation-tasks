﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assign_Day2_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int i=0;
            string stat="yes";
            while(i>=0)
            {
                Console.Write("Enter the Item Quantity:");
                int itemQty = Convert.ToInt16(Console.ReadLine());
                Console.Write("Enter the Item Price:");
                double itemPrice = Convert.ToDouble(Console.ReadLine());
            
               order o = new order(itemQty, itemPrice);
            Console.Write("Enter the Item Id:");
            o.PitemId = Convert.ToInt32(Console.ReadLine());
            
            
            Console.Write("Enter the Customer Name:");
            o.PcustomerName = Console.ReadLine();
            Console.WriteLine(o.PorderId);
            Console.WriteLine(o.PorderValue);
                Console.Write("Do you wish to Continue?");
                stat=Console.ReadLine();
                if(stat=="No"||stat=="no"||stat=="NO"||stat=="nO"||stat=="n"){
                  break;
                }
                else{
                i++;
                }
                
            }
            Console.WriteLine("Total No of Order(s) is "+order.count);
            Console.ReadKey();

        }
    }
}
