﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter EmpId:");
            int empid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Emp Name:");
            string empname = Console.ReadLine();
            Console.Write("Enter the Emp Basic Salary:");
            int basic = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Employee Type:");
            string type = Console.ReadLine();
            Employee obj;
            if (type == "Employee"|| type=="employee")
            {
                obj = new Employee(empid, empname, basic);
            }
            else if (type == "intern" || type == "Intern")
            {
                obj = new intern(empid, empname, basic);
            }
            else
            {

                obj = new Employee_Contract(empid, empname, basic);
            }
            Console.WriteLine(obj.GetDetails());
            Console.WriteLine(obj.GetWork());
            Console.WriteLine(obj.GetSalary());
            Console.ReadKey();
        }
    }
}
