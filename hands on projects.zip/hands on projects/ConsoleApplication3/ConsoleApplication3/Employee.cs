﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Employee
    {
        int EmpID;
        string EmpName;
        protected int basicSal;
        public Employee(int EmpID,string EmpName,int basicSal)
        {
            this.EmpID = EmpID;
            this.EmpName = EmpName;
            this.basicSal = basicSal;
        }
        public string GetDetails()
        {
            return EmpID + " " + EmpName;
        }
        public virtual string GetWork()
        {
            return "Working As A Programmer";
        }
        public virtual int GetSalary()
        {
            int tax = 1200;
            return basicSal+2500-tax;
        }
    }
}
