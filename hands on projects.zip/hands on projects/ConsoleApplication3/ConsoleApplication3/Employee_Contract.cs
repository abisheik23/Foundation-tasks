﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class Employee_Contract:Employee
    {
        public Employee_Contract(int EmpID, string EmpName, int basicSal)
            : base(EmpID, EmpName, basicSal)
        {
         
        }
        public sealed override int GetSalary()
        {
            return basicSal + 1000;
        }

    }
}
