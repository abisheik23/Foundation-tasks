﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_overriding
{
    class intern:Employee
    {
        public intern(int EmpId, string EmpName, int basicSal)
            : base(EmpId, EmpName, basicSal)
        {
        
        }
        public override string GetWork()
        {
            
            return "Working As A Intern";
        }
        public override int GetSalary()
        {
            basicSal = 15000;
           return basicSal;
        }
    }
}
