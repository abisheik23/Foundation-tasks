﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Win_thread
{
    public partial class frm_threadpool : Form
    {
        public frm_threadpool()
        {
            InitializeComponent();
        }

        private void btn_pool_Click(object sender, EventArgs e)
        {
            ThreadPool.SetMinThreads(5, 1000);
            ThreadPool.SetMaxThreads(10, 1000);
            int counter = 0;
            while (counter < 20)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(call),counter); 
                counter++;
            }
        }
        public void call(object obj)
        {
            MessageBox.Show(obj+" "+Thread.CurrentThread.ManagedThreadId);
        }

        private void frm_threadpool_Load(object sender, EventArgs e)
        {

        }
    }
}
