﻿namespace Win_thread
{
    partial class Frm_locking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_num1 = new System.Windows.Forms.TextBox();
            this.tb_num2 = new System.Windows.Forms.TextBox();
            this.btn_thread1 = new System.Windows.Forms.Button();
            this.btn_thread2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_num1
            // 
            this.tb_num1.Location = new System.Drawing.Point(87, 53);
            this.tb_num1.Name = "tb_num1";
            this.tb_num1.Size = new System.Drawing.Size(261, 20);
            this.tb_num1.TabIndex = 0;
            // 
            // tb_num2
            // 
            this.tb_num2.Location = new System.Drawing.Point(88, 120);
            this.tb_num2.Name = "tb_num2";
            this.tb_num2.Size = new System.Drawing.Size(260, 20);
            this.tb_num2.TabIndex = 1;
            // 
            // btn_thread1
            // 
            this.btn_thread1.Location = new System.Drawing.Point(42, 217);
            this.btn_thread1.Name = "btn_thread1";
            this.btn_thread1.Size = new System.Drawing.Size(125, 28);
            this.btn_thread1.TabIndex = 2;
            this.btn_thread1.Text = "Thread1";
            this.btn_thread1.UseVisualStyleBackColor = true;
            this.btn_thread1.Click += new System.EventHandler(this.btn_thread1_Click);
            // 
            // btn_thread2
            // 
            this.btn_thread2.Location = new System.Drawing.Point(248, 217);
            this.btn_thread2.Name = "btn_thread2";
            this.btn_thread2.Size = new System.Drawing.Size(125, 28);
            this.btn_thread2.TabIndex = 3;
            this.btn_thread2.Text = "Thread2";
            this.btn_thread2.UseVisualStyleBackColor = true;
            this.btn_thread2.Click += new System.EventHandler(this.btn_thread2_Click);
            // 
            // Frm_locking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(417, 360);
            this.Controls.Add(this.btn_thread2);
            this.Controls.Add(this.btn_thread1);
            this.Controls.Add(this.tb_num2);
            this.Controls.Add(this.tb_num1);
            this.Name = "Frm_locking";
            this.Text = "Frm_locking";
            this.Load += new System.EventHandler(this.Frm_locking_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_num1;
        private System.Windows.Forms.TextBox tb_num2;
        private System.Windows.Forms.Button btn_thread1;
        private System.Windows.Forms.Button btn_thread2;
    }
}