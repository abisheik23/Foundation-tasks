﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Win_thread
{
    public partial class frm_join_autoresetevent : Form
    {
        public frm_join_autoresetevent()
        {
            InitializeComponent();
        }
        public void call()
        {
            MessageBox.Show("Call Function");
            wait.Set();
            MessageBox.Show("Call Function 2");
        }
        AutoResetEvent wait = new AutoResetEvent(false);
        private void btn_join_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(call);
            th.Start();
            MessageBox.Show("Main Thread 1");
            wait.WaitOne();
            //th.Join();
            MessageBox.Show("Main Thread 2");
        }
    }
}
