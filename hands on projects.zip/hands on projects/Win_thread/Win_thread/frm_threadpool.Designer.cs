﻿namespace Win_thread
{
    partial class frm_threadpool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_pool = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_pool
            // 
            this.btn_pool.Location = new System.Drawing.Point(92, 98);
            this.btn_pool.Name = "btn_pool";
            this.btn_pool.Size = new System.Drawing.Size(134, 58);
            this.btn_pool.TabIndex = 0;
            this.btn_pool.Text = "ThreadPool";
            this.btn_pool.UseVisualStyleBackColor = true;
            this.btn_pool.Click += new System.EventHandler(this.btn_pool_Click);
            // 
            // frm_threadpool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 283);
            this.Controls.Add(this.btn_pool);
            this.Name = "frm_threadpool";
            this.Text = "Threadpool";
            this.Load += new System.EventHandler(this.frm_threadpool_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_pool;
    }
}