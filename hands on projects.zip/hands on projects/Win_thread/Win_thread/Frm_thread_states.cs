﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Win_thread
{
    public partial class Frm_thread_states : Form
    {
        public Frm_thread_states()
        {
            InitializeComponent();
        }
        Bitmap b1 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Chrysanthemum.jpg");
        Bitmap b2 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Penguins.jpg");
        Bitmap b3 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg");
        Bitmap b4 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg");
        Bitmap b5 = new Bitmap(@"C:\Users\Public\Pictures\Sample Pictures\Koala.jpg");
        public void showImages()
        {
            while (true)
            {
                pb_thread.Image = b1;
                Thread.Sleep(2000);
                pb_thread.Image = b2;
                Thread.Sleep(2000);
                pb_thread.Image = b3;
                Thread.Sleep(2000);
                pb_thread.Image = b4;
                Thread.Sleep(2000);
                pb_thread.Image = b5;
                Thread.Sleep(2000);
            }
        }
        Thread th;
        private void btn_start_Click(object sender, EventArgs e)
        {
            th = new Thread(showImages);
            th.IsBackground = true;
            th.Start();

        }

        private void btn_pause_Click(object sender, EventArgs e)
        {
            th.Suspend();
        }

        private void btn_resume_Click(object sender, EventArgs e)
        {
            th.Resume();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            th.Abort();
        }


    }
}
