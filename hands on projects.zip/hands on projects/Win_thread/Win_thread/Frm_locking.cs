﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace Win_thread
{
    public partial class Frm_locking : Form
    {
        public Frm_locking()
        {
            InitializeComponent();
        }
        int total;
        public void sum()
        {
          // lock (this)
            //{
            if (Monitor.TryEnter(this,5000))
            {
            
                int num1 = Convert.ToInt32(tb_num1.Text);
                int num2 = Convert.ToInt32(tb_num2.Text);
                total = num1 + num2;
                Thread.Sleep(15000);
                MessageBox.Show("Total :" + total);
                Monitor.Exit(this);
            }
            else
            {
                MessageBox.Show("Object is locked try after sometime");
            }
            //}
        }
        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(sum);
            th1.Start();
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(sum);
            th2.Start();
        }

        private void Frm_locking_Load(object sender, EventArgs e)
        {

        }
        
    }
}
