﻿namespace Win_thread
{
    partial class frm_async_call
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_asyncs = new System.Windows.Forms.Button();
            this.lst_results = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_asyncs
            // 
            this.btn_asyncs.Location = new System.Drawing.Point(87, 117);
            this.btn_asyncs.Name = "btn_asyncs";
            this.btn_asyncs.Size = new System.Drawing.Size(109, 42);
            this.btn_asyncs.TabIndex = 0;
            this.btn_asyncs.Text = "Async Call";
            this.btn_asyncs.UseVisualStyleBackColor = true;
            this.btn_asyncs.Click += new System.EventHandler(this.btn_asyncs_Click);
            // 
            // lst_results
            // 
            this.lst_results.FormattingEnabled = true;
            this.lst_results.Location = new System.Drawing.Point(79, 180);
            this.lst_results.Name = "lst_results";
            this.lst_results.Size = new System.Drawing.Size(134, 69);
            this.lst_results.TabIndex = 1;
            // 
            // frm_async_call
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lst_results);
            this.Controls.Add(this.btn_asyncs);
            this.Name = "frm_async_call";
            this.Text = "Async call";
            this.Load += new System.EventHandler(this.frm_async_call_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_asyncs;
        private System.Windows.Forms.ListBox lst_results;

        public System.EventHandler frm_async_call_Load { get; set; }
    }
}