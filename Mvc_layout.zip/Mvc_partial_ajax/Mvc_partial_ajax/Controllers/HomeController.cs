﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_partial_ajax.Models;
namespace Mvc_partial_ajax.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetPartialView(int pid)
        {
            ViewBag.pid = pid;
            ViewBag.pname = "Mobile";
            ViewBag.url = "/Images/download.jpg";
            return PartialView("MyPartialView"); 
        }

        public ActionResult AjaxIndex()
        {
            return View();
        }

        public ActionResult GetAjaxData(int pid)
        {
            return Json("Hello from the Server:"+pid+":"+DateTime.Now.ToString());
        }

        public ActionResult PlaceOrder()
        {
            return View();
        }
        [HttpPost]
        public ActionResult PlaceOrder(OrderModel model)
        {
            System.Threading.Thread.Sleep(3000);
            model.OrderID = 12522;
            return Json("Order Placed Successfully , Order ID:"+model.OrderID);
        }
    }
}
