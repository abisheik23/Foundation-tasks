﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace Mvc_partial_ajax.Models
{
    public class OrderModel
    {
    
        [Display(Name="OrderID")]
        public int OrderID { get; set; }

        [Display(Name="CustomerName")]
        [Required (ErrorMessage="*")]
        public string CustomerName { get; set; }

        [Display(Name="Order Amount")]
        [Required(ErrorMessage = "*")]
        public int OrderAmt { get; set; }

        [Display (Name="Order city")]
        [Required(ErrorMessage = "*")]
        public string OrderCity { get; set; }
    }
}