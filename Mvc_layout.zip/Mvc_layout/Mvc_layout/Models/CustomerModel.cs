﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Mvc_layout.Models
{
    public class CustomerModel
    {
        [Display (Name="Customer ID")]    
        public int Customerid { get; set; }
        
        [Display (Name="FirstName")]
        [Required(ErrorMessage="Enter the First Name")]
        [StringLength(int.MaxValue,MinimumLength=5,ErrorMessage="Miniumum 5 chars")]
        public string CustomerFname { get; set; }


        [Display(Name = "LastName")]
        [Required(ErrorMessage = "Enter the Last Name")]
        [StringLength(int.MaxValue, MinimumLength = 5, ErrorMessage = "Miniumum 5 chars")]
        public string CustomerLname { get; set; }
        
        [Display(Name="Age")]
        [Required(ErrorMessage="Enter the age")]
        [Range(18,60,ErrorMessage="Age b/w 18-60")]
        public int CustomerAge { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter the City ID")]
        public int city { get; set;}
        
        [Display(Name="Email")]
        [Required(ErrorMessage="Enter the EmailID")]
        [Remote("CheckEmail", "Home", ErrorMessage = "Invalid EmailID")]
        public string CustomerEmail { get; set; }
        
        [Display(Name="Address")]
        [Required(ErrorMessage="Enter the address")]
        [StringLength(100,MinimumLength=10,ErrorMessage="Min 10 Chars")]
        public string Customeraddress { get; set; }
    }
}