﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

namespace Mvc_layout.Models
{
    public class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["layout"].ConnectionString);
        public bool addCustomers(CustomerModel c)
        {
            SqlCommand com_ins = new SqlCommand("insert customers values(@fname,@lname,@age,@cid,@emid,@addr)", con);
            com_ins.Parameters.AddWithValue("@fname", c.CustomerFname);
            com_ins.Parameters.AddWithValue("@lname", c.CustomerLname);
            com_ins.Parameters.AddWithValue("@age", c.CustomerAge);
            com_ins.Parameters.AddWithValue("@cid", c.city);
            com_ins.Parameters.AddWithValue("@emid", c.CustomerEmail);
            com_ins.Parameters.AddWithValue("@addr", c.Customeraddress);
            con.Open();
            com_ins.ExecuteNonQuery();
            SqlCommand com_cuid=new SqlCommand("select @@identity",con);
            int cusid = Convert.ToInt32(com_cuid.ExecuteScalar());
            c.Customerid = cusid;
            con.Close();
            return true;
        }
        public List<CustomerModel> getCustomer()
        {
            List<CustomerModel> cuslist = new List<CustomerModel>();
            SqlCommand com_details = new SqlCommand("Select * from customers", con);
            con.Open();
            SqlDataReader dr = com_details.ExecuteReader();
            while (dr.Read())
            {
                CustomerModel c = new CustomerModel();
                c.Customerid=dr.GetInt32(0);
                c.CustomerFname=dr.GetString(1);
                c.CustomerLname=dr.GetString(2);
                c.CustomerAge=dr.GetInt32(3);
                c.city=dr.GetInt32(4);
                c.CustomerEmail=dr.GetString(5);
                c.Customeraddress=dr.GetString(6);
                cuslist.Add(c);
            }
            con.Close();
            return cuslist;
        }
        public List<CityModel> getCity()
        {
            List<CityModel> citylist = new List<CityModel>();
            SqlCommand com_city = new SqlCommand("select * from cities", con);
            con.Open();
            SqlDataReader dr=com_city.ExecuteReader();
           
            while(dr.Read())
            {
                CityModel c = new CityModel();
                c.cityid = dr.GetInt32(0);
                c.cityname = dr.GetString(1);
                citylist.Add(c);
            }
            con.Close();
            return citylist;
        }

        public bool CheckEmail(string CustomerEmail)
        {
            SqlCommand com_check = new SqlCommand("Select Count(*) from customers where customeremailid=@eid", con);
            com_check.Parameters.AddWithValue("@eid", CustomerEmail);
            con.Open();
            com_check.ExecuteNonQuery(); 
            int count = Convert.ToInt32(com_check.ExecuteScalar());
            con.Close(); 
           if (count == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
            
          public bool addOrder(OrderModel o)
        {
            SqlCommand com_ins = new SqlCommand("insert orders values(@cid,@iid,@iqty,@iprice,@addr)", con);
            com_ins.Parameters.AddWithValue("@cid", o.CustomerID);
            com_ins.Parameters.AddWithValue("@iid",o.ItemID);
            com_ins.Parameters.AddWithValue("@iqty", o.ItemQty);
            com_ins.Parameters.AddWithValue("@iprice", o.ItemPrice);
            com_ins.Parameters.AddWithValue("@addr", o.Address);
            con.Open();
            com_ins.ExecuteNonQuery();
            SqlCommand com_cuid=new SqlCommand("select @@identity",con);
            int orderid = Convert.ToInt32(com_cuid.ExecuteScalar());
            o.OrderID = orderid;
            con.Close();
            return true;
        }

          public List<OrderModel> showOrder(int cid)
          {
              List<OrderModel> orderlist = new List<OrderModel>();
              SqlCommand com_order = new SqlCommand("select * from orders where customerid=@cid", con);
              com_order.Parameters.AddWithValue("@cid", cid);
              con.Open();
              SqlDataReader dr = com_order.ExecuteReader();

              while (dr.Read())
              {
                  OrderModel o = new OrderModel();
                  o.OrderID = dr.GetInt32(0);
                  o.CustomerID = dr.GetInt32(1);
                  o.ItemID = dr.GetInt32(2);
                  o.ItemQty = dr.GetInt32(3);
                  o.ItemPrice = dr.GetInt32(4);
                  o.Address = dr.GetString(5);
                  orderlist.Add(o);
              }
              con.Close();
              return orderlist;
          }

          public OrderModel findOrder(int oid)
          {
              OrderModel o = new OrderModel();
              SqlCommand com_order = new SqlCommand("select * from orders where orderid=@oid", con);
              com_order.Parameters.AddWithValue("@oid", oid);
              con.Open();
              SqlDataReader dr = com_order.ExecuteReader();

              while (dr.Read())
              {
                  
                  o.OrderID = dr.GetInt32(0);
                  o.CustomerID = dr.GetInt32(1);
                  o.ItemID = dr.GetInt32(2);
                  o.ItemQty = dr.GetInt32(3);
                  o.ItemPrice = dr.GetInt32(4);
                  o.Address = dr.GetString(5);
                 
              }
              con.Close();
              return o;
          }
            
        }
    }
