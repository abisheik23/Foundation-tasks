﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_layout.Models
{
    public class CityModel
    {
        public int cityid { get; set; }
        public string cityname { get; set;}
    }
}