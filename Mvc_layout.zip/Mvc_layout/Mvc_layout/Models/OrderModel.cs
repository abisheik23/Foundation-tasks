﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace Mvc_layout.Models
{
    public class OrderModel
    {
         [Display(Name = "Order ID")]    
        public int OrderID { get; set; }

         [Display(Name = "Customer ID")]
         [Required(ErrorMessage = "Required")]
        public int CustomerID { get; set; }

         [Display(Name = "Item ID")]
         [Required(ErrorMessage = "Required")]
        public int ItemID { get; set; }

         [Display(Name = "Item Qty")]
         [Required(ErrorMessage = "Required")]
        public int ItemQty { get; set; }

         [Display(Name = "Item Price")]
         [Required(ErrorMessage = "Required")]
        public int ItemPrice { get; set;}

         [Display(Name = "Address")]
         [Required(ErrorMessage = "Required")]
          public string Address { get; set;}
    }
}