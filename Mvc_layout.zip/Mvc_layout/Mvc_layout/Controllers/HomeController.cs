﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_layout.Models;

namespace Mvc_layout.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult PlaceOrder()
        {
            return View();
        }
        public ActionResult FindOrder()
        {
            return View();
        }
        public ActionResult ShowOrder(int cid)
        {
            CustomerDAL dal = new CustomerDAL();
            List<OrderModel> orderlist=dal.showOrder(cid);
            return PartialView("ShowOrder",orderlist);
        }

        public ActionResult ShowDetails()
        {
          
            return View();
        }
        [HttpPost]
        public ActionResult FindOrder(int oid)
        { 
            CustomerDAL dal = new CustomerDAL();
            OrderModel o=dal.findOrder(oid);
            return PartialView("ShowDetails", o);
        }
        public ActionResult AddCustomer()
        {
            List<SelectListItem> cities = new List<SelectListItem>();
            List<CityModel> citylist = new List<CityModel>();
            CustomerDAL dal = new CustomerDAL();
            citylist = dal.getCity();
            foreach (CityModel city in citylist)
            {
                cities.Add(new SelectListItem { Text=city.cityname, Value=(Convert.ToString(city.cityid))});
            }
            ViewBag.cities = cities;
            return View();
        }
        
        
        [HttpPost]
        public ActionResult AddCustomer(CustomerModel c)
        {
            

            CustomerDAL dal = new CustomerDAL();
            dal.addCustomers(c);
            ViewBag.customerid = c.Customerid;
            return View("CustomerAdded");
        }
        public ActionResult GetCustomer()
        {
            CustomerDAL dal = new CustomerDAL();
            List<CustomerModel> cuslist = dal.getCustomer();
            return View(cuslist);
        }
        [HttpPost]
        public ActionResult PlaceOrder(OrderModel o)
        {
            CustomerDAL dal = new CustomerDAL();
            dal.addOrder(o);
            System.Threading.Thread.Sleep(3000);
            return Json("Order Placed Successfully , Order ID:" + o.OrderID);
           
        }

       public ActionResult CheckEmail(string CustomerEmail)
        {
            CustomerDAL dal = new CustomerDAL();
            if (dal.CheckEmail(CustomerEmail))
            {
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
