﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Mvc_admin.Models
{
    public class Security
    {
        [Display(Name = "AdminID")]
        [Required(ErrorMessage = "Enter the adminID")]
        public string adminID { get; set; }
        
        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter the Password")]
        public string password { get; set; }

        [Display(Name = "Email Address")]
        [Required(ErrorMessage = "Enter the Email Address")]
        [EmailAddress(ErrorMessage = "Enter the proper Email Address")]
        public string emailID { get; set; }

        [Display(Name = "Security Question")]
        [Required(ErrorMessage = "Enter the Question")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "Security Answer")]
        [Required(ErrorMessage = "Enter the Answer")]
        public string SecurityAnswer { get; set; }
    }
}