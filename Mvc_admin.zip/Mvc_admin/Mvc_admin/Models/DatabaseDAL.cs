﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
namespace Mvc_admin.Models
{
    public class DatabaseDAL
    {
        public bool addDetails(Security s)
        {

            MembershipCreateStatus status;
            Membership.CreateUser(s.adminID,s.password,s.emailID,s.SecurityQuestion,s.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        mainprojectEntities dc = new mainprojectEntities();
        public client client(int cid)
        {
            var obj = (from c in dc.clients
                       where c.clientid == cid
                       select c).FirstOrDefault();
            client cli = obj;
            return cli;

        }
        public List<TransactionDetail> translist()
        {
            var q = from trans in dc.TransactionDetails
                    select trans;
            List<TransactionDetail> trs = q.ToList();
            return trs;
        }
        public List<AccRequest> reqlist()
        {
            var r = from req in dc.AccRequests
                    select req;

            List<AccRequest> accr = r.ToList();
            return accr;
        }
        public bool addAcc(AccountDetail ad)
        {
            dc.AccountDetails.Add(ad);
            dc.SaveChanges();
            return true;
        }
    }
}