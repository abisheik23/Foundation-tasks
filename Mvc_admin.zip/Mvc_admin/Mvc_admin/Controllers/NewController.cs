﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_admin.Models;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_admin.Controllers
{
    public class NewController : Controller
    {
        LogEntry log = new LogEntry();
        // GET: /New/
        [AllowAnonymous]
        public ActionResult AddSecurity()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult AddSecurity(Security s)
        {
            
            DatabaseDAL dal = new DatabaseDAL();
            log.Message = "New admin has been created";
            Logger.Write(log);
            dal.addDetails(s);
            return Json("Admin has been added");
        }

    }
}
