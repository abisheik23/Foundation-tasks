﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_admin.Models;
using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_admin.Controllers
{
    public class MainController : Controller
    {
        LogEntry log = new LogEntry();
        // GET: /Main/
        [Authorize]
        public ActionResult TransactionDetails()
        {
            DatabaseDAL dal = new DatabaseDAL();
            List<TransactionDetail> trans=dal.translist();
            return View(trans);
        }
        
        [Authorize]
        public ActionResult ClientDetails(int cid)
        {
            DatabaseDAL dal = new DatabaseDAL();
            client c = dal.client(cid);
            if (c == null) 
            {
                log.Message = "Data not found for client "+cid.ToString();
                Logger.Write(log);
                return Json("Data not found");
            }
            else
            {
                log.Message = "Client details of " + cid.ToString() +" are shown";
                Logger.Write(log);
                return PartialView("ClientDetails",c);
            }
        }

        [Authorize]
        public ActionResult RequestDetails()
        {
            DatabaseDAL dal = new DatabaseDAL();
            List<AccRequest> req = dal.reqlist();
            log.Message = "Request details of are shown";
            Logger.Write(log);
            return View(req);
        }
        
        [Authorize]
        public ActionResult addAccount()
        {
            return View();
        }
        
        [Authorize]
        [HttpPost]
        public ActionResult addAccount(AccountDetail acc)
        {
           
                DatabaseDAL dal = new DatabaseDAL();
                log.Message = "Account is added for " + acc.clientid.ToString();
                Logger.Write(log);
                dal.addAcc(acc);
                ViewBag.msg="Account has been to added to clientid" + acc.clientid;
                return View();
                
        }
        
    }
}
