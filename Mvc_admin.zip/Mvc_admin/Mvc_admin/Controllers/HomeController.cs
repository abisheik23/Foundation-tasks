﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_admin.Controllers
{
    public class HomeController : Controller
    {
        LogEntry log = new LogEntry();
        // GET: /Home/
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }
        [Authorize]
        public ActionResult Logout()
        {
            log.Message = "The user" + User.Identity.Name + "Has logged out";
            Logger.Write(log);
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }


        [HttpPost]
        public ActionResult Login(string adminID, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(adminID,Password))
            {
                FormsAuthentication.SetAuthCookie(adminID,rememberme);
                return RedirectToAction("Index", "Home");
                log.Message = "The User " + User.Identity.Name.ToString() + " has logged in";
                Logger.Write(log);
            }
            else
            {
                log.Message = "The Invalid Userid or Password for " + User.Identity.Name;
                Logger.Write(log);
                ViewBag.msg = "Invalid User Id or Password";
                return View();
            }
        }

    }
}
