﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_firstapp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult AboutUs()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult Login(int userid, string password, bool rememberme)
        {
            if (userid == 1000 && password == "pass@123")
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return View("InvalidUser");
            }
        }
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult getSum()
        {
            return View();
        }

        [HttpPost]

        public ActionResult getSum(int num1, int num2)
        {
            //DAL
            int total = num1 + num2;
            ViewBag.result = total;

            return View();
        }

    }
}
