﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_Assign.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            ViewBag.userid = TempData["userid"].ToString();
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Login(int userid, string password, bool rememberme)
        {
            if (userid == 1000 && password == "password")
            {
                return RedirectToAction("Index","Home");
            }
            else
            {
                return View("InvalidUser");
            }
        }

        public ActionResult addCust()
        {
            return View();
        }

        [HttpPost]
        public ActionResult addCust(int customerid, string customername, string customercity, string customerpassword) 
        {
            return View("CreateCustomer");
        }

    }
}
