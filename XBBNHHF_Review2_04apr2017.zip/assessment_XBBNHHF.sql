create database assessment

use assessment

create table department_XBBNHHF(
dept_id int primary key,
dept_name varchar(120)
)

create table employee_XBBNHHF(
emp_id int identity(1000,1) primary key,
emp_name varchar(120),
dob date,
designation varchar(120),
dept_id int foreign key references department_XBBNHHF(dept_id) 
)


insert department_XBBNHHF values(1,'Accounts')
insert department_XBBNHHF values(2,'Development')
insert department_XBBNHHF values(3,'Customer Service')
insert department_XBBNHHF values(4,'Quality and Assurance')
insert department_XBBNHHF values(5,'Human Resource')
insert department_XBBNHHF values(6,'Learning and Development')
insert department_XBBNHHF values(7,'Networking')
insert department_XBBNHHF values(8,'Data Analyst')
insert department_XBBNHHF values(9,'UI/UX Development')
insert department_XBBNHHF values(10,'Mainframe')

select e.emp_name,e.dob,e.designation,d.dept_name from employee_XBBNHHF e join department_XBBNHHF d on(e.dept_id=d.dept_id)