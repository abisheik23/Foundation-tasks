﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class View_XBBNHHF : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_search_Click(object sender, EventArgs e)
    {
         int id = Convert.ToInt32(tb_search.Text);
        DatabaseDAL dal = new DatabaseDAL();
        View v = dal.viewdata(id);
        if (v != null && v.dob.ToShortDateString()!="1/1/0001")
        {
            lb_msg.Text = "Employee Found";
            lb_name.Text = v.name;
            lb_dob.Text = v.dob.ToShortDateString();
            lb_desg.Text = v.desg;
            lb_dept.Text = v.dept;
        }
        else
        {
            lb_msg.Text = "Employee not found";
            lb_name.Text = "";
            lb_dob.Text = "";
            lb_desg.Text = "";
            lb_dept.Text = "";
        }
    }
    
}