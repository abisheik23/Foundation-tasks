﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;
namespace Mvc_mainproject.Models
{
    public class DatabaseDAL
    {
       mainprojectEntities dc = new mainprojectEntities();
        public int addClients(client c)
       {
            dc.clients.Add(c);        
            dc.SaveChanges();
            return c.clientid;
            
        }

        public bool addAccount(AccountDetail ad)
        {
            dc.AccountDetails.Add(ad);
            dc.SaveChanges();
            return true;
        }
        public bool addDetails(DatabaseModel dm)
        {
           
            MembershipCreateStatus status;
            Membership.CreateUser(dm.Id.ToString(), dm.password, dm.emailaddress, dm.securityQuestion, dm.securityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
               return true;
            }
            else
            {
                return false;
            }
        }
        public List<AccountDetail> showAccount(int cid)
        {
            var q=from acc in dc.AccountDetails
                  where acc.clientid==cid
                  select acc;
            List<AccountDetail> acclist = q.ToList();
            return acclist;
        }
        public bool addAccess(accessDetail ad)
        {
            dc.accessDetails.Add(ad);
            dc.SaveChanges();
            return true;
        }
        public accessDetail showAccess(int aid)
        {
            var obj = (from ad in dc.accessDetails
                    where ad.accountid == aid
                    select ad).FirstOrDefault();
            accessDetail adl = obj;
            return adl;
        }
        
    }
}