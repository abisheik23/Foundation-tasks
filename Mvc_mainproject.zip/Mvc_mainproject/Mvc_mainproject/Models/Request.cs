﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_mainproject.Models
{
    public class Request
    {

        
        public int reqid { get; set; }
        
        public int clientid { get; set; }
        
        public string type { get; set; }
       
        public int amount { get; set; }
    }
}