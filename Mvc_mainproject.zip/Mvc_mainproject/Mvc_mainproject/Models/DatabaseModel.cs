﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Mvc_mainproject.Models
{
    public class DatabaseModel
    {
        [Display(Name="Password")]
        [Required(ErrorMessage="Enter the Password")]
        public string password { get; set;}

        [Display(Name="Email Address")]
        [Required (ErrorMessage="Enter the Email Address")]
        [EmailAddress (ErrorMessage="Enter the proper Email Address")]
        public string emailaddress { get; set; }
        
        [Display(Name = "Security Question")]
        [Required(ErrorMessage = "Enter the Question")]
        public string securityQuestion { get; set; }

        [Display(Name = "Security Answer")]
        [Required(ErrorMessage = "Enter the Answer")]
        public string securityAnswer { get; set; }

        [Display(Name = "AccountID")]
        [Required(ErrorMessage = "Enter the Password")]
        public int Id { get; set; }
    }
}