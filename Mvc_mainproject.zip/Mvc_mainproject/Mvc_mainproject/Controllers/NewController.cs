﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Mvc_mainproject.Models;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_mainproject.Controllers
{
    public class NewController : Controller
    {
        LogEntry log = new LogEntry();
        // GET: /New/
        static int cid;
        [AllowAnonymous]
        public ActionResult NewCustomer()
        {
            return View();
        }
       
        [AllowAnonymous]
        public ActionResult NewAccount()
        {
           return View();
        }
        
        [AllowAnonymous]
        public ActionResult NewSecurity()
        {
            
            return View();
        }
        [AllowAnonymous]
        public ActionResult NewSecurity2()
        {

            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewCustomer(client c)
        {
            DatabaseDAL dal = new DatabaseDAL();
            cid=dal.addClients(c);
            return View();
           
        }
        
        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewAccount(AccountDetail ad)
        {
            DatabaseDAL dal = new DatabaseDAL();
            ad.clientid = cid;
            dal.addAccount(ad);
            return View();
        }
        
        [HttpPost]
        [AllowAnonymous]
        public ActionResult NewSecurity(DatabaseModel dm)
        {
            log.Message = "New user has been created for " + cid.ToString();
            Logger.Write(log);
            DatabaseDAL dal = new DatabaseDAL();
            dm.Id = cid;
            dal.addDetails(dm);
            System.Threading.Thread.Sleep(2000);
            return Json("This page will Redirect in 10 seconds,Do not Refresh the page ,client id is" + dm.Id);

        }
        

    }
}
