﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Mvc_mainproject.Models;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_mainproject.Controllers
{
    public class HomeController : Controller
    {
        LogEntry logEntry = new LogEntry();
        //
        // GET: /Home/
        [Authorize]
        public ActionResult Index()
        {
            int cid = Convert.ToInt32(User.Identity.Name);
            DatabaseDAL dal = new DatabaseDAL();
            List<AccountDetail> acclist = dal.showAccount(cid);
            return View(acclist);
        }
       
        public ActionResult Login()
        {
            return View();
        }

        [Authorize]
       
   public ActionResult Logout()
        {
           // var logWriter = EnterpriseLibraryContainer.Current.GetInstance<LogWriter>();
            
            logEntry.Message = "The user" + User.Identity.Name.ToString() + "Has logged out";
            Logger.Write(logEntry);
            FormsAuthentication.SignOut();

            return RedirectToAction("Login", "Home");
           
        }
       
    
        [HttpPost]
        public ActionResult Login(int ClientID, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(ClientID.ToString(), Password))
            {
                logEntry.Message = "The User " + User.Identity.Name.ToString() + " has logged in";
                Logger.Write(logEntry);
                FormsAuthentication.SetAuthCookie(ClientID.ToString(), rememberme);
                return RedirectToAction("Index", "Home");
               
            }
            else
            {
                logEntry.Message = "The Invalid Userid or Password for "+ User.Identity.Name.ToString();
                Logger.Write(logEntry);
                ViewBag.msg = "Invalid User Id or Password";
                return View();
            }
        }
        

    }
}
