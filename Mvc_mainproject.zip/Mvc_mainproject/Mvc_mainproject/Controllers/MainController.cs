﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc_mainproject.Models;
using System.Transactions;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Net;
using System.Runtime.Serialization.Json;
using Microsoft.Practices.EnterpriseLibrary.Logging;
namespace Mvc_mainproject.Controllers
{
    public class MainController : Controller
    {
        LogEntry log = new LogEntry();
        // GET: /Main/
        [Authorize]
        public ActionResult AccRequest()
        {
            return View();
        }

        [Authorize]
        public ActionResult showAccess(int aid)
        {
            DatabaseDAL dal = new DatabaseDAL();
            accessDetail adlist = dal.showAccess(aid);
            if (adlist == null) 
            {
                log.Message = "Access Details not found for "+ User.Identity.Name.ToString()+" for "+aid.ToString();
                Logger.Write(log);
                return Json("Access Details not found");
            }
            else
            {
                log.Message = "Access Details of " + aid.ToString()+" are shown";
                Logger.Write(log);
                return PartialView("showAccess", adlist);
            }
        }
        
        [Authorize]
        public ActionResult TransferAmount()
        {
            return View();
        }
        
        [Authorize]
        public ActionResult addAccess()
        {
            return View();
        }
        [Authorize]
          public ActionResult ViewAccount()
        {
            log.Message = "Account Details of  " + User.Identity.Name.ToString() + " are shown";
            Logger.Write(log);
            int cid = Convert.ToInt32(User.Identity.Name);
            DatabaseDAL dal = new DatabaseDAL();
            List<AccountDetail> acclist = dal.showAccount(cid);
            return View(acclist);
        }

        [Authorize]
        [HttpPost]
        public ActionResult addAccess(accessDetail ad)
        {
            log.Message = "Access Details are added " + ad.accountid.ToString() + " are shown";
            Logger.Write(log);
            DatabaseDAL dal = new DatabaseDAL();
            dal.addAccess(ad);
            return Json("Security Detail has been added to your account"+ad.accountid);
        }

        [Authorize]
        [HttpPost]
        public ActionResult TransferAmount(int saccid,int taccid,int amt,int pin)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    ServiceReference_pay.ServiceClient pay_proxy = new ServiceReference_pay.ServiceClient("WSHttpBinding_IService");
                    int id = pay_proxy.addPay(Convert.ToInt32(User.Identity.Name),saccid,taccid,amt,pin);
                    scope.Complete();
                    System.Threading.Thread.Sleep(2000);
                    if (id != 0)
                    {
                        log.Message = "Transaction of "+amt.ToString() +" is Transferred from " + saccid.ToString() + " to " +taccid.ToString();
                        Logger.Write(log);
                        return Json("Your Transaction ID-" + id + "Has been completed");
                    }
                    else
                    {
                        log.Message = "Transaction failed  of " + saccid.ToString();
                        Logger.Write(log);
                        return Json("Transaction Failed");
                    }
                }
            }
            catch(Exception exp)
            {
                log.Message = "Transaction cancelled due to " + exp;
                Logger.Write(log);
                return Json("Your Transaction has been cancelled");
                
            }
        }

        [Authorize]
        [HttpPost]
        public ActionResult AccRequest(string acctype, int amt)
        {

            try
            {
                ServiceReference_req.Request obj = new ServiceReference_req.Request();
                obj.clientid = Convert.ToInt32(User.Identity.Name);
                obj.acctype = acctype;
                obj.amount = amt;
                ServiceReference_req.ServiceClient req_proxy = new ServiceReference_req.ServiceClient("WSHttpBinding_IService1");
                log.Message = "Account Request of  " + User.Identity.Name.ToString() + " is given to admin";
                Logger.Write(log);
                string msg = req_proxy.addReq(obj);
                return Json(msg);
                //using (WebClient client_req = new WebClient())
                //{
                //    string param = User.Identity.Name + "/" + acctype + "/" + Convert.ToString(amt);
                //    string address = "http://localhost:49916/service_req/Service.svc/Request/" + param;
                //    client_req.OpenReadCompleted += new OpenReadCompletedEventHandler(client_req_OpenReadCompleted);
                //    client_req.OpenRead(new Uri(address, UriKind.Absolute));
                //    return View();
                //}
            }
            catch (Exception exp)
            {
                log.Message = "Request Failed due to" + exp;
                Logger.Write(log);
                return Json("Request Failed");
            }
        }
                    
            
        

        //public void client_req_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        //{
            
        //    DataContractJsonSerializer json = new DataContractJsonSerializer(typeof(Int32));
        //    object on = json.ReadObject(e.Result) as object;
        //    ViewBag.data = Convert.ToString(on);
        
        //}


        

        
       
    }
}
