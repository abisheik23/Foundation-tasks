﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
namespace Mvc_admin.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }
         public ActionResult Login()
        {
            return View();
        }

        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }


        [HttpPost]
        public ActionResult Login(string adminID, string Password, bool rememberme)
        {
            if (Membership.ValidateUser(adminID,Password))
            {
                FormsAuthentication.SetAuthCookie(adminID,rememberme);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "Invalid User Id or Password";
                return View();
            }
        }

    }
}
